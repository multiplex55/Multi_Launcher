//! Worker-owned macro runtime.  The public methods only exchange messages and snapshots;
//! action execution and all waits live on the worker.
#[cfg(test)]
use super::compile_program;
pub use super::executor::DebugSnapshotReason;
use super::executor::{
    Backends, DiagnosticKind, ExecResult, ExecutionDiagnostic, ExecutionEvent,
    ExecutionFrameContext, ExecutionFrameSnapshot, ExecutionMode, ExecutionOptions, Executor,
    MonotonicClock, RunControl, StepOutcome, SystemMonotonicClock, production_backends_with_store,
    program_contains_clipboard_actions,
};
use super::{
    EventEnricher, KeyboardTranslator, MkInvocation, MkInvocationSubset, MkInvocationValues,
    MkMacroDocument, MkMacroStore, MkValue, NormalizationConfig, Operation,
    RecorderObserverSession, RecorderRuntime, RecorderSnapshot, RecordingResult, RecordingTarget,
    RuntimeVariables, SharedOperationGuard, SystemRecorderClock, production_hook_service,
};
use crate::activity::{
    ActivityCenter, ActivityDiagnostic, ActivityIncarnation, ActivityOperation, ActivityOutcome,
    ActivityOwner, ActivityProgress, ActivityProgressUnit, ActivityRetirement, ActivitySlot,
    ActivityTask,
};
mod summary;
use anyhow::{Result, anyhow};
use once_cell::sync::Lazy;
#[cfg(test)]
use std::time::{Duration, Instant};
use std::{
    collections::BTreeMap,
    sync::{
        Arc, Condvar, Mutex, RwLock,
        atomic::{AtomicBool, AtomicU8, AtomicU64, Ordering},
        mpsc,
    },
    thread::{self, JoinHandle},
    time::SystemTime,
};
pub(crate) use summary::{
    HISTORY_DETAIL_LIMIT, HISTORY_PAGE_SIZE, HistoryFilter, HistoryHeader, HistoryProjection,
    HistoryStepDetail, HistoryViewError, HistoryViewRequest, RunKey,
};
pub use summary::{
    InvocationSource, MacroRunSummary, SafeFailureLocation, SummaryActionCategory, SummaryOutcome,
    SummaryStepAggregate, SummarySubset, SummaryVisitTotals,
};
use summary::{SummaryAccumulator, SummaryHistory};

#[derive(Debug, Clone, PartialEq)]
pub enum RuntimeCommand {
    Invoke(MkInvocation),
    Run(u64),
    RunFrom(u64, u64),
    RunSelection(u64, Vec<u64>),
    DebugRun(u64),
    DebugRunFrom(u64, u64),
    DebugRunSelection(u64, Vec<u64>),
    /// Executes an already-compiled, process-local recording proposal. The
    /// ticket associates transient Review UI with this run without publishing
    /// the proposal through the store.
    RecordingPreview {
        macro_id: u64,
        ticket: u64,
    },
    Pause,
    Resume,
    Stop,
    Shutdown,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RuntimeRunMode {
    Normal,
    Debug,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RuntimeOrigin {
    Stored,
    RecordingPreview { ticket: u64 },
}
#[derive(Debug, Clone, Copy)]
struct RunRequest<'a> {
    macro_id: u64,
    starting_step: Option<u64>,
    selection: Option<&'a [u64]>,
    mode: RuntimeRunMode,
    arguments: Option<&'a MkInvocationValues>,
}
impl RunRequest<'_> {
    fn summary_subset(self) -> SummarySubset {
        if let Some(step_id) = self.starting_step {
            SummarySubset::FromStep { step_id }
        } else if let Some(ids) = self.selection {
            SummarySubset::Selected {
                step_count: u64::try_from(ids.len()).unwrap_or(u64::MAX),
            }
        } else {
            SummarySubset::Whole
        }
    }

    fn to_invocation(self) -> MkInvocation {
        MkInvocation {
            macro_id: self.macro_id,
            arguments: self.arguments.cloned().unwrap_or_default(),
            mode: match self.mode {
                RuntimeRunMode::Normal => ExecutionMode::Normal,
                RuntimeRunMode::Debug => ExecutionMode::Debug,
            },
            subset: if let Some(id) = self.starting_step {
                MkInvocationSubset::From(id)
            } else if let Some(ids) = self.selection {
                MkInvocationSubset::Selected(ids.to_vec())
            } else {
                MkInvocationSubset::Whole
            },
        }
    }
}
fn run_request(command: &RuntimeCommand) -> Option<RunRequest<'_>> {
    if let RuntimeCommand::Invoke(invocation) = command {
        let (starting_step, selection) = match &invocation.subset {
            MkInvocationSubset::Whole => (None, None),
            MkInvocationSubset::From(id) => (Some(*id), None),
            MkInvocationSubset::Selected(ids) => (None, Some(ids.as_slice())),
        };
        return Some(RunRequest {
            macro_id: invocation.macro_id,
            starting_step,
            selection,
            mode: match invocation.mode {
                ExecutionMode::Normal => RuntimeRunMode::Normal,
                ExecutionMode::Debug => RuntimeRunMode::Debug,
            },
            arguments: Some(&invocation.arguments),
        });
    }
    let (macro_id, starting_step, selection, mode) = match command {
        RuntimeCommand::Run(id) => (*id, None, None, RuntimeRunMode::Normal),
        RuntimeCommand::RunFrom(id, step_id) => (*id, Some(*step_id), None, RuntimeRunMode::Normal),
        RuntimeCommand::RunSelection(id, selection) => (
            *id,
            None,
            Some(selection.as_slice()),
            RuntimeRunMode::Normal,
        ),
        RuntimeCommand::DebugRun(id) => (*id, None, None, RuntimeRunMode::Debug),
        RuntimeCommand::DebugRunFrom(id, step_id) => {
            (*id, Some(*step_id), None, RuntimeRunMode::Debug)
        }
        RuntimeCommand::DebugRunSelection(id, selection) => {
            (*id, None, Some(selection.as_slice()), RuntimeRunMode::Debug)
        }
        RuntimeCommand::RecordingPreview { macro_id, .. } => {
            (*macro_id, None, None, RuntimeRunMode::Normal)
        }
        _ => return None,
    };
    Some(RunRequest {
        macro_id,
        starting_step,
        selection,
        mode,
        arguments: None,
    })
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RuntimeState {
    Idle,
    Running,
    Paused,
    Stopping,
    Completed,
    Stopped,
    Failed,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RuntimePauseReason {
    User,
    Breakpoint {
        step_id: u64,
        frame: ExecutionFrameContext,
    },
}
#[derive(Debug, Clone, PartialEq)]
pub struct DebugSnapshot {
    pub frame: ExecutionFrameContext,
    pub macro_name: Arc<str>,
    /// The last immutable variable map published by a Debug execution
    /// boundary. This is always owned by the snapshot and never aliases the
    /// executor's worker-local map.
    pub step_id: Option<u64>,
    pub variables: Arc<RuntimeVariables>,
    pub reason: DebugSnapshotReason,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StepState {
    Pending,
    Running,
    Success,
    Skipped,
    Failed,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct DiagnosticKey {
    pub run_id: u64,
    pub step_id: u64,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct MacroStepKey {
    pub macro_id: u64,
    pub step_id: u64,
}
impl MacroStepKey {
    pub const fn new(macro_id: u64, step_id: u64) -> Self {
        Self { macro_id, step_id }
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct MacroDiagnosticKey {
    pub run_id: u64,
    pub step: MacroStepKey,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BreakpointOccurrence {
    pub run_id: u64,
    pub occurrence: u64,
    pub frame_id: u64,
    pub step: MacroStepKey,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CompletedStepOutcome {
    Success(Option<StepOutcome>),
    Failure(ExecutionDiagnostic),
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CompletedStep {
    pub frame: ExecutionFrameContext,
    pub key: MacroStepKey,
    pub macro_name: Arc<str>,
    pub outcome: CompletedStepOutcome,
}

#[derive(Debug, Clone)]
pub struct RuntimeSnapshot {
    pub state: RuntimeState,
    pub run_mode: RuntimeRunMode,
    pub run_id: u64,
    pub origin: RuntimeOrigin,
    /// Root invocation identity, preserved for compatibility.
    pub macro_id: Option<u64>,
    pub root_macro_name: Option<Arc<str>>,
    /// Current root step; callees have their own authoritative stack identity.
    pub step_id: Option<u64>,
    pub call_stack: Arc<Vec<ExecutionFrameSnapshot>>,
    pub macro_steps: Arc<BTreeMap<MacroStepKey, StepState>>,
    pub macro_step_outcomes: Arc<BTreeMap<MacroStepKey, StepOutcome>>,
    pub macro_failures: Arc<BTreeMap<MacroDiagnosticKey, ExecutionDiagnostic>>,
    /// This result belongs to an invocation occurrence, independently of maps
    /// reset when the same callee is invoked again or its frame is popped.
    pub last_completed: Option<Arc<CompletedStep>>,
    pub pause_reason: Option<RuntimePauseReason>,
    /// Advances once per executor BreakpointHit, not per snapshot publication.
    pub breakpoint_sequence: u64,
    /// The most recently published Debug boundary for this run. `None` means
    /// that this run has not published debug data, which is the defined state
    /// for Normal playback, including a manually paused Normal run.
    pub debug_snapshot: Option<Arc<DebugSnapshot>>,
    /// The last immutable runtime-variable map published by a Debug event.
    /// This remains empty for Normal playback and is runtime-only.
    pub debug_variables: Arc<BTreeMap<String, MkValue>>,
    /// Step associated with `debug_variables`, if the Debug event had one.
    pub debug_variables_step_id: Option<u64>,
    /// Reason associated with `debug_variables`, if a Debug event was seen.
    pub debug_snapshot_reason: Option<DebugSnapshotReason>,
    /// True when this Debug run can access clipboard text and therefore hides
    /// value maps from the Runtime Inspector. Status and call-stack metadata
    /// remain available.
    pub debug_values_redacted: bool,
    /// Root-only projection of the last terminal step. A skipped step is not
    /// considered completed because it did not execute.
    pub last_completed_step_id: Option<u64>,
    pub completed_steps: usize,
    pub total_steps: usize,
    pub started_at: Option<SystemTime>,
    pub finished_at: Option<SystemTime>,
    pub latest_failure: Option<ExecutionDiagnostic>,
    /// Legacy root-only projections of the authoritative compound maps above.
    pub failures: Arc<BTreeMap<DiagnosticKey, ExecutionDiagnostic>>,
    pub steps: Arc<BTreeMap<u64, StepState>>,
    pub step_outcomes: Arc<BTreeMap<u64, StepOutcome>>,
    pub revision: u64,
}
impl Default for RuntimeSnapshot {
    fn default() -> Self {
        Self {
            state: RuntimeState::Idle,
            run_mode: RuntimeRunMode::Normal,
            run_id: 0,
            origin: RuntimeOrigin::Stored,
            macro_id: None,
            root_macro_name: None,
            step_id: None,
            call_stack: Arc::new(Vec::new()),
            macro_steps: Arc::new(BTreeMap::new()),
            macro_step_outcomes: Arc::new(BTreeMap::new()),
            macro_failures: Arc::new(BTreeMap::new()),
            last_completed: None,
            pause_reason: None,
            breakpoint_sequence: 0,
            debug_snapshot: None,
            debug_variables: Arc::new(BTreeMap::new()),
            debug_variables_step_id: None,
            debug_snapshot_reason: None,
            debug_values_redacted: false,
            last_completed_step_id: None,
            completed_steps: 0,
            total_steps: 0,
            started_at: None,
            finished_at: None,
            latest_failure: None,
            failures: Arc::new(BTreeMap::new()),
            steps: Arc::new(BTreeMap::new()),
            step_outcomes: Arc::new(BTreeMap::new()),
            revision: 0,
        }
    }
}
impl RuntimeSnapshot {
    pub fn active_frame(&self) -> Option<ExecutionFrameContext> {
        self.call_stack.last().map(|frame| frame.context)
    }
    pub fn active_macro_id(&self) -> Option<u64> {
        self.active_frame().map(|frame| frame.macro_id)
    }
    pub fn active_step_id(&self) -> Option<u64> {
        self.call_stack
            .last()
            .and_then(|frame| frame.active_step_id)
    }
    pub fn breakpoint_occurrence(&self) -> Option<BreakpointOccurrence> {
        match (self.state, self.pause_reason) {
            (RuntimeState::Paused, Some(RuntimePauseReason::Breakpoint { step_id, frame })) => {
                Some(BreakpointOccurrence {
                    run_id: self.run_id,
                    occurrence: self.breakpoint_sequence,
                    frame_id: frame.frame_id,
                    step: MacroStepKey::new(frame.macro_id, step_id),
                })
            }
            _ => None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CommandResult {
    Accepted,
    AlreadyRunning { active_macro_id: u64 },
    Rejected(ExecutionDiagnostic),
}

/// One terminal result for a runtime run admitted by a caller that owns its
/// completion lifecycle. Started and queued states are deliberately absent.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct OwnedMacroRunCompletion {
    pub run_id: u64,
    pub macro_id: u64,
    pub state: RuntimeState,
    pub failure_kind: Option<DiagnosticKind>,
}

/// Handle for one exact admitted run. Cancellation compares the ID and latches
/// Stop under the same admission lock used by new runs.
pub(crate) struct OwnedMacroRun {
    runtime: Arc<MacroRuntime>,
    run_id: u64,
    start_gate: Arc<OwnedRunStartGate>,
    completion: mpsc::Receiver<OwnedMacroRunCompletion>,
}

impl OwnedMacroRun {
    pub(crate) fn run_id(&self) -> u64 {
        self.run_id
    }

    pub(crate) fn try_completion(
        &self,
    ) -> Result<Option<OwnedMacroRunCompletion>, mpsc::TryRecvError> {
        match self.completion.try_recv() {
            Ok(completion) if completion.run_id == self.run_id => Ok(Some(completion)),
            Ok(_) => Err(mpsc::TryRecvError::Disconnected),
            Err(error) => Err(error),
        }
    }

    pub(crate) fn wait_completion(
        &self,
        timeout: std::time::Duration,
    ) -> Result<OwnedMacroRunCompletion, mpsc::RecvTimeoutError> {
        let completion = self.completion.recv_timeout(timeout)?;
        if completion.run_id == self.run_id {
            Ok(completion)
        } else {
            Err(mpsc::RecvTimeoutError::Disconnected)
        }
    }

    pub(crate) fn stop_if_current(&self) -> bool {
        self.runtime.stop_if_current(self.run_id)
    }

    /// Atomically choose whether this pending run may begin effects. A token
    /// already cancelled at this boundary receives a terminal Stopped result
    /// without entering the macro executor.
    pub(crate) fn activate_if_not_cancelled(
        &self,
        cancellation: &crate::file_operations::ScanCancellation,
    ) -> bool {
        self.runtime
            .activate_owned_if_current(self.run_id, &self.start_gate, cancellation)
    }
}

const OWNED_RUN_PENDING: u8 = 0;
const OWNED_RUN_STARTED: u8 = 1;
const OWNED_RUN_CANCELLED: u8 = 2;

struct OwnedRunStartGate {
    state: AtomicU8,
    lock: Mutex<()>,
    wake: Condvar,
}

impl OwnedRunStartGate {
    fn new() -> Arc<Self> {
        Arc::new(Self {
            state: AtomicU8::new(OWNED_RUN_PENDING),
            lock: Mutex::new(()),
            wake: Condvar::new(),
        })
    }

    fn transition(&self, next: u8) -> bool {
        let _lock = self.lock.lock().unwrap();
        let changed = self
            .state
            .compare_exchange(OWNED_RUN_PENDING, next, Ordering::AcqRel, Ordering::Acquire)
            .is_ok();
        if changed {
            self.wake.notify_all();
        }
        changed
    }

    fn wait_for_start(&self) -> bool {
        let mut lock = self.lock.lock().unwrap();
        loop {
            match self.state.load(Ordering::Acquire) {
                OWNED_RUN_STARTED => return true,
                OWNED_RUN_CANCELLED => return false,
                _ => lock = self.wake.wait(lock).unwrap(),
            }
        }
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InvocationDisposition {
    Submitted,
    AwaitingInput { request_id: u64 },
}

struct Shared {
    snapshot: RwLock<Arc<RuntimeSnapshot>>,
    // Retain the most recently published preview independently from the
    // process-wide presentation snapshot. A later stored run must not erase a
    // Review window's terminal outcome before its next frame observes it.
    last_preview_snapshot: RwLock<Option<Arc<RuntimeSnapshot>>>,
    control: Arc<RunControl>,
    monotonic_clock: Arc<dyn MonotonicClock>,
    summary_history: Mutex<SummaryHistory>,
    admission: Mutex<Option<ActiveAdmission>>,
    activity_center: Mutex<Option<ActivityCenter>>,
    next_run_id: AtomicU64,
    operations: Arc<SharedOperationGuard>,
    #[cfg(test)]
    test_events: Mutex<Vec<ExecutionEvent>>,
    #[cfg(test)]
    test_worker_barrier: Mutex<Option<Arc<TestWorkerBarrierInner>>>,
    #[cfg(test)]
    test_terminal_barrier: Mutex<Option<Arc<TestWorkerBarrierInner>>>,
    #[cfg(test)]
    test_breakpoint_observer: Mutex<Option<Box<dyn FnOnce(&RunControl) + Send>>>,
}
struct ActiveAdmission {
    macro_id: u64,
    origin: RuntimeOrigin,
    run_id: u64,
    owned_start_gate: Option<Arc<OwnedRunStartGate>>,
    activity: Option<ActivityTask>,
    summary: Option<SummaryAccumulator>,
}
struct WorkerMessage {
    command: RuntimeCommand,
    program: Option<super::MkCompiledProgram>,
    origin: RuntimeOrigin,
    run_id: Option<u64>,
    owned_completion: Option<mpsc::SyncSender<OwnedMacroRunCompletion>>,
    owned_start_gate: Option<Arc<OwnedRunStartGate>>,
}
static RUNTIME_GENERATIONS: AtomicU64 = AtomicU64::new(1);
static NEXT_PREVIEW_TICKET: AtomicU64 = AtomicU64::new(1);
pub struct MacroRuntime {
    tx: mpsc::Sender<WorkerMessage>,
    store: Arc<MkMacroStore>,
    generation: u64,
    available: AtomicBool,
    shared: Arc<Shared>,
    worker: Mutex<Option<JoinHandle<()>>>,
    #[cfg(test)]
    test_commands: Mutex<Vec<RuntimeCommand>>,
}

struct HistoryViewLease {
    runtime: Arc<MacroRuntime>,
    charge: usize,
    projection: Option<HistoryProjection>,
}

impl Drop for HistoryViewLease {
    fn drop(&mut self) {
        drop(self.projection.take());
        self.runtime
            .shared
            .summary_history
            .lock()
            .unwrap()
            .release_view(self.charge);
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum HistoryAccessError {
    RuntimeUnavailable,
    Busy,
    Budget,
}

#[cfg(test)]
struct TestWorkerBarrierInner {
    state: Mutex<(bool, bool)>,
    wake: Condvar,
}

#[cfg(test)]
pub(crate) struct TestWorkerBarrier(Arc<TestWorkerBarrierInner>);

#[cfg(test)]
impl TestWorkerBarrier {
    pub(crate) fn wait_until_blocked(&self) {
        let deadline = Instant::now() + Duration::from_secs(10);
        let mut state = self.0.state.lock().unwrap();
        while !state.0 {
            let remaining = deadline.saturating_duration_since(Instant::now());
            assert!(
                !remaining.is_zero(),
                "runtime worker did not reach test barrier"
            );
            let (next, timeout) = self.0.wake.wait_timeout(state, remaining).unwrap();
            state = next;
            assert!(
                !timeout.timed_out() || state.0,
                "runtime worker did not reach test barrier"
            );
        }
    }

    pub(crate) fn release(&self) {
        let mut state = self.0.state.lock().unwrap();
        state.1 = true;
        self.0.wake.notify_all();
    }
}

#[cfg(test)]
impl Drop for TestWorkerBarrier {
    fn drop(&mut self) {
        self.release();
    }
}

#[cfg(test)]
fn install_test_barrier(
    slot: &Mutex<Option<Arc<TestWorkerBarrierInner>>>,
    label: &str,
) -> TestWorkerBarrier {
    let barrier = Arc::new(TestWorkerBarrierInner {
        state: Mutex::new((false, false)),
        wake: Condvar::new(),
    });
    let mut slot = slot.lock().unwrap();
    assert!(slot.is_none(), "{label} test barrier is already installed");
    *slot = Some(barrier.clone());
    TestWorkerBarrier(barrier)
}

#[cfg(test)]
fn wait_on_test_barrier(slot: &Mutex<Option<Arc<TestWorkerBarrierInner>>>) {
    if let Some(barrier) = slot.lock().unwrap().take() {
        let mut state = barrier.state.lock().unwrap();
        state.0 = true;
        barrier.wake.notify_all();
        while !state.1 {
            state = barrier.wake.wait(state).unwrap();
        }
    }
}

impl MacroRuntime {
    pub(crate) fn attach_activity_center(&self, center: ActivityCenter) {
        let mut admission = self.shared.admission.lock().unwrap();
        *self.shared.activity_center.lock().unwrap() = Some(center.clone());
        let Some(active) = admission.as_mut() else {
            return;
        };
        if active.activity.is_some() {
            return;
        }
        let snapshot = self.snapshot();
        let operation = ActivityOperation::PlayMacro;
        let task = if snapshot.run_id == active.run_id
            && matches!(
                snapshot.state,
                RuntimeState::Running | RuntimeState::Paused | RuntimeState::Stopping
            ) {
            center.observe_running(
                ActivityOwner::Macro,
                ActivitySlot::MacroRun,
                ActivityIncarnation::new(self.generation),
                operation,
            )
        } else {
            center.observe_queued(
                ActivityOwner::Macro,
                ActivitySlot::MacroRun,
                ActivityIncarnation::new(self.generation),
                operation,
            )
        };
        if let Some(task) = task {
            if snapshot.state == RuntimeState::Stopping {
                task.mark_cancelling();
            }
            let weak_shared = Arc::downgrade(&self.shared);
            let run_id = active.run_id;
            task.set_cancel_handler(move || {
                if let Some(shared) = weak_shared.upgrade() {
                    stop_shared_run_if_current(&shared, run_id);
                }
            });
            active.activity = Some(task);
        }
    }

    fn ensure_available(&self) -> ExecResult {
        let admission = self.shared.admission.lock().unwrap();
        if !self.available.load(Ordering::Acquire) {
            return Err(ExecutionDiagnostic::new(
                DiagnosticKind::RuntimeUnavailable,
                "The macro runtime was replaced or closed",
            ));
        }
        if let Some(active) = admission.as_ref() {
            return Err(ExecutionDiagnostic::new(
                DiagnosticKind::RuntimeUnavailable,
                format!("Macro {} is already running", active.macro_id),
            ));
        }
        if self.shared.operations.active(Operation::Recording) {
            return Err(ExecutionDiagnostic::new(
                DiagnosticKind::InvalidTarget,
                "recording is active",
            ));
        }
        Ok(())
    }
    /// Direct callers prepare on their own thread, without reserving a worker
    /// while the user considers input. Final submission retains atomic admission.
    pub fn prepare_invocation(
        self: &Arc<Self>,
        invocation: MkInvocation,
        broker: &Arc<super::invocation_prompt::InvocationPromptBroker>,
    ) -> ExecResult<InvocationDisposition> {
        self.prepare_direct_command(
            RuntimeCommand::Invoke(invocation),
            broker,
            InvocationSource::UnclassifiedApi,
        )
    }

    pub fn prepare_invocation_with_source(
        self: &Arc<Self>,
        invocation: MkInvocation,
        broker: &Arc<super::invocation_prompt::InvocationPromptBroker>,
        source: InvocationSource,
    ) -> ExecResult<InvocationDisposition> {
        self.prepare_direct_command(RuntimeCommand::Invoke(invocation), broker, source)
    }
    fn prepare_direct_command(
        self: &Arc<Self>,
        command: RuntimeCommand,
        broker: &Arc<super::invocation_prompt::InvocationPromptBroker>,
        invocation_source: InvocationSource,
    ) -> ExecResult<InvocationDisposition> {
        self.ensure_available()?;
        broker.ensure_idle()?;
        let request = run_request(&command).ok_or_else(|| {
            ExecutionDiagnostic::new(
                DiagnosticKind::InvalidTarget,
                "Expected a direct invocation",
            )
        })?;
        let mut invocation = request.to_invocation();
        let document = self.store.snapshot();
        let program = super::invocation::compile_invocation_program(&document, &invocation)?;
        let target = document
            .macros
            .iter()
            .find(|m| m.id == invocation.macro_id)
            .ok_or_else(|| {
                ExecutionDiagnostic::new(DiagnosticKind::TargetNotFound, "Macro was not found")
            })?;
        let prepared = super::prepare_parameters(
            &target.signature.parameters,
            &target.signature.outputs,
            &invocation.arguments,
        )?;
        if !prepared.missing.is_empty() {
            let request_id = broker.enqueue(
                self,
                super::invocation_prompt::InvocationPromptRequest {
                    id: 0,
                    runtime_generation: self.generation,
                    invocation,
                    macro_name: target.name.clone(),
                    macro_description: target.description.clone(),
                    parameters: target.signature.parameters.clone(),
                    prepared_values: prepared.values,
                    invocation_source,
                },
            )?;
            return Ok(InvocationDisposition::AwaitingInput { request_id });
        }
        invocation.arguments = prepared.values;
        // Keep the existing empty-argument command contract for compatibility.
        let command = if invocation.arguments.is_empty() {
            command
        } else {
            RuntimeCommand::Invoke(invocation)
        };
        command_result(self.submit_command_with_source(command, Some(program), invocation_source))?;
        Ok(InvocationDisposition::Submitted)
    }
    pub(crate) fn confirm_invocation(
        &self,
        request: &super::invocation_prompt::InvocationPromptRequest,
        values: MkInvocationValues,
    ) -> ExecResult {
        self.ensure_available()?;
        if request.runtime_generation != self.generation {
            return Err(ExecutionDiagnostic::new(
                DiagnosticKind::RuntimeUnavailable,
                "The macro runtime changed while input was pending",
            ));
        }
        let mut invocation = request.invocation.clone();
        invocation.arguments = values;
        let document = self.store.snapshot();
        let program = super::invocation::compile_invocation_program(&document, &invocation)?;
        let plan = program.plan(invocation.macro_id).ok_or_else(|| {
            ExecutionDiagnostic::new(DiagnosticKind::InvalidPlan, "Program root is missing")
        })?;
        super::invocation::validate_parameter_assumptions(
            &request.parameters,
            plan.signature.parameters(),
        )?;
        let prepared = super::prepare_parameters(
            plan.signature.parameters(),
            plan.signature.outputs(),
            &invocation.arguments,
        )?;
        // The shared preparation boundary owns missing/type errors, including
        // callers outside egui that submit an incomplete response.
        prepared
            .clone()
            .into_variables(plan.signature.parameters())?;
        invocation.arguments = prepared.values;
        command_result(self.submit_command_with_source(
            RuntimeCommand::Invoke(invocation),
            Some(program),
            request.invocation_source,
        ))
    }
    pub fn new(store: Arc<MkMacroStore>, backends: Backends) -> Self {
        Self::with_guard(store, backends, Arc::new(SharedOperationGuard::default()))
    }
    fn with_guard(
        store: Arc<MkMacroStore>,
        backends: Backends,
        operations: Arc<SharedOperationGuard>,
    ) -> Self {
        Self::with_guard_and_clock(
            store,
            backends,
            operations,
            Arc::new(SystemMonotonicClock::new()),
        )
    }
    fn with_guard_and_clock(
        store: Arc<MkMacroStore>,
        backends: Backends,
        operations: Arc<SharedOperationGuard>,
        monotonic_clock: Arc<dyn MonotonicClock>,
    ) -> Self {
        let (tx, rx) = mpsc::channel();
        let shared = Arc::new(Shared {
            snapshot: RwLock::new(Arc::new(RuntimeSnapshot::default())),
            last_preview_snapshot: RwLock::new(None),
            control: Arc::new(RunControl::default()),
            monotonic_clock,
            summary_history: Mutex::new(SummaryHistory::new()),
            admission: Mutex::new(None),
            activity_center: Mutex::new(None),
            next_run_id: AtomicU64::new(1),
            operations,
            #[cfg(test)]
            test_events: Mutex::new(Vec::new()),
            #[cfg(test)]
            test_worker_barrier: Mutex::new(None),
            #[cfg(test)]
            test_terminal_barrier: Mutex::new(None),
            #[cfg(test)]
            test_breakpoint_observer: Mutex::new(None),
        });
        let s = shared.clone();
        let worker_store = store.clone();
        let worker = thread::Builder::new()
            .name("mkmacro-runtime".into())
            .spawn(move || worker_loop(worker_store, backends, rx, s))
            .expect("spawn macro runtime");
        Self {
            tx,
            store,
            generation: RUNTIME_GENERATIONS.fetch_add(1, Ordering::Relaxed),
            available: AtomicBool::new(true),
            shared,
            worker: Mutex::new(Some(worker)),
            #[cfg(test)]
            test_commands: Mutex::new(Vec::new()),
        }
    }
    pub fn command(&self, c: RuntimeCommand) -> CommandResult {
        self.submit_command(c, None)
    }
    pub fn preview(
        &self,
        document: &super::MkMacroDocument,
        macro_id: u64,
        ticket: u64,
    ) -> ExecResult {
        self.ensure_available()?;
        let program = super::compile_program(document, macro_id).map_err(|diagnostics| {
            let message = diagnostics
                .iter()
                .map(|diagnostic| diagnostic.message.as_str())
                .collect::<Vec<_>>()
                .join("; ");
            ExecutionDiagnostic::new(DiagnosticKind::InvalidPlan, message)
        })?;
        command_result(self.submit_command_with_source(
            RuntimeCommand::RecordingPreview { macro_id, ticket },
            Some(program),
            InvocationSource::RecordingPreview,
        ))
    }
    fn submit_command(
        &self,
        c: RuntimeCommand,
        program: Option<super::MkCompiledProgram>,
    ) -> CommandResult {
        self.submit_command_with_source(c, program, InvocationSource::UnclassifiedApi)
    }

    fn submit_command_with_source(
        &self,
        c: RuntimeCommand,
        program: Option<super::MkCompiledProgram>,
        invocation_source: InvocationSource,
    ) -> CommandResult {
        self.submit_command_with_owner(c, program, None, None, None, invocation_source)
            .0
    }

    fn submit_command_with_owner(
        &self,
        c: RuntimeCommand,
        program: Option<super::MkCompiledProgram>,
        expected_macros: Option<Vec<super::MkMacro>>,
        owned_completion: Option<mpsc::SyncSender<OwnedMacroRunCompletion>>,
        owned_start_gate: Option<Arc<OwnedRunStartGate>>,
        invocation_source: InvocationSource,
    ) -> (CommandResult, Option<u64>) {
        #[cfg(test)]
        self.test_commands.lock().unwrap().push(c.clone());
        let request = run_request(&c);
        if matches!(&c, RuntimeCommand::RecordingPreview { .. }) && program.is_none() {
            return (
                CommandResult::Rejected(ExecutionDiagnostic::new(
                    DiagnosticKind::InvalidPlan,
                    "recording preview requires an ephemeral compiled program",
                )),
                None,
            );
        }
        if request.is_some_and(|request| request.selection.is_some_and(<[u64]>::is_empty)) {
            return (
                CommandResult::Rejected(ExecutionDiagnostic::new(
                    DiagnosticKind::InvalidSelection,
                    "selection is empty",
                )),
                None,
            );
        }
        // Admission serializes terminal publication with control commands and
        // new-run claims. Lock order is admission -> control/snapshot/operations.
        let mut admission = self.shared.admission.lock().unwrap();
        if !self.available.load(Ordering::Acquire) {
            return (
                CommandResult::Rejected(ExecutionDiagnostic::new(
                    DiagnosticKind::RuntimeUnavailable,
                    "macro worker is shut down",
                )),
                None,
            );
        }
        if request.is_some()
            && let Some(active) = admission.as_ref()
        {
            return (
                CommandResult::AlreadyRunning {
                    active_macro_id: active.macro_id,
                },
                None,
            );
        }
        if let Some(expected_macros) = expected_macros.as_ref() {
            let current = self.store.snapshot();
            for expected in expected_macros {
                let mut matching = current
                    .macros
                    .iter()
                    .filter(|macro_| macro_.id == expected.id);
                if matching.next() != Some(expected) || matching.next().is_some() {
                    return (
                        CommandResult::Rejected(ExecutionDiagnostic::new(
                            DiagnosticKind::InvalidTarget,
                            "macro configuration changed before admission",
                        )),
                        None,
                    );
                }
            }
        }
        let active = admission.is_some();
        let state = self.snapshot().state;
        let stopped = self.shared.control.is_stopped();
        let wrong_state = match &c {
            RuntimeCommand::Pause => !active || stopped || state == RuntimeState::Paused,
            RuntimeCommand::Resume => !active || stopped || state != RuntimeState::Paused,
            RuntimeCommand::Stop => !active,
            _ => false,
        };
        if wrong_state {
            return (
                CommandResult::Rejected(ExecutionDiagnostic::new(
                    DiagnosticKind::InvalidTarget,
                    format!("command {c:?} is not valid while runtime is {state:?}"),
                )),
                None,
            );
        }
        let mut run_id = None;
        if let Some(request) = request {
            if !self.shared.operations.claim(Operation::Playback) {
                return (
                    CommandResult::Rejected(ExecutionDiagnostic::new(
                        DiagnosticKind::InvalidTarget,
                        "recording is active",
                    )),
                    None,
                );
            }
            let admitted_run_id = self.shared.next_run_id.fetch_add(1, Ordering::Relaxed);
            let origin = match &c {
                RuntimeCommand::RecordingPreview { ticket, .. } => {
                    RuntimeOrigin::RecordingPreview { ticket: *ticket }
                }
                _ => RuntimeOrigin::Stored,
            };
            let document = self.store.snapshot();
            let macro_name = program
                .as_ref()
                .and_then(|program| program.name(request.macro_id))
                .or_else(|| {
                    document
                        .macros
                        .iter()
                        .find(|macro_| macro_.id == request.macro_id)
                        .map(|macro_| macro_.name.as_str())
                });
            let summary = self.shared.summary_history.lock().unwrap().begin(
                admitted_run_id,
                request.macro_id,
                macro_name,
                invocation_source,
                origin,
                request.mode,
                request.summary_subset(),
                self.shared.monotonic_clock.clone(),
            );
            let Some(summary) = summary else {
                self.shared.operations.release(Operation::Playback);
                return (
                    CommandResult::Rejected(ExecutionDiagnostic::new(
                        DiagnosticKind::RuntimeUnavailable,
                        "run summary capacity is unavailable",
                    )),
                    None,
                );
            };
            self.shared
                .control
                .reset_with_clock(self.shared.monotonic_clock.clone());
            let activity = self
                .shared
                .activity_center
                .lock()
                .unwrap()
                .as_ref()
                .and_then(|center| {
                    center.start(
                        ActivityOwner::Macro,
                        ActivitySlot::MacroRun,
                        ActivityIncarnation::new(self.generation),
                        ActivityOperation::PlayMacro,
                    )
                });
            if let Some(activity) = &activity {
                let weak_shared = Arc::downgrade(&self.shared);
                activity.set_cancel_handler(move || {
                    if let Some(shared) = weak_shared.upgrade() {
                        stop_shared_run_if_current(&shared, admitted_run_id);
                    }
                });
            }
            *admission = Some(ActiveAdmission {
                macro_id: request.macro_id,
                origin,
                run_id: admitted_run_id,
                owned_start_gate: owned_start_gate.clone(),
                activity,
                summary: Some(summary),
            });
            run_id = Some(admitted_run_id);
        }
        match c {
            RuntimeCommand::Pause => {
                self.shared.control.pause();
                if admission.is_some() {
                    publish_manual_pause(&self.shared);
                }
            }
            RuntimeCommand::Resume => {
                self.shared.control.resume();
                if admission.is_some() {
                    publish(&self.shared, |snapshot| {
                        snapshot.state = RuntimeState::Running;
                        snapshot.pause_reason = None;
                    });
                }
            }
            RuntimeCommand::Stop => {
                if let Some(gate) = admission
                    .as_ref()
                    .and_then(|active| active.owned_start_gate.as_ref())
                {
                    gate.transition(OWNED_RUN_CANCELLED);
                }
                self.shared.control.stop();
                if admission.is_some() {
                    publish(&self.shared, |snapshot| {
                        snapshot.state = RuntimeState::Stopping;
                        snapshot.pause_reason = None;
                    });
                }
            }
            _ => {}
        }
        if self
            .tx
            .send(WorkerMessage {
                origin: match &c {
                    RuntimeCommand::RecordingPreview { ticket, .. } => {
                        RuntimeOrigin::RecordingPreview { ticket: *ticket }
                    }
                    _ => RuntimeOrigin::Stored,
                },
                command: c,
                program,
                run_id,
                owned_completion,
                owned_start_gate,
            })
            .is_err()
        {
            if let Some(activity) = admission
                .as_ref()
                .and_then(|active| active.activity.as_ref())
            {
                activity.finish(
                    ActivityOutcome::Failed,
                    Some(ActivityDiagnostic::WorkerUnavailable),
                    ActivityRetirement::Confirmed,
                );
            }
            self.shared.control.finish();
            self.shared.operations.release(Operation::Playback);
            if let Some(active) = admission.as_mut()
                && let Some(summary) = active.summary.take()
            {
                self.shared.summary_history.lock().unwrap().abort(summary);
            }
            *admission = None;
            return (
                CommandResult::Rejected(ExecutionDiagnostic::new(
                    DiagnosticKind::RuntimeUnavailable,
                    "macro worker is shut down",
                )),
                None,
            );
        }
        (CommandResult::Accepted, run_id)
    }
    /// Idempotently cancel one admitted recording preview. The comparison and
    /// Stop latch share the admission lock, so a stale Review can neither miss
    /// an accepted-but-unpublished preview nor stop a later stored run.
    pub fn stop_recording_preview(&self, ticket: u64) -> bool {
        let admission = self.shared.admission.lock().unwrap();
        if !admission
            .as_ref()
            .is_some_and(|active| active.origin == RuntimeOrigin::RecordingPreview { ticket })
        {
            return false;
        }
        self.shared.control.stop();
        let snapshot = self.snapshot();
        if snapshot.origin == (RuntimeOrigin::RecordingPreview { ticket })
            && matches!(snapshot.state, RuntimeState::Running | RuntimeState::Paused)
        {
            publish(&self.shared, |snapshot| {
                snapshot.state = RuntimeState::Stopping;
                snapshot.pause_reason = None;
            });
        }
        true
    }

    /// Stop only the run whose ID is still admitted. The ID comparison and
    /// Stop latch are atomic with respect to admission of another run.
    fn stop_if_current(&self, run_id: u64) -> bool {
        stop_shared_run_if_current(&self.shared, run_id)
    }

    fn activate_owned_if_current(
        &self,
        run_id: u64,
        gate: &OwnedRunStartGate,
        cancellation: &crate::file_operations::ScanCancellation,
    ) -> bool {
        let admission = self.shared.admission.lock().unwrap();
        if !admission.as_ref().is_some_and(|active| {
            active.run_id == run_id
                && active
                    .owned_start_gate
                    .as_ref()
                    .is_some_and(|current| std::ptr::eq(current.as_ref(), gate))
        }) {
            return false;
        }
        if cancellation.is_cancelled() {
            gate.transition(OWNED_RUN_CANCELLED);
            self.shared.control.stop();
            return false;
        }
        gate.transition(OWNED_RUN_STARTED)
    }

    fn is_available(&self) -> bool {
        self.available.load(Ordering::Acquire)
    }

    fn start_owned_hotfolder_macro(
        self: &Arc<Self>,
        expected_macro: &super::MkMacro,
        expected_dependencies: &[super::MkMacro],
    ) -> ExecResult<OwnedMacroRun> {
        let document = self.store.snapshot();
        let mut matching = document
            .macros
            .iter()
            .filter(|macro_| macro_.id == expected_macro.id);
        if matching.next() != Some(expected_macro) || matching.next().is_some() {
            return Err(ExecutionDiagnostic::new(
                DiagnosticKind::InvalidTarget,
                "macro configuration changed before execution",
            ));
        }

        let mut invocation = MkInvocation::new(expected_macro.id);
        let program = super::invocation::compile_invocation_program(&document, &invocation)?;
        let plan = program.plan(expected_macro.id).ok_or_else(|| {
            ExecutionDiagnostic::new(DiagnosticKind::InvalidPlan, "Macro program root is missing")
        })?;
        let prepared = super::prepare_parameters(
            plan.signature.parameters(),
            plan.signature.outputs(),
            &invocation.arguments,
        )?;
        if !prepared.missing.is_empty() {
            return Err(ExecutionDiagnostic::new(
                DiagnosticKind::InvalidTarget,
                "macro requires invocation input that unattended execution cannot provide",
            ));
        }
        invocation.arguments = prepared.values;
        let mut expected_macros = Vec::with_capacity(program.macro_ids().len());
        for macro_id in program.macro_ids() {
            let mut matching = document
                .macros
                .iter()
                .filter(|macro_| macro_.id == *macro_id);
            let Some(macro_) = matching.next() else {
                return Err(ExecutionDiagnostic::new(
                    DiagnosticKind::InvalidPlan,
                    "macro dependency disappeared during compilation",
                ));
            };
            if matching.next().is_some() {
                return Err(ExecutionDiagnostic::new(
                    DiagnosticKind::InvalidPlan,
                    "macro dependency is ambiguous during compilation",
                ));
            }
            expected_macros.push(macro_.clone());
        }
        if expected_macros != expected_dependencies {
            return Err(ExecutionDiagnostic::new(
                DiagnosticKind::InvalidTarget,
                "macro dependency closure changed after Hot Folder validation",
            ));
        }

        let (completion_tx, completion_rx) = mpsc::sync_channel(1);
        let start_gate = OwnedRunStartGate::new();
        let (result, run_id) = self.submit_command_with_owner(
            RuntimeCommand::Invoke(invocation),
            Some(program),
            Some(expected_macros),
            Some(completion_tx),
            Some(start_gate.clone()),
            InvocationSource::HotFolder,
        );
        let run_id = match result {
            CommandResult::Accepted => run_id.ok_or_else(|| {
                ExecutionDiagnostic::new(
                    DiagnosticKind::RuntimeUnavailable,
                    "macro worker accepted a run without an admission ID",
                )
            })?,
            CommandResult::AlreadyRunning { .. } => {
                return Err(ExecutionDiagnostic::new(
                    DiagnosticKind::RuntimeUnavailable,
                    "macro runtime is busy with another run",
                ));
            }
            CommandResult::Rejected(diagnostic) => return Err(diagnostic),
        };
        Ok(OwnedMacroRun {
            runtime: self.clone(),
            run_id,
            start_gate,
            completion: completion_rx,
        })
    }
    pub fn snapshot(&self) -> Arc<RuntimeSnapshot> {
        self.shared.snapshot.read().unwrap().clone()
    }

    /// Inspect completed metadata while the bounded history lock is held.
    /// The callback cannot retain record references past this call.
    pub fn with_run_summaries<R>(
        &self,
        inspect: impl FnOnce(u64, &std::collections::VecDeque<MacroRunSummary>) -> R,
    ) -> R {
        self.shared
            .summary_history
            .lock()
            .unwrap()
            .with_completed(inspect)
    }

    fn with_history_view<R>(
        self: &Arc<Self>,
        request: HistoryViewRequest,
        inspect: impl FnOnce(&HistoryProjection) -> R,
    ) -> Result<R, HistoryViewError> {
        let (projection, charge) = self
            .shared
            .summary_history
            .lock()
            .unwrap()
            .reserve_view(self.generation, request)?;
        let lease = HistoryViewLease {
            runtime: self.clone(),
            charge,
            projection: Some(projection),
        };
        debug_assert_eq!(charge, std::mem::size_of::<HistoryViewLease>());
        let result = inspect(lease.projection.as_ref().unwrap());
        drop(lease);
        Ok(result)
    }

    fn clear_completed_history(&self) -> Result<(), HistoryViewError> {
        if self
            .shared
            .summary_history
            .lock()
            .unwrap()
            .clear_completed()
        {
            Ok(())
        } else {
            Err(HistoryViewError::Busy)
        }
    }

    #[cfg(test)]
    fn history_view_bytes(&self) -> usize {
        self.shared.summary_history.lock().unwrap().view_bytes()
    }
    pub fn recording_preview_status(&self, ticket: u64) -> (bool, Option<Arc<RuntimeSnapshot>>) {
        let active = self
            .shared
            .admission
            .lock()
            .unwrap()
            .as_ref()
            .is_some_and(|admission| {
                admission.origin == RuntimeOrigin::RecordingPreview { ticket }
            });
        let snapshot = self
            .shared
            .last_preview_snapshot
            .read()
            .unwrap()
            .as_ref()
            .filter(|snapshot| snapshot.origin == RuntimeOrigin::RecordingPreview { ticket })
            .cloned();
        (active, snapshot)
    }
    #[cfg(test)]
    pub(crate) fn take_test_commands(&self) -> Vec<RuntimeCommand> {
        std::mem::take(&mut *self.test_commands.lock().unwrap())
    }
    #[cfg(test)]
    pub(crate) fn take_test_events(&self) -> Vec<ExecutionEvent> {
        std::mem::take(&mut *self.shared.test_events.lock().unwrap())
    }
    #[cfg(test)]
    pub(crate) fn install_test_worker_barrier(&self) -> TestWorkerBarrier {
        install_test_barrier(&self.shared.test_worker_barrier, "runtime worker")
    }
    #[cfg(test)]
    fn install_test_terminal_barrier(&self) -> TestWorkerBarrier {
        install_test_barrier(&self.shared.test_terminal_barrier, "runtime terminal")
    }
    #[cfg(test)]
    fn install_test_breakpoint_observer(
        &self,
        observer: impl FnOnce(&RunControl) + Send + 'static,
    ) {
        let mut slot = self.shared.test_breakpoint_observer.lock().unwrap();
        assert!(
            slot.is_none(),
            "breakpoint observer test hook already installed"
        );
        *slot = Some(Box::new(observer));
    }
    pub fn shutdown(&self) {
        {
            let admission = self.shared.admission.lock().unwrap();
            self.available.store(false, Ordering::Release);
            if let Some(gate) = admission
                .as_ref()
                .and_then(|active| active.owned_start_gate.as_ref())
            {
                gate.transition(OWNED_RUN_CANCELLED);
            }
            self.shared.control.stop();
            let _ = self.tx.send(WorkerMessage {
                command: RuntimeCommand::Shutdown,
                program: None,
                origin: RuntimeOrigin::Stored,
                run_id: None,
                owned_completion: None,
                owned_start_gate: None,
            });
        }
        if let Some(h) = self.worker.lock().unwrap().take() {
            let _ = h.join();
        }
    }
}
impl Drop for MacroRuntime {
    fn drop(&mut self) {
        self.shutdown()
    }
}

fn publish(shared: &Shared, f: impl FnOnce(&mut RuntimeSnapshot)) {
    // One owner serializes the transformation, not just the final replacement.
    // Callers must acquire admission/control before entering this boundary.
    let mut current = shared.snapshot.write().unwrap();
    let next = Arc::make_mut(&mut current);
    f(next);
    crate::hotkey::launcher_invocation::set_exclusive_owner(
        crate::hotkey::launcher_invocation::ExclusiveOwner::MacroPlayback,
        matches!(
            next.state,
            RuntimeState::Running | RuntimeState::Paused | RuntimeState::Stopping
        ),
    );
    next.revision += 1;
    if matches!(next.origin, RuntimeOrigin::RecordingPreview { .. }) {
        *shared.last_preview_snapshot.write().unwrap() = Some(current.clone());
    }
}

fn controlled_state(control: &RunControl) -> RuntimeState {
    if control.is_stopped() {
        RuntimeState::Stopping
    } else if control.is_paused() {
        RuntimeState::Paused
    } else {
        RuntimeState::Running
    }
}

fn terminal_classification(result: &ExecResult, stopped: bool) -> (RuntimeState, SummaryOutcome) {
    match result {
        Ok(()) if stopped => (RuntimeState::Stopped, SummaryOutcome::Stopped),
        Ok(()) => (RuntimeState::Completed, SummaryOutcome::Completed),
        Err(diagnostic) if diagnostic.kind == DiagnosticKind::Cancelled => {
            (RuntimeState::Stopped, SummaryOutcome::Stopped)
        }
        Err(diagnostic) => (
            RuntimeState::Failed,
            SummaryOutcome::Failed(diagnostic.kind),
        ),
    }
}

fn frame_name(snapshot: &RuntimeSnapshot, context: ExecutionFrameContext) -> Arc<str> {
    snapshot
        .call_stack
        .last()
        .filter(|frame| frame.context == context)
        .map(|frame| frame.macro_name.clone())
        .unwrap_or_else(|| Arc::from(format!("Macro #{}", context.macro_id)))
}

fn clear_debug_variables(snapshot: &mut RuntimeSnapshot) {
    if snapshot.debug_snapshot.is_none()
        && snapshot.debug_variables.is_empty()
        && snapshot.debug_variables_step_id.is_none()
        && snapshot.debug_snapshot_reason.is_none()
    {
        return;
    }
    snapshot.debug_snapshot = None;
    snapshot.debug_variables = Arc::new(BTreeMap::new());
    snapshot.debug_variables_step_id = None;
    snapshot.debug_snapshot_reason = None;
}

fn publish_debug_variables(
    snapshot: &mut RuntimeSnapshot,
    frame: ExecutionFrameContext,
    step_id: Option<u64>,
    variables: RuntimeVariables,
    reason: DebugSnapshotReason,
) {
    let variables = Arc::new(variables);
    snapshot.debug_snapshot = Some(Arc::new(DebugSnapshot {
        frame,
        macro_name: frame_name(snapshot, frame),
        step_id,
        variables: variables.clone(),
        reason,
    }));
    snapshot.debug_variables = variables;
    snapshot.debug_variables_step_id = step_id;
    snapshot.debug_snapshot_reason = Some(reason);
}

fn set_step_state(
    snapshot: &mut RuntimeSnapshot,
    frame: ExecutionFrameContext,
    step_id: u64,
    state: StepState,
) {
    Arc::make_mut(&mut snapshot.macro_steps)
        .insert(MacroStepKey::new(frame.macro_id, step_id), state);
    if frame.depth == 1 {
        Arc::make_mut(&mut snapshot.steps).insert(step_id, state);
    }
}

fn set_active_step(snapshot: &mut RuntimeSnapshot, context: ExecutionFrameContext, step_id: u64) {
    if let Some(frame) = snapshot.call_stack.last()
        && frame.context == context
        && frame.active_step_id != Some(step_id)
    {
        Arc::make_mut(&mut snapshot.call_stack)
            .last_mut()
            .unwrap()
            .active_step_id = Some(step_id);
    }
    if context.depth == 1 {
        snapshot.step_id = Some(step_id);
    }
}

fn complete_step(
    snapshot: &mut RuntimeSnapshot,
    context: ExecutionFrameContext,
    step_id: u64,
    outcome: CompletedStepOutcome,
) {
    snapshot.last_completed = Some(Arc::new(CompletedStep {
        frame: context,
        key: MacroStepKey::new(context.macro_id, step_id),
        macro_name: frame_name(snapshot, context),
        outcome,
    }));
    if context.depth == 1 {
        snapshot.last_completed_step_id = Some(step_id);
    }
}

fn apply_execution_event(
    snapshot: &mut RuntimeSnapshot,
    program: &super::MkCompiledProgram,
    context: ExecutionFrameContext,
    event: ExecutionEvent,
    control_state: RuntimeState,
) {
    snapshot.state = control_state;
    if control_state != RuntimeState::Paused {
        snapshot.pause_reason = None;
    } else if snapshot.pause_reason.is_none() {
        snapshot.pause_reason = Some(RuntimePauseReason::User);
    }
    match event {
        ExecutionEvent::FrameEntered(frame) => {
            if context.depth == 1 {
                snapshot.root_macro_name = Some(frame.macro_name.clone());
            }
            Arc::make_mut(&mut snapshot.call_stack).push(frame);
            clear_debug_variables(snapshot);
            // Only frame entry consults the immutable program. Repeated calls
            // reset current row state without altering the last completed record.
            if let Some(plan) = program.plan(context.macro_id) {
                Arc::make_mut(&mut snapshot.macro_steps)
                    .retain(|key, _| key.macro_id != context.macro_id);
                Arc::make_mut(&mut snapshot.macro_step_outcomes)
                    .retain(|key, _| key.macro_id != context.macro_id);
                Arc::make_mut(&mut snapshot.macro_failures)
                    .retain(|key, _| key.step.macro_id != context.macro_id);
                for instruction in plan.instructions.iter() {
                    set_step_state(
                        snapshot,
                        context,
                        instruction.step.id,
                        if instruction.step.enabled {
                            StepState::Pending
                        } else {
                            StepState::Skipped
                        },
                    );
                }
            }
        }
        ExecutionEvent::FrameExited { caller_boundary } => {
            if snapshot
                .call_stack
                .last()
                .is_some_and(|frame| frame.context == context)
            {
                Arc::make_mut(&mut snapshot.call_stack).pop();
            }
            if let Some(caller) = snapshot.active_frame() {
                if caller.depth == 1 {
                    snapshot.step_id = snapshot.active_step_id();
                }
                if let Some(boundary) = caller_boundary {
                    publish_debug_variables(
                        snapshot,
                        caller,
                        boundary.step_id,
                        boundary.variables,
                        DebugSnapshotReason::FrameRestored,
                    );
                } else {
                    clear_debug_variables(snapshot);
                }
            }
        }
        ExecutionEvent::BreakpointHit { step_id, variables } => {
            snapshot.breakpoint_sequence += 1;
            set_active_step(snapshot, context, step_id);
            set_step_state(snapshot, context, step_id, StepState::Pending);
            if control_state == RuntimeState::Paused {
                snapshot.pause_reason = Some(RuntimePauseReason::Breakpoint {
                    step_id,
                    frame: context,
                });
            }
            publish_debug_variables(
                snapshot,
                context,
                Some(step_id),
                variables,
                DebugSnapshotReason::Breakpoint,
            );
        }
        ExecutionEvent::DebugVariables {
            step_id,
            variables,
            reason,
        } => {
            publish_debug_variables(snapshot, context, step_id, variables, reason);
        }
        ExecutionEvent::StepStarted(step_id) => {
            set_active_step(snapshot, context, step_id);
            set_step_state(snapshot, context, step_id, StepState::Running);
        }
        ExecutionEvent::StepFinished(step_id) => {
            set_step_state(snapshot, context, step_id, StepState::Success);
            if context.depth == 1 {
                snapshot.completed_steps += 1;
            }
            let outcome = snapshot
                .macro_step_outcomes
                .get(&MacroStepKey::new(context.macro_id, step_id))
                .cloned();
            complete_step(
                snapshot,
                context,
                step_id,
                CompletedStepOutcome::Success(outcome),
            );
        }
        ExecutionEvent::StepOutcome(step_id, outcome) => {
            Arc::make_mut(&mut snapshot.macro_step_outcomes).insert(
                MacroStepKey::new(context.macro_id, step_id),
                outcome.clone(),
            );
            if context.depth == 1 {
                Arc::make_mut(&mut snapshot.step_outcomes).insert(step_id, outcome);
            }
        }
        ExecutionEvent::StepSkipped(step_id) => {
            set_step_state(snapshot, context, step_id, StepState::Skipped)
        }
        ExecutionEvent::StepFailed(step_id, diagnostic) => {
            set_step_state(snapshot, context, step_id, StepState::Failed);
            snapshot.latest_failure = Some(diagnostic.clone());
            Arc::make_mut(&mut snapshot.macro_failures).insert(
                MacroDiagnosticKey {
                    run_id: snapshot.run_id,
                    step: MacroStepKey::new(context.macro_id, step_id),
                },
                diagnostic.clone(),
            );
            if context.depth == 1 {
                Arc::make_mut(&mut snapshot.failures).insert(
                    DiagnosticKey {
                        run_id: snapshot.run_id,
                        step_id,
                    },
                    diagnostic.clone(),
                );
            }
            complete_step(
                snapshot,
                context,
                step_id,
                CompletedStepOutcome::Failure(diagnostic),
            );
        }
        ExecutionEvent::Paused | ExecutionEvent::Resumed => {
            // Shared control, read before publication, is authoritative.
        }
    }
}

fn publish_manual_pause(shared: &Shared) {
    publish(shared, set_manual_pause);
}

fn set_manual_pause(snapshot: &mut RuntimeSnapshot) {
    if snapshot.state == RuntimeState::Stopping {
        return;
    }
    snapshot.state = RuntimeState::Paused;
    // BreakpointHit is the authoritative pause event. A Pause command can
    // already be queued when that event arrives, so manual pause updates
    // must not downgrade the reason while still stopped at that breakpoint.
    let stopped_at_breakpoint = matches!(snapshot.pause_reason,
        Some(RuntimePauseReason::Breakpoint { step_id, frame })
            if snapshot.active_frame() == Some(frame) && snapshot.active_step_id() == Some(step_id));
    if !stopped_at_breakpoint {
        snapshot.pause_reason = Some(RuntimePauseReason::User);
    }
}

fn stop_shared_run_if_current(shared: &Shared, run_id: u64) -> bool {
    let admission = shared.admission.lock().unwrap();
    let Some(active) = admission.as_ref().filter(|active| active.run_id == run_id) else {
        return false;
    };
    if let Some(gate) = active.owned_start_gate.as_ref() {
        gate.transition(OWNED_RUN_CANCELLED);
    }
    shared.control.stop();
    let snapshot = shared.snapshot.read().unwrap();
    if snapshot.run_id == run_id
        && matches!(snapshot.state, RuntimeState::Running | RuntimeState::Paused)
    {
        drop(snapshot);
        publish(shared, |snapshot| {
            snapshot.state = RuntimeState::Stopping;
            snapshot.pause_reason = None;
        });
    }
    true
}

fn clear_pause_reason(shared: &Shared) {
    if shared.snapshot.read().unwrap().pause_reason.is_some() {
        publish(shared, |snapshot| snapshot.pause_reason = None);
    }
}

fn worker_loop(
    store: Arc<MkMacroStore>,
    backends: Backends,
    rx: mpsc::Receiver<WorkerMessage>,
    shared: Arc<Shared>,
) {
    while let Ok(WorkerMessage {
        command,
        program,
        origin,
        run_id,
        owned_completion,
        owned_start_gate,
    }) = rx.recv()
    {
        match command {
            RuntimeCommand::Shutdown => {
                clear_pause_reason(&shared);
                break;
            }
            // Control was already applied synchronously by command(). Replaying
            // it after a run ends could corrupt the next admitted run's state.
            RuntimeCommand::Pause | RuntimeCommand::Resume | RuntimeCommand::Stop => {}
            command => {
                let request = run_request(&command).expect("run commands are classified");
                #[cfg(test)]
                if let Some(barrier) = shared.test_worker_barrier.lock().unwrap().take() {
                    let mut state = barrier.state.lock().unwrap();
                    state.0 = true;
                    barrier.wake.notify_all();
                    while !state.1 {
                        state = barrier.wake.wait(state).unwrap();
                    }
                }
                run_one(
                    &store,
                    &backends,
                    &shared,
                    request,
                    program,
                    origin,
                    run_id.expect("admitted run has an ID"),
                    owned_completion,
                    owned_start_gate,
                )
            }
        }
    }
    shared.control.stop();
    let mut admission = shared.admission.lock().unwrap();
    shared.operations.release(Operation::Playback);
    *admission = None;
}
/// Admission covers compilation and invocation preparation as well as effects.
/// The executor releases owned input before this root lifecycle releases activity.
struct RootRunGuard<'a> {
    shared: &'a Shared,
    run_id: u64,
    completed: bool,
}
impl RootRunGuard<'_> {
    fn complete<T>(
        mut self,
        publish_terminal: impl FnOnce(bool) -> (T, SummaryOutcome),
    ) -> (T, Option<ActivityTask>, SummaryOutcome) {
        #[cfg(test)]
        wait_on_test_barrier(&self.shared.test_terminal_barrier);
        let mut admission = self.shared.admission.lock().unwrap();
        // Stop and terminal publication use the same admission lock. Capture
        // the authoritative stopped bit once so the snapshot and summary
        // cannot disagree if Stop races the end of execution.
        let stopped = self.shared.control.is_stopped();
        self.shared.control.finish();
        let paused = self.shared.control.paused_duration();
        let (result, outcome) = publish_terminal(stopped);
        if let Some(active) = admission
            .as_mut()
            .filter(|active| active.run_id == self.run_id)
            && let Some(summary) = active.summary.take()
        {
            self.shared
                .summary_history
                .lock()
                .unwrap()
                .publish(summary, outcome, None, paused);
        }
        let activity = admission
            .as_ref()
            .filter(|active| active.run_id == self.run_id)
            .and_then(|active| active.activity.clone());
        self.shared.operations.release(Operation::Playback);
        *admission = None;
        self.completed = true;
        (result, activity, outcome)
    }
}
impl Drop for RootRunGuard<'_> {
    fn drop(&mut self) {
        if !self.completed {
            let mut admission = self.shared.admission.lock().unwrap();
            self.shared.control.finish();
            let paused = self.shared.control.paused_duration();
            if let Some(active) = admission
                .as_mut()
                .filter(|active| active.run_id == self.run_id)
                && let Some(summary) = active.summary.take()
            {
                self.shared.summary_history.lock().unwrap().publish(
                    summary,
                    SummaryOutcome::Failed(DiagnosticKind::Panic),
                    None,
                    paused,
                );
            }
            self.shared.operations.release(Operation::Playback);
            *admission = None;
        }
    }
}

fn update_active_summary(
    shared: &Shared,
    run_id: u64,
    update: impl FnOnce(&mut SummaryAccumulator),
) {
    let mut admission = shared.admission.lock().unwrap();
    if let Some(active) = admission.as_mut().filter(|active| active.run_id == run_id)
        && let Some(summary) = active.summary.as_mut()
    {
        update(summary);
    }
}

fn run_one(
    store: &MkMacroStore,
    backends: &Backends,
    shared: &Shared,
    request: RunRequest<'_>,
    prepared_program: Option<super::MkCompiledProgram>,
    origin: RuntimeOrigin,
    run_id: u64,
    owned_completion: Option<mpsc::SyncSender<OwnedMacroRunCompletion>>,
    owned_start_gate: Option<Arc<OwnedRunStartGate>>,
) {
    let RunRequest {
        macro_id: mid,
        mode,
        arguments,
        ..
    } = request;
    let run_guard = RootRunGuard {
        shared,
        run_id,
        completed: false,
    };
    #[cfg(test)]
    shared.test_events.lock().unwrap().clear();
    let start_cancelled = owned_start_gate
        .as_ref()
        .is_some_and(|gate| !gate.wait_for_start());
    let activity = shared
        .admission
        .lock()
        .unwrap()
        .as_ref()
        .filter(|active| active.run_id == run_id)
        .and_then(|active| active.activity.clone());
    if let Some(activity) = activity {
        activity.mark_running();
    }
    let mut clipboard_privacy_active = false;
    let result = if start_cancelled {
        Err(ExecutionDiagnostic::new(
            DiagnosticKind::Cancelled,
            "Macro run was cancelled before start",
        ))
    } else {
        std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let program = match prepared_program {
                Some(program) => program,
                None => {
                    update_active_summary(shared, run_id, |summary| {
                        summary.mark_worker_preparation_started();
                    });
                    let invocation = request.to_invocation();
                    super::invocation::compile_invocation_program(&store.snapshot(), &invocation)?
                }
            };
            clipboard_privacy_active = program_contains_clipboard_actions(&program);
            let plan = program.plan(mid).ok_or_else(|| {
                ExecutionDiagnostic::new(
                    DiagnosticKind::InvalidPlan,
                    "Compiled program root is missing",
                )
            })?;
            let admission = shared.admission.lock().unwrap();
            let state = controlled_state(&shared.control);
            publish(shared, |s| {
                *s = RuntimeSnapshot {
                    state,
                    run_mode: mode,
                    run_id,
                    origin,
                    macro_id: Some(mid),
                    debug_values_redacted: mode == RuntimeRunMode::Debug
                        && clipboard_privacy_active,
                    pause_reason: (state == RuntimeState::Paused)
                        .then_some(RuntimePauseReason::User),
                    total_steps: plan.instructions.iter().filter(|x| x.step.enabled).count(),
                    started_at: Some(SystemTime::now()),
                    revision: s.revision,
                    ..RuntimeSnapshot::default()
                };
            });
            drop(admission);
            let observer = |context: ExecutionFrameContext, event: ExecutionEvent| {
                #[cfg(test)]
                if context.depth == 1
                    && !matches!(
                        event,
                        ExecutionEvent::FrameEntered(_) | ExecutionEvent::FrameExited { .. }
                    )
                {
                    shared.test_events.lock().unwrap().push(event.clone());
                }
                #[cfg(test)]
                let immediate_breakpoint_observer = if context.depth == 1
                    && matches!(&event, ExecutionEvent::BreakpointHit { .. })
                {
                    shared.test_breakpoint_observer.lock().unwrap().take()
                } else {
                    None
                };
                // Serialize state decisions with control commands. Read control
                // before snapshot publication to preserve the single lock order.
                let mut admission = shared.admission.lock().unwrap();
                let state = controlled_state(&shared.control);
                if let Some(active) = admission.as_mut().filter(|active| active.run_id == run_id)
                    && let Some(summary) = active.summary.as_mut()
                {
                    summary.observe(
                        context,
                        &event,
                        &program,
                        &mut shared.summary_history.lock().unwrap(),
                    );
                }
                publish(shared, |snapshot| {
                    apply_execution_event(snapshot, &program, context, event, state)
                });
                if let Some(activity) = admission
                    .as_ref()
                    .filter(|active| active.run_id == run_id)
                    .and_then(|active| active.activity.as_ref())
                {
                    let snapshot = shared.snapshot.read().unwrap();
                    activity.set_progress(Some(ActivityProgress::new(
                        snapshot.completed_steps as u64,
                        Some(snapshot.total_steps as u64),
                        ActivityProgressUnit::Steps,
                    )));
                }
                drop(admission);
                #[cfg(test)]
                if let Some(observer) = immediate_breakpoint_observer {
                    observer(&shared.control);
                }
            };
            update_active_summary(shared, run_id, |summary| {
                summary.mark_execution_started();
            });
            let executor = Executor::new(backends.clone(), shared.control.clone());
            let options = match mode {
                RuntimeRunMode::Normal => ExecutionOptions::normal(),
                RuntimeRunMode::Debug => ExecutionOptions::debug(),
            };
            executor.execute_program(
                &program,
                arguments.unwrap_or(&MkInvocationValues::new()),
                options,
                &observer,
            )
        }))
        .unwrap_or_else(|payload| {
            if clipboard_privacy_active {
                tracing::error!(
                    macro_id = mid,
                    "macro execution panicked in clipboard-enabled run"
                );
                Err(ExecutionDiagnostic::new(
                    DiagnosticKind::Panic,
                    "Macro execution panicked during clipboard-enabled execution",
                )
                .context("macro_id", mid.to_string()))
            } else {
                let message = payload
                    .downcast_ref::<String>()
                    .cloned()
                    .or_else(|| {
                        payload
                            .downcast_ref::<&str>()
                            .map(|text| (*text).to_owned())
                    })
                    .unwrap_or_else(|| "non-string panic payload".into());
                tracing::error!(macro_id = mid, %message, "macro execution panicked");
                Err(ExecutionDiagnostic::new(
                    DiagnosticKind::Panic,
                    format!("Macro execution panicked: {message}"),
                )
                .context("macro_id", mid.to_string()))
            }
        })
    };
    let failure_kind = result.as_ref().err().map(|diagnostic| diagnostic.kind);
    let (state, activity, terminal_outcome) = run_guard.complete(|stopped| {
        let (state, terminal_outcome) = terminal_classification(&result, stopped);
        publish(shared, |s| {
            // Failed preparation still belongs to this admitted run, rather
            // than retaining the identity/status maps of an earlier macro.
            if s.run_id != run_id {
                *s = RuntimeSnapshot {
                    run_id,
                    origin,
                    macro_id: Some(mid),
                    run_mode: mode,
                    revision: s.revision,
                    ..RuntimeSnapshot::default()
                };
            }
            match result {
                Ok(()) => {
                    s.state = state;
                }
                Err(d) if d.kind == DiagnosticKind::Cancelled => s.state = RuntimeState::Stopped,
                Err(d) => {
                    s.state = RuntimeState::Failed;
                    s.latest_failure = Some(d);
                }
            }
            // A panic can bypass frame-exit events. Terminal snapshots have no
            // active stack, while the last captured Debug identity stays owned.
            if !s.call_stack.is_empty() {
                s.call_stack = Arc::new(Vec::new());
            }
            let reason = match s.state {
                RuntimeState::Completed => DebugSnapshotReason::RunFinished,
                RuntimeState::Stopped => DebugSnapshotReason::RunCancelled,
                _ => DebugSnapshotReason::RunFailed,
            };
            if let Some(debug) = &mut s.debug_snapshot {
                Arc::make_mut(debug).reason = reason;
                s.debug_snapshot_reason = Some(reason);
            }
            s.step_id = None;
            s.pause_reason = None;
            s.finished_at = Some(SystemTime::now());
        });
        (state, terminal_outcome)
    });
    if let Some(activity) = activity {
        let outcome = match terminal_outcome {
            SummaryOutcome::Completed => ActivityOutcome::Completed,
            SummaryOutcome::Stopped => ActivityOutcome::Cancelled,
            SummaryOutcome::Failed(_) => ActivityOutcome::Failed,
        };
        activity.finish(
            outcome,
            (outcome == ActivityOutcome::Failed).then_some(ActivityDiagnostic::WorkerFailed),
            ActivityRetirement::Unavailable,
        );
    }
    if let Some(completion) = owned_completion {
        let _ = completion.send(OwnedMacroRunCompletion {
            run_id,
            macro_id: mid,
            state,
            failure_kind,
        });
    }
}

static RUNTIME: Lazy<RwLock<Option<Arc<MacroRuntime>>>> = Lazy::new(|| RwLock::new(None));
static RECORDER: Lazy<RwLock<Option<Arc<RecorderRuntime>>>> = Lazy::new(|| RwLock::new(None));
static HOTKEYS: Lazy<RwLock<Option<Arc<super::hotkeys::MkMacroHotkeyService>>>> =
    Lazy::new(|| RwLock::new(None));
static DOCUMENT_PUBLICATION_OBSERVER: Lazy<
    RwLock<Option<Arc<super::store::DocumentPublicationObserver>>>,
> = Lazy::new(|| RwLock::new(None));
static RECORDER_HOTKEYS: Lazy<RwLock<Option<Arc<super::recorder_hotkeys::RecorderHotkeyService>>>> =
    Lazy::new(|| RwLock::new(None));
#[derive(Clone)]
struct RecordingArm {
    target: Option<RecordingTarget>,
    config: NormalizationConfig,
}
static RECORDING_ARM: Lazy<RwLock<RecordingArm>> = Lazy::new(|| {
    RwLock::new(RecordingArm {
        target: None,
        config: NormalizationConfig::default(),
    })
});
static RECORDING_STATUS: Lazy<RwLock<Option<String>>> = Lazy::new(|| RwLock::new(None));
static RECORDING_ANNOTATION_ACTIVE: AtomicBool = AtomicBool::new(false);
static PENDING_RECORDINGS: Lazy<Mutex<Vec<RecordingResult>>> = Lazy::new(|| Mutex::new(Vec::new()));
static RECORD_STOP_COORDINATOR: Lazy<(Mutex<bool>, Condvar)> =
    Lazy::new(|| (Mutex::new(false), Condvar::new()));
struct RecordStopJob {
    recorder: Arc<RecorderRuntime>,
    occurrence: Vec<u32>,
}
struct RecordStopCompletion;
impl Drop for RecordStopCompletion {
    fn drop(&mut self) {
        let mut pending = RECORD_STOP_COORDINATOR.0.lock().unwrap();
        *pending = false;
        RECORD_STOP_COORDINATOR.1.notify_all();
    }
}
static RECORD_STOP_WORKER: Lazy<mpsc::Sender<RecordStopJob>> = Lazy::new(|| {
    let (tx, rx) = mpsc::channel::<RecordStopJob>();
    thread::Builder::new()
        .name("mkmacro-record-stop".into())
        .spawn(move || {
            while let Ok(job) = rx.recv() {
                let _completion = RecordStopCompletion;
                let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    job.recorder.stop_for_review_with_control(job.occurrence)
                }))
                .unwrap_or_else(|_| Err(anyhow!("recording finalization panicked")));
                match result {
                    Ok(result) => {
                        PENDING_RECORDINGS.lock().unwrap().push(result);
                        *RECORDING_STATUS.write().unwrap() = None;
                    }
                    Err(error) => {
                        *RECORDING_STATUS.write().unwrap() = Some(error.to_string());
                    }
                }
                if job.recorder.snapshot().state == super::RecorderRuntimeState::Idle {
                    job.recorder.complete_review_transfer();
                }
            }
        })
        .expect("spawn recorder stop worker");
    tx
});
pub fn set_shared_store(store: Arc<MkMacroStore>) {
    set_shared_store_with_backends_and_reserved(
        store.clone(),
        production_backends_with_store(store),
        &[],
    )
}
pub fn set_shared_store_with_reserved(store: Arc<MkMacroStore>, reserved: &[(&str, &str)]) {
    set_shared_store_with_backends_and_reserved(
        store.clone(),
        production_backends_with_store(store),
        reserved,
    )
}

/// Replaces only launcher-owned hotkey reservations without rebuilding the
/// macro runtime, recorder, or store during a settings reload.
pub fn refresh_shared_hotkey_reservations(reserved: &[(&str, &str)]) -> Result<(), String> {
    let service = HOTKEYS
        .read()
        .map_err(|_| "shared macro hotkey service lock is poisoned".to_string())?
        .clone()
        .ok_or_else(|| "shared macro hotkey service is not initialized".to_string())?;
    service.replace_reserved(reserved)
}

/// Reads the document currently owned by the shared macro hotkey service.
/// This is a read-only preflight input; callers must not refresh reservations
/// while merely validating a proposed launcher route.
pub fn shared_hotkey_document_snapshot() -> Result<Option<Arc<MkMacroDocument>>, String> {
    let service = HOTKEYS
        .read()
        .map_err(|_| "shared macro hotkey service lock is poisoned".to_string())?;
    Ok(service.as_ref().map(|service| service.document_snapshot()))
}
/// Install the main owner's publication fence on the same store used by both
/// macro hotkey and recorder polling. This does not query or resolve routes.
pub fn observe_shared_document_publication(
    observer: Arc<super::store::DocumentPublicationObserver>,
) -> Result<(), String> {
    *DOCUMENT_PUBLICATION_OBSERVER
        .write()
        .map_err(|_| "macro publication observer lock is poisoned".to_string())? =
        Some(Arc::clone(&observer));
    let service = HOTKEYS
        .read()
        .map_err(|_| "shared macro hotkey service lock is poisoned".to_string())?;
    if let Some(service) = service.as_ref() {
        service.set_publication_observer(observer);
    }
    Ok(())
}
/// Installs a shared runtime with injected effects (intended for tests).
pub fn set_shared_store_with_backends(store: Arc<MkMacroStore>, backends: Backends) {
    set_shared_store_with_backends_and_reserved(store, backends, &[])
}
/// Installs a shared runtime with injected effects and reserved launcher chords.
pub fn set_shared_store_with_backends_and_reserved(
    store: Arc<MkMacroStore>,
    backends: Backends,
    reserved: &[(&str, &str)],
) {
    set_shared_store_components(
        store,
        backends,
        reserved,
        production_hook_service(8192),
        true,
        None,
    )
}
fn set_shared_store_components(
    store: Arc<MkMacroStore>,
    backends: Backends,
    reserved: &[(&str, &str)],
    recorder_hooks: super::HookService,
    start_hotkey_services: bool,
    recorder_components: Option<(
        Box<dyn KeyboardTranslator>,
        Arc<dyn Fn() -> RecorderObserverSession + Send + Sync>,
        Box<dyn EventEnricher>,
    )>,
) {
    let publication_observer = DOCUMENT_PUBLICATION_OBSERVER.read().unwrap().clone();
    if let Some(observer) = &publication_observer {
        (observer.before)();
        store.set_publication_observer(Arc::clone(observer));
    }
    // Stop pollers before taking stop coordination; a poller callback may be
    // in the process of enqueuing the current recording's Stop occurrence.
    if let Some(old) = HOTKEYS.write().unwrap().take() {
        old.shutdown()
    }
    if let Some(old) = RECORDER_HOTKEYS.write().unwrap().take() {
        old.shutdown()
    }
    // Runtime replacement cannot discard an accepted stop/review transfer.
    // Serialize enqueue against replacement and wait for the exact captured
    // recorder instance to finish before shutting it down.
    let mut stop_coordination = RECORD_STOP_COORDINATOR.0.lock().unwrap();
    while *stop_coordination {
        stop_coordination = RECORD_STOP_COORDINATOR.1.wait(stop_coordination).unwrap();
    }
    if let Some(old) = RUNTIME.write().unwrap().take() {
        old.shutdown()
    }
    if let Some(old) = RECORDER.write().unwrap().take() {
        old.shutdown()
    }
    let guard = Arc::new(SharedOperationGuard::default());
    *RUNTIME.write().unwrap() = Some(Arc::new(MacroRuntime::with_guard(
        store.clone(),
        backends,
        guard.clone(),
    )));
    let recorder = match recorder_components {
        Some((translator, factory, enricher)) => RecorderRuntime::with_guard_and_components(
            store.clone(),
            recorder_hooks,
            Arc::new(SystemRecorderClock),
            guard,
            translator,
            factory,
            enricher,
        ),
        None => RecorderRuntime::with_guard(
            store.clone(),
            recorder_hooks,
            Arc::new(SystemRecorderClock),
            guard,
        ),
    };
    *RECORDER.write().unwrap() = Some(Arc::new(recorder));
    if start_hotkey_services {
        *HOTKEYS.write().unwrap() = Some(Arc::new(
            super::hotkeys::MkMacroHotkeyService::new_with_reserved(store.clone(), reserved),
        ));
        *RECORDER_HOTKEYS.write().unwrap() = Some(Arc::new(
            super::recorder_hotkeys::RecorderHotkeyService::system(store),
        ));
    }
    if let Some(observer) = publication_observer {
        (observer.after)();
    }
}
fn global() -> Result<Arc<MacroRuntime>> {
    RUNTIME
        .read()
        .unwrap()
        .clone()
        .ok_or_else(|| anyhow!("macro runtime is not initialized"))
}

pub(crate) fn hotfolder_runtime_available() -> bool {
    RUNTIME
        .read()
        .unwrap()
        .as_ref()
        .is_some_and(|runtime| runtime.is_available())
}

pub(crate) fn start_hotfolder_macro(
    expected_macro: &super::MkMacro,
    expected_dependencies: &[super::MkMacro],
) -> ExecResult<OwnedMacroRun> {
    let runtime = RUNTIME.read().unwrap().clone().ok_or_else(|| {
        ExecutionDiagnostic::new(
            DiagnosticKind::RuntimeUnavailable,
            "macro runtime is not initialized",
        )
    })?;
    runtime.start_owned_hotfolder_macro(expected_macro, expected_dependencies)
}

fn command_result(result: CommandResult) -> ExecResult {
    match result {
        CommandResult::Accepted => Ok(()),
        CommandResult::Rejected(diagnostic) => Err(diagnostic),
        CommandResult::AlreadyRunning { active_macro_id } => Err(ExecutionDiagnostic::new(
            DiagnosticKind::RuntimeUnavailable,
            format!("Macro {active_macro_id} is already running"),
        )),
    }
}
/// Success includes a queued parameter request; no execution is admitted until
/// complete typed values have been confirmed.
fn prepare_direct(command: RuntimeCommand) -> Result<()> {
    prepare_direct_with_source(command, InvocationSource::UnclassifiedApi)
}

fn prepare_direct_with_source(
    command: RuntimeCommand,
    invocation_source: InvocationSource,
) -> Result<()> {
    global()?.prepare_direct_command(
        command,
        &super::invocation_prompt::production_invocation_prompt_broker(),
        invocation_source,
    )?;
    Ok(())
}
fn accepted(r: CommandResult) -> Result<()> {
    match r {
        CommandResult::Accepted => Ok(()),
        x => Err(anyhow!("{x:?}")),
    }
}
pub fn invoke(invocation: MkInvocation) -> Result<()> {
    prepare_direct(RuntimeCommand::Invoke(invocation))
}
pub fn invoke_with_source(invocation: MkInvocation, source: InvocationSource) -> Result<()> {
    prepare_direct_with_source(RuntimeCommand::Invoke(invocation), source)
}
pub fn run(id: u64) -> Result<()> {
    prepare_direct(RuntimeCommand::Run(id))
}
pub fn run_with_source(id: u64, source: InvocationSource) -> Result<()> {
    prepare_direct_with_source(RuntimeCommand::Run(id), source)
}
pub fn run_from(macro_id: u64, step_id: u64) -> Result<()> {
    prepare_direct(RuntimeCommand::RunFrom(macro_id, step_id))
}
pub fn run_from_with_source(macro_id: u64, step_id: u64, source: InvocationSource) -> Result<()> {
    prepare_direct_with_source(RuntimeCommand::RunFrom(macro_id, step_id), source)
}
pub fn run_selection(macro_id: u64, ids: Vec<u64>) -> Result<()> {
    prepare_direct(RuntimeCommand::RunSelection(macro_id, ids))
}
pub fn run_selection_with_source(
    macro_id: u64,
    ids: Vec<u64>,
    source: InvocationSource,
) -> Result<()> {
    prepare_direct_with_source(RuntimeCommand::RunSelection(macro_id, ids), source)
}
pub fn debug_run(macro_id: u64) -> Result<()> {
    prepare_direct(RuntimeCommand::DebugRun(macro_id))
}
pub fn debug_run_with_source(macro_id: u64, source: InvocationSource) -> Result<()> {
    prepare_direct_with_source(RuntimeCommand::DebugRun(macro_id), source)
}
pub fn debug_run_from(macro_id: u64, step_id: u64) -> Result<()> {
    prepare_direct(RuntimeCommand::DebugRunFrom(macro_id, step_id))
}
pub fn debug_run_from_with_source(
    macro_id: u64,
    step_id: u64,
    source: InvocationSource,
) -> Result<()> {
    prepare_direct_with_source(RuntimeCommand::DebugRunFrom(macro_id, step_id), source)
}
pub fn debug_run_selection(macro_id: u64, ids: Vec<u64>) -> Result<()> {
    prepare_direct(RuntimeCommand::DebugRunSelection(macro_id, ids))
}
pub fn debug_run_selection_with_source(
    macro_id: u64,
    ids: Vec<u64>,
    source: InvocationSource,
) -> Result<()> {
    prepare_direct_with_source(RuntimeCommand::DebugRunSelection(macro_id, ids), source)
}
/// Compile and submit an ephemeral document snapshot without publishing it to
/// the store. It shares the normal worker, admission, controls, diagnostics,
/// and executor cleanup path.
pub fn preview_document(document: &super::MkMacroDocument, macro_id: u64) -> Result<u64> {
    let ticket = NEXT_PREVIEW_TICKET.fetch_add(1, Ordering::Relaxed);
    global()?.preview(document, macro_id, ticket)?;
    Ok(ticket)
}
pub fn stop_recording_preview(ticket: u64) -> bool {
    RUNTIME
        .read()
        .unwrap()
        .as_ref()
        .is_some_and(|runtime| runtime.stop_recording_preview(ticket))
}
pub fn pause() -> Result<()> {
    accepted(global()?.command(RuntimeCommand::Pause))
}
pub fn resume() -> Result<()> {
    accepted(global()?.command(RuntimeCommand::Resume))
}
pub fn stop() -> Result<()> {
    accepted(global()?.command(RuntimeCommand::Stop))
}
/// Returns transient execution state; it is never serialized by `MkMacroStore`.
pub fn snapshot() -> Option<Arc<RuntimeSnapshot>> {
    RUNTIME.read().unwrap().as_ref().map(|r| r.snapshot())
}

pub(crate) fn attach_activity_center(center: ActivityCenter) {
    let runtime = RUNTIME.read().unwrap().clone();
    if let Some(runtime) = runtime {
        runtime.attach_activity_center(center);
    }
}

pub fn with_run_summaries<R>(
    inspect: impl FnOnce(u64, &std::collections::VecDeque<MacroRunSummary>) -> R,
) -> Option<R> {
    RUNTIME
        .read()
        .unwrap()
        .as_ref()
        .map(|runtime| runtime.with_run_summaries(inspect))
}

pub(crate) fn with_history_view<R>(
    request: HistoryViewRequest,
    inspect: impl FnOnce(&HistoryProjection) -> R,
) -> Result<R, HistoryAccessError> {
    with_registered_history_view(&RUNTIME, request, inspect)
}

fn with_registered_history_view<R>(
    registry: &RwLock<Option<Arc<MacroRuntime>>>,
    request: HistoryViewRequest,
    inspect: impl FnOnce(&HistoryProjection) -> R,
) -> Result<R, HistoryAccessError> {
    // Clone the owner under the registry lock, then release that lock before
    // reserving the frame view or calling UI code.
    let runtime = registry
        .read()
        .unwrap()
        .clone()
        .ok_or(HistoryAccessError::RuntimeUnavailable)?;
    runtime
        .with_history_view(request, inspect)
        .map_err(|error| match error {
            HistoryViewError::Busy => HistoryAccessError::Busy,
            HistoryViewError::Budget => HistoryAccessError::Budget,
        })
}

pub(crate) fn clear_run_history(generation: u64) -> Result<(), HistoryAccessError> {
    let registry = RUNTIME.read().unwrap();
    let runtime = registry
        .as_ref()
        .filter(|runtime| runtime.generation == generation)
        .ok_or(HistoryAccessError::RuntimeUnavailable)?;
    runtime
        .clear_completed_history()
        .map_err(|error| match error {
            HistoryViewError::Busy => HistoryAccessError::Busy,
            HistoryViewError::Budget => HistoryAccessError::Budget,
        })
}
/// Returns admission and the last retained snapshot for one preview ticket.
/// The retained snapshot survives later stored playback snapshots.
pub fn recording_preview_status(ticket: u64) -> (bool, Option<Arc<RuntimeSnapshot>>) {
    RUNTIME
        .read()
        .unwrap()
        .as_ref()
        .map_or((false, None), |runtime| {
            runtime.recording_preview_status(ticket)
        })
}
#[cfg(test)]
pub(crate) fn test_runtime() -> Option<Arc<MacroRuntime>> {
    RUNTIME.read().unwrap().clone()
}
pub fn record_target(target: RecordingTarget, config: NormalizationConfig) -> Result<()> {
    if record_stop_pending() {
        return Err(anyhow!("recording is stopping for review"));
    }
    RECORDER
        .read()
        .unwrap()
        .clone()
        .ok_or_else(|| anyhow!("macro runtime is not initialized"))?
        .start_target(target, config, Vec::new())
}
pub fn record_pause() -> Result<()> {
    RECORDER
        .read()
        .unwrap()
        .clone()
        .ok_or_else(|| anyhow!("macro runtime is not initialized"))?
        .pause()
}
pub fn record_resume() -> Result<()> {
    RECORDER
        .read()
        .unwrap()
        .clone()
        .ok_or_else(|| anyhow!("macro runtime is not initialized"))?
        .resume()
}
/// Stops capture and transfers ownership to the GUI's pending Review queue.
/// Command/headless callers must use this path because they cannot directly
/// present or safely discard the returned transient recording.
pub fn record_stop_for_review() -> Result<()> {
    request_record_stop_for_review().map(|_| ())
}
/// Requests capture finalization on one owned worker so egui can render the
/// Stopping state while observation/UIA lanes flush. Duplicate clicks are
/// idempotent and every successful result reaches the same Review queue.
pub fn request_record_stop_for_review() -> Result<bool> {
    let mut pending = RECORD_STOP_COORDINATOR.0.lock().unwrap();
    let recorder = RECORDER
        .read()
        .unwrap()
        .clone()
        .ok_or_else(|| anyhow!("macro runtime is not initialized"))?;
    enqueue_record_stop_for_review(&mut pending, recorder, Vec::new())
}
pub fn record_stop_pending() -> bool {
    *RECORD_STOP_COORDINATOR.0.lock().unwrap()
}

fn request_record_stop_for_review_on(
    recorder: Arc<RecorderRuntime>,
    occurrence: Vec<u32>,
) -> Result<bool> {
    let mut pending = RECORD_STOP_COORDINATOR.0.lock().unwrap();
    enqueue_record_stop_for_review(&mut pending, recorder, occurrence)
}

fn enqueue_record_stop_for_review(
    pending: &mut bool,
    recorder: Arc<RecorderRuntime>,
    occurrence: Vec<u32>,
) -> Result<bool> {
    if *pending {
        return Ok(false);
    }
    match recorder.snapshot().state {
        super::RecorderRuntimeState::Recording | super::RecorderRuntimeState::Paused => {}
        super::RecorderRuntimeState::Stopping => return Ok(false),
        super::RecorderRuntimeState::Idle => return Err(anyhow!("recorder is not active")),
    }
    *pending = true;
    RECORDING_ANNOTATION_ACTIVE.store(false, Ordering::Release);
    if RECORD_STOP_WORKER
        .send(RecordStopJob {
            recorder,
            occurrence,
        })
        .is_err()
    {
        *pending = false;
        return Err(anyhow!("recording stop worker is unavailable"));
    }
    Ok(true)
}
pub fn recorder_snapshot() -> Option<Arc<RecorderSnapshot>> {
    RECORDER.read().unwrap().as_ref().map(|r| r.snapshot())
}
pub fn record_marker() -> Result<()> {
    RECORDER
        .read()
        .unwrap()
        .clone()
        .ok_or_else(|| anyhow!("macro runtime is not initialized"))?
        .marker()
}
pub fn record_annotation(text: String) -> Result<()> {
    RECORDER
        .read()
        .unwrap()
        .clone()
        .ok_or_else(|| anyhow!("macro runtime is not initialized"))?
        .annotation(text)
}
pub fn set_recording_annotation_active(active: bool) {
    RECORDING_ANNOTATION_ACTIVE.store(active, Ordering::Release);
}
pub fn arm_recording(target: Option<RecordingTarget>, options: NormalizationConfig) {
    *RECORDING_ARM.write().unwrap() = RecordingArm {
        target,
        config: options,
    };
    if target.is_some()
        && RECORDING_STATUS.read().unwrap().as_deref()
            == Some("Select a macro before starting recording")
    {
        *RECORDING_STATUS.write().unwrap() = None;
    }
}
pub fn recording_status() -> Option<String> {
    RECORDING_STATUS.read().unwrap().clone()
}
pub fn take_pending_recordings() -> Vec<RecordingResult> {
    std::mem::take(&mut *PENDING_RECORDINGS.lock().unwrap())
}

/// Callback used by the global recorder control. It exchanges only thread-safe runtime state;
/// GUI drafts are updated later when they drain `take_pending_recordings`.
pub(crate) fn toggle_recording() {
    recorder_control(super::recorder_hotkeys::RecorderControlAction::Toggle)
}

fn hotkey_keys(hotkey: &super::MkHotkey) -> Vec<u32> {
    hotkey
        .modifiers
        .iter()
        .chain(std::iter::once(&hotkey.key))
        .filter_map(|key| super::virtual_key(key).map(u32::from))
        .collect()
}
fn control_hotkey(
    doc: &super::MkMacroDocument,
    action: super::recorder_hotkeys::RecorderControlAction,
) -> Option<&super::MkHotkey> {
    match action {
        super::recorder_hotkeys::RecorderControlAction::Toggle => {
            Some(&doc.settings.record_toggle_hotkey)
        }
        super::recorder_hotkeys::RecorderControlAction::PauseResume => {
            doc.settings.recorder.pause_resume_hotkey.as_ref()
        }
        super::recorder_hotkeys::RecorderControlAction::Marker => {
            doc.settings.recorder.marker_hotkey.as_ref()
        }
    }
}
pub(crate) fn recorder_control(action: super::recorder_hotkeys::RecorderControlAction) {
    if RECORDING_ANNOTATION_ACTIVE.load(Ordering::Acquire)
        && action != super::recorder_hotkeys::RecorderControlAction::Toggle
    {
        return;
    }
    let Some(recorder) = RECORDER.read().unwrap().clone() else {
        return;
    };
    let document = recorder.document_snapshot();
    let occurrence = document
        .as_deref()
        .and_then(|doc| control_hotkey(doc, action))
        .map(hotkey_keys)
        .unwrap_or_default();
    let result: Result<()> = match (action, recorder.snapshot().state) {
        (
            super::recorder_hotkeys::RecorderControlAction::Toggle,
            super::RecorderRuntimeState::Idle,
        ) => {
            if record_stop_pending() {
                return;
            }
            let arm = RECORDING_ARM.read().unwrap().clone();
            let target = arm.target;
            let Some(target) = target else {
                *RECORDING_STATUS.write().unwrap() =
                    Some("Select a macro before starting recording".into());
                return;
            };
            recorder.start_target(target, arm.config, occurrence)
        }
        (
            super::recorder_hotkeys::RecorderControlAction::Toggle,
            super::RecorderRuntimeState::Recording | super::RecorderRuntimeState::Paused,
        ) => request_record_stop_for_review_on(recorder.clone(), occurrence).map(|_| ()),
        (
            super::recorder_hotkeys::RecorderControlAction::PauseResume,
            super::RecorderRuntimeState::Recording,
        ) => recorder.pause_with_control(occurrence),
        (
            super::recorder_hotkeys::RecorderControlAction::PauseResume,
            super::RecorderRuntimeState::Paused,
        ) => recorder.resume_with_held(occurrence),
        (
            super::recorder_hotkeys::RecorderControlAction::Marker,
            super::RecorderRuntimeState::Recording,
        ) => recorder
            .suppress_control(occurrence)
            .and_then(|()| recorder.marker()),
        (
            super::recorder_hotkeys::RecorderControlAction::Marker,
            super::RecorderRuntimeState::Paused,
        ) => recorder.marker(),
        (_, super::RecorderRuntimeState::Stopping | super::RecorderRuntimeState::Idle) => return,
    };
    *RECORDING_STATUS.write().unwrap() = result.err().map(|e| e.to_string());
}

#[cfg(test)]
mod folder_tests {
    use super::*;
    use crate::mkmacro::{executor::fake::FakeBackend, model::*};
    use std::time::{Duration, Instant};

    fn run_document(document: MkMacroDocument, id: u64) -> (Arc<RuntimeSnapshot>, Vec<String>) {
        let dir = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(dir.path()).unwrap();
        store.save(document).unwrap();
        let effects = Arc::new(FakeBackend::default());
        let runtime = MacroRuntime::new(Arc::new(store), effects.clone().backends());
        assert_eq!(
            runtime.command(RuntimeCommand::Run(id)),
            CommandResult::Accepted
        );
        let deadline = Instant::now() + Duration::from_secs(2);
        loop {
            let snapshot = runtime.snapshot();
            if matches!(
                snapshot.state,
                RuntimeState::Completed | RuntimeState::Failed
            ) {
                return (snapshot, effects.events());
            }
            assert!(
                Instant::now() < deadline,
                "runtime did not finish: {snapshot:?}"
            );
            thread::sleep(Duration::from_millis(2));
        }
    }

    #[test]
    fn folder_metadata_does_not_change_runtime_lookup_or_manual_run_eligibility() {
        let target = MkMacro {
            signature: Default::default(),
            id: 91,
            name: "Target".into(),
            description: String::new(),
            enabled: true,
            hotkey: Some(MkHotkey {
                key: MkKey::Function(8),
                modifiers: vec![],
            }),
            hotkey_scope: MkHotkeyScope::ActiveWindow(MkWindowMatcher {
                process: Some("editor.exe".into()),
                ..Default::default()
            }),
            folder_id: None,
            playback: Default::default(),
            steps: vec![MkStep {
                metadata: Default::default(),
                id: 11,
                enabled: true,
                breakpoint: false,
                repeat: 1,
                delay_after_ms: 0,
                on_error: Default::default(),
                action: MkAction::Text(MkTextPayload {
                    text: "target executed".into(),
                    mode: MkTextMode::Type,
                }),
            }],
        };
        let mut decoy = target.clone();
        decoy.id = 7;
        decoy.name = "Decoy".into();
        decoy.hotkey = None;
        decoy.steps.clear();
        let mut document = MkMacroDocument {
            macros: vec![decoy, target],
            folders: vec![
                MkMacroFolder {
                    id: 42,
                    name: "Utilities".into(),
                },
                MkMacroFolder {
                    id: 43,
                    name: "Work".into(),
                },
            ],
            ..Default::default()
        };
        // A folder ID must never become a runtime target; disabled macros stay disabled.
        for (enabled, requested_id, expected_state) in [
            (true, 91, RuntimeState::Completed),
            (false, 91, RuntimeState::Failed),
            (true, 42, RuntimeState::Failed),
        ] {
            document.macros[1].enabled = enabled;
            document.macros[1].folder_id = None;
            document.folders[0].name = "Utilities".into();
            let (expected, expected_events) = run_document(document.clone(), requested_id);
            assert_eq!(expected.state, expected_state);
            if expected_state == RuntimeState::Completed {
                assert_eq!(expected.macro_id, Some(91));
                assert_eq!(expected.steps[&11], StepState::Success);
                assert_eq!(expected_events, ["text:target executed"]);
            } else {
                let kind = if enabled {
                    DiagnosticKind::TargetNotFound
                } else {
                    DiagnosticKind::InvalidTarget
                };
                assert_eq!(expected.latest_failure.as_ref().unwrap().kind, kind);
                assert!(expected_events.is_empty());
            }
            for (folder_id, name) in [
                (None, "Utilities"),
                (Some(42), "Utilities"),
                (Some(42), "Renamed folder"),
                (Some(43), "Utilities"),
            ] {
                document.macros[1].folder_id = folder_id;
                document.folders[0].name = name.into();
                let (actual, events) = run_document(document.clone(), requested_id);
                assert_eq!(actual.state, expected.state);
                assert_eq!(actual.macro_id, expected.macro_id);
                assert_eq!(actual.run_id, expected.run_id);
                assert_eq!(actual.steps, expected.steps);
                assert_eq!(actual.completed_steps, expected.completed_steps);
                assert_eq!(actual.total_steps, expected.total_steps);
                assert_eq!(actual.latest_failure, expected.latest_failure);
                assert_eq!(actual.failures, expected.failures);
                assert_eq!(events, expected_events);
            }
        }
    }
}

#[cfg(test)]
mod run_mode_tests {
    use super::*;
    use crate::mkmacro::prompt::{PromptBackend, PromptRequest, PromptResponse};
    use crate::mkmacro::{
        MKMACROS_FILE, MkAction, MkCondition, MkCoordinateTarget, MkDelayPayload, MkKey, MkMacro,
        MkMacroDocument, MkMouseButton, MkMouseMovePayload, MkMousePayload, MkPoint,
        MkPromptInputPayload, MkStep, MkTextMode, MkTextPayload, MkValue,
        executor::fake::FakeBackend,
    };
    use std::fs;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Condvar, Mutex};
    use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

    #[derive(Default)]
    struct ManualRuntimeClock(AtomicU64);

    impl ManualRuntimeClock {
        fn set_millis(&self, millis: u64) {
            self.0.store(millis, Ordering::SeqCst);
        }
    }

    impl MonotonicClock for ManualRuntimeClock {
        fn monotonic_now(&self) -> Duration {
            Duration::from_millis(self.0.load(Ordering::SeqCst))
        }

        fn wall_now(&self) -> SystemTime {
            UNIX_EPOCH
        }
    }

    struct AckHookLoop;
    impl crate::mkmacro::HookLoopAdapter for AckHookLoop {
        fn run(
            self,
            commands: std::sync::mpsc::Receiver<crate::mkmacro::HookCommandRequest>,
            _callback: crate::mkmacro::CallbackSender,
        ) {
            while let Ok(request) = commands.recv() {
                let shutdown = request.command == crate::mkmacro::HookCommand::Shutdown;
                request.acknowledge(true);
                if shutdown {
                    break;
                }
            }
        }
    }

    struct NoTextTranslator;
    impl crate::mkmacro::KeyboardTranslator for NoTextTranslator {
        fn translate(
            &mut self,
            _request: &crate::mkmacro::KeyboardTranslationRequest,
        ) -> crate::mkmacro::KeyTranslation {
            crate::mkmacro::KeyTranslation::None
        }
    }

    struct NoContextEnricher;
    impl crate::mkmacro::EventEnricher for NoContextEnricher {
        fn enrich(
            &mut self,
            _event: &crate::mkmacro::HookEvent,
        ) -> Option<crate::mkmacro::EventContext> {
            None
        }
    }

    struct FixedRecorderClock;
    impl crate::mkmacro::RecorderClock for FixedRecorderClock {
        fn now_us(&self) -> u64 {
            1
        }
    }

    fn empty_recorder_observer() -> crate::mkmacro::RecorderObserverSession {
        crate::mkmacro::RecorderObserverSession::with_parts(
            crate::mkmacro::ObservationBaseline::default(),
            crate::mkmacro::AuxiliaryObservationWorker::spawn(None, None),
        )
    }

    fn step(id: u64, action: MkAction) -> MkStep {
        MkStep {
            metadata: Default::default(),
            id,
            enabled: true,
            breakpoint: false,
            repeat: 1,
            delay_after_ms: 0,
            on_error: Default::default(),
            action,
        }
    }

    fn test_macro(id: u64, enabled: bool, steps: Vec<MkStep>) -> MkMacro {
        MkMacro {
            signature: Default::default(),
            id,
            name: format!("macro {id}"),
            description: String::new(),
            enabled,
            hotkey: None,
            hotkey_scope: Default::default(),
            folder_id: None,
            playback: Default::default(),
            steps,
        }
    }

    fn runtime_with(
        macros: Vec<MkMacro>,
    ) -> (tempfile::TempDir, MacroRuntime, Arc<SharedOperationGuard>) {
        let (dir, runtime, guard, _fake) = runtime_with_effects(macros);
        (dir, runtime, guard)
    }

    fn runtime_with_effects(
        macros: Vec<MkMacro>,
    ) -> (
        tempfile::TempDir,
        MacroRuntime,
        Arc<SharedOperationGuard>,
        Arc<FakeBackend>,
    ) {
        let dir = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(dir.path()).unwrap();
        store
            .save(MkMacroDocument {
                macros,
                ..Default::default()
            })
            .unwrap();
        let guard = Arc::new(SharedOperationGuard::default());
        let fake = Arc::new(FakeBackend::default());
        let runtime =
            MacroRuntime::with_guard(Arc::new(store), fake.clone().backends(), guard.clone());
        (dir, runtime, guard, fake)
    }

    fn runtime_with_effects_and_clock(
        macros: Vec<MkMacro>,
        clock: Arc<dyn MonotonicClock>,
    ) -> (
        tempfile::TempDir,
        MacroRuntime,
        Arc<SharedOperationGuard>,
        Arc<FakeBackend>,
    ) {
        let dir = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(dir.path()).unwrap();
        store
            .save(MkMacroDocument {
                macros,
                ..Default::default()
            })
            .unwrap();
        let guard = Arc::new(SharedOperationGuard::default());
        let fake = Arc::new(FakeBackend::default());
        let runtime = MacroRuntime::with_guard_and_clock(
            Arc::new(store),
            fake.clone().backends(),
            guard.clone(),
            clock,
        );
        (dir, runtime, guard, fake)
    }

    fn runtime_with_backends(
        macros: Vec<MkMacro>,
        backends: Backends,
    ) -> (tempfile::TempDir, MacroRuntime, Arc<SharedOperationGuard>) {
        let dir = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(dir.path()).unwrap();
        store
            .save(MkMacroDocument {
                macros,
                ..Default::default()
            })
            .unwrap();
        let guard = Arc::new(SharedOperationGuard::default());
        let runtime = MacroRuntime::with_guard(Arc::new(store), backends, guard.clone());
        (dir, runtime, guard)
    }

    fn wait_for_terminal(runtime: &MacroRuntime) -> Arc<RuntimeSnapshot> {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let snapshot = runtime.snapshot();
            if matches!(
                snapshot.state,
                RuntimeState::Completed | RuntimeState::Failed | RuntimeState::Stopped
            ) {
                return snapshot;
            }
            assert!(
                Instant::now() < deadline,
                "runtime did not finish: {snapshot:?}"
            );
            thread::sleep(Duration::from_millis(2));
        }
    }

    fn wait_for_terminal_after(
        runtime: &MacroRuntime,
        previous_run_id: u64,
    ) -> Arc<RuntimeSnapshot> {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let snapshot = runtime.snapshot();
            if snapshot.run_id > previous_run_id
                && matches!(
                    snapshot.state,
                    RuntimeState::Completed | RuntimeState::Failed | RuntimeState::Stopped
                )
            {
                return snapshot;
            }
            assert!(
                Instant::now() < deadline,
                "runtime did not finish: {snapshot:?}"
            );
            thread::sleep(Duration::from_millis(2));
        }
    }

    fn wait_for_activity_terminal(
        center: &ActivityCenter,
        key: crate::activity::ActivityKey,
    ) -> crate::activity::ActivityRow {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            if let Some(row) = center
                .snapshot()
                .rows
                .into_iter()
                .find(|row| row.key == key && row.lifecycle.is_terminal())
            {
                return row;
            }
            assert!(
                Instant::now() < deadline,
                "Activity owner did not publish terminal state for {key:?}"
            );
            thread::yield_now();
        }
    }

    fn wait_for_run_summary(runtime: &MacroRuntime, run_id: u64) -> SummaryOutcome {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let matching = runtime.with_run_summaries(|_, summaries| {
                summaries
                    .iter()
                    .filter(|summary| summary.run_id == run_id)
                    .map(|summary| summary.outcome)
                    .collect::<Vec<_>>()
            });
            if !matching.is_empty() {
                assert_eq!(
                    matching.len(),
                    1,
                    "run {run_id} must publish exactly one terminal summary"
                );
                return matching[0];
            }
            assert!(
                Instant::now() < deadline,
                "summary owner did not publish terminal state for run {run_id}"
            );
            thread::yield_now();
        }
    }

    #[test]
    fn macro_activity_routes_cancel_to_exact_run_and_reports_terminal_progress() {
        let target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::Delay(MkDelayPayload {
                    fixed_ms: 0,
                    ..Default::default()
                }),
            )],
        );
        let (_dir, runtime, _guard) = runtime_with(vec![target]);
        let center = ActivityCenter::new();
        runtime.attach_activity_center(center.clone());

        let first_barrier = runtime.install_test_worker_barrier();
        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        first_barrier.wait_until_blocked();
        let first = center.snapshot();
        assert_eq!(first.rows.len(), 1);
        let first_key = first.rows[0].key;
        assert_eq!(
            first.rows[0].lifecycle,
            crate::activity::ActivityLifecycle::Queued
        );
        assert_eq!(
            center.request_cancel(first_key),
            crate::activity::ActivityCancelResult::Requested
        );
        assert_eq!(
            center.snapshot().rows[0].lifecycle,
            crate::activity::ActivityLifecycle::Cancelling
        );
        first_barrier.release();
        let stopped = wait_for_terminal(&runtime);
        assert_eq!(stopped.state, RuntimeState::Stopped);
        let stopped_row = wait_for_activity_terminal(&center, first_key);
        let stopped_activity = center.snapshot();
        assert_eq!(stopped_activity.rows.len(), 1);
        assert_eq!(stopped_activity.rows[0].key, first_key);
        assert_eq!(
            stopped_row.lifecycle,
            crate::activity::ActivityLifecycle::Terminal(ActivityOutcome::Cancelled)
        );
        assert_eq!(stopped_row.retirement, ActivityRetirement::Unavailable);
        assert_eq!(
            wait_for_run_summary(&runtime, stopped.run_id),
            SummaryOutcome::Stopped
        );

        let second_barrier = runtime.install_test_worker_barrier();
        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        second_barrier.wait_until_blocked();
        assert_eq!(
            center.request_cancel(first_key),
            crate::activity::ActivityCancelResult::Terminal
        );
        let active_rows = center.snapshot();
        assert_eq!(active_rows.rows.len(), 2);
        let second_key = active_rows
            .rows
            .iter()
            .find(|row| row.key != first_key)
            .expect("second admitted run has its own Activity key")
            .key;
        assert!(active_rows.rows.iter().any(|row| {
            row.key != first_key && row.lifecycle == crate::activity::ActivityLifecycle::Queued
        }));
        second_barrier.release();
        let completed = wait_for_terminal_after(&runtime, stopped.run_id);
        assert_eq!(completed.state, RuntimeState::Completed);
        let completed_row = wait_for_activity_terminal(&center, second_key);
        let completed_activity = center.snapshot();
        assert_eq!(completed_activity.rows.len(), 2);
        assert_eq!(completed_row.key, second_key);
        assert_eq!(
            completed_row.lifecycle,
            crate::activity::ActivityLifecycle::Terminal(ActivityOutcome::Completed)
        );
        assert!(
            completed_row
                .progress
                .is_some_and(|progress| progress.completed == 1)
        );
        assert!(
            completed_activity
                .rows
                .iter()
                .any(|row| row.key == first_key)
        );
        assert_eq!(
            wait_for_run_summary(&runtime, completed.run_id),
            SummaryOutcome::Completed
        );

        let summaries = runtime.with_run_summaries(|_, summaries| {
            summaries
                .iter()
                .map(|summary| (summary.run_id, summary.outcome))
                .collect::<Vec<_>>()
        });
        assert_eq!(
            summaries,
            vec![
                (stopped.run_id, SummaryOutcome::Stopped),
                (completed.run_id, SummaryOutcome::Completed),
            ],
            "each exact Activity run has one matching summary and no duplicate completion"
        );
        assert_eq!(stopped_row.key, first_key);
        assert_eq!(completed_row.key, second_key);
    }

    fn wait_for_state(runtime: &MacroRuntime, wanted: RuntimeState) -> Arc<RuntimeSnapshot> {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let snapshot = runtime.snapshot();
            if snapshot.state == wanted {
                return snapshot;
            }
            assert!(
                Instant::now() < deadline,
                "runtime did not reach {wanted:?}: {snapshot:?}"
            );
            thread::sleep(Duration::from_millis(2));
        }
    }

    fn wait_for_debug_boundary(
        runtime: &MacroRuntime,
        step_id: Option<u64>,
        reason: DebugSnapshotReason,
    ) -> Arc<RuntimeSnapshot> {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let snapshot = runtime.snapshot();
            if snapshot
                .debug_snapshot
                .as_ref()
                .is_some_and(|debug| debug.step_id == step_id && debug.reason == reason)
            {
                return snapshot;
            }
            assert!(
                Instant::now() < deadline,
                "runtime did not publish debug boundary {step_id:?}/{reason:?}: {snapshot:?}"
            );
            thread::sleep(Duration::from_millis(2));
        }
    }

    #[test]
    fn frame_debugger_nested_same_ids_resume_stop_and_normal_mode() {
        use super::super::{
            MkCallMacroPayload, MkKey, MkMacroParameter, MkSignatureId, MkValueType,
        };
        for (mode, stop_at_breakpoint) in [
            (ExecutionMode::Debug, false),
            (ExecutionMode::Debug, true),
            (ExecutionMode::Normal, false),
        ] {
            let text = |value: &str| {
                MkAction::Text(MkTextPayload {
                    text: value.into(),
                    mode: MkTextMode::Type,
                })
            };
            let set = |value: &str| MkAction::SetVariable {
                name: "which".into(),
                value: MkValue::String(value.into()),
            };
            let call = |id| {
                MkAction::CallMacro(MkCallMacroPayload {
                    macro_id: id,
                    ..Default::default()
                })
            };
            let root = test_macro(
                1,
                true,
                vec![
                    step(1, set("root")),
                    step(4, MkAction::KeyDown(MkKey::Control)),
                    step(2, call(2)),
                    step(3, text("after:${which}")),
                ],
            );
            let child = test_macro(
                2,
                true,
                vec![
                    step(1, set("child")),
                    step(2, call(3)),
                    step(3, text("after:${which}")),
                ],
            );
            let mut leaf_step = step(1, text("${which}:${macro.name}"));
            leaf_step.breakpoint = true;
            let mut leaf = test_macro(3, true, vec![leaf_step]);
            leaf.signature.parameters.push(MkMacroParameter {
                id: MkSignatureId(1),
                name: "which".into(),
                value_type: MkValueType::String,
                input_kind: Default::default(),
                description: String::new(),
                default_value: Some(MkValue::String("leaf".into())),
            });
            let (_dir, runtime, _guard, fake) = runtime_with_effects(vec![root, child, leaf]);
            let mut invocation = MkInvocation::new(1);
            invocation.mode = mode;
            assert_eq!(
                runtime.command(RuntimeCommand::Invoke(invocation)),
                CommandResult::Accepted
            );
            if mode == ExecutionMode::Debug {
                let paused = wait_for_state(&runtime, RuntimeState::Paused);
                assert_eq!(paused.macro_id, Some(1));
                assert_eq!(paused.step_id, Some(2));
                assert_eq!(paused.active_macro_id(), Some(3));
                assert_eq!(paused.active_step_id(), Some(1));
                assert_eq!(
                    paused
                        .call_stack
                        .iter()
                        .map(|frame| (
                            frame.context.macro_id,
                            frame.context.frame_id,
                            frame.context.depth,
                            frame.context.caller_step_id
                        ))
                        .collect::<Vec<_>>(),
                    [(1, 1, 1, None), (2, 2, 2, Some(2)), (3, 3, 3, Some(2))]
                );
                assert_eq!(
                    paused
                        .call_stack
                        .iter()
                        .map(|frame| frame.macro_name.as_ref())
                        .collect::<Vec<_>>(),
                    ["macro 1", "macro 2", "macro 3"]
                );
                assert_eq!(paused.call_stack[0].active_step_id, Some(2));
                assert_eq!(
                    paused.macro_steps[&MacroStepKey::new(1, 1)],
                    StepState::Success
                );
                assert_eq!(
                    paused.macro_steps[&MacroStepKey::new(3, 1)],
                    StepState::Pending
                );
                let debug = paused.debug_snapshot.as_ref().unwrap();
                assert_eq!(debug.frame.frame_id, 3);
                assert_eq!(debug.frame.macro_id, 3);
                assert_eq!(debug.variables["which"], MkValue::String("leaf".into()));
                assert_eq!(
                    debug.variables["macro.name"],
                    MkValue::String("macro 3".into())
                );
                assert_eq!(
                    paused.breakpoint_occurrence().unwrap().step,
                    MacroStepKey::new(3, 1)
                );
                assert_eq!(fake.events(), ["key_down:Control"]);
                assert_eq!(
                    runtime.command(if stop_at_breakpoint {
                        RuntimeCommand::Stop
                    } else {
                        RuntimeCommand::Resume
                    }),
                    CommandResult::Accepted
                );
            }
            let done = wait_for_terminal(&runtime);
            assert_eq!(
                done.state,
                if stop_at_breakpoint {
                    RuntimeState::Stopped
                } else {
                    RuntimeState::Completed
                }
            );
            assert!(done.call_stack.is_empty());
            assert_eq!(done.active_frame(), None);
            if stop_at_breakpoint {
                assert_eq!(fake.events(), ["key_down:Control", "key_up:Control"]);
            } else {
                assert_eq!(
                    fake.events(),
                    [
                        "key_down:Control",
                        "text:leaf:macro 3",
                        "text:after:child",
                        "text:after:root",
                        "key_up:Control"
                    ]
                );
            }
            if mode == ExecutionMode::Normal {
                assert!(done.debug_snapshot.is_none());
                assert!(done.debug_variables.is_empty());
            } else {
                assert_eq!(done.debug_snapshot.as_ref().unwrap().frame.macro_id, 1);
            }
        }
    }

    #[test]
    fn frame_debugger_snapshot_publication_is_atomic_and_monotonic() {
        let (_dir, runtime, _guard) = runtime_with(vec![]);
        let before = runtime.snapshot();
        std::thread::scope(|scope| {
            for _ in 0..6 {
                let shared = &runtime.shared;
                scope.spawn(move || {
                    for _ in 0..100 {
                        publish(shared, |snapshot| {
                            snapshot.completed_steps += 1;
                            snapshot.total_steps += 1;
                        });
                    }
                });
            }
        });
        let after = runtime.snapshot();
        assert_eq!(after.revision, before.revision + 600);
        assert_eq!((after.completed_steps, after.total_steps), (600, 600));
        assert_eq!(
            (before.completed_steps, before.total_steps, before.revision),
            (0, 0, 0)
        );
    }

    #[test]
    fn frame_debugger_stop_precedes_pause_resume_while_action_is_pending() {
        let gate = Arc::new(ControllablePromptBackend::default());
        let mut backends = Arc::new(FakeBackend::default()).backends();
        backends.prompt = gate.clone();
        let target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::PromptInput(MkPromptInputPayload {
                    variable: "answer".into(),
                    ..Default::default()
                }),
            )],
        );
        let (_dir, runtime, _guard) = runtime_with_backends(vec![target], backends);
        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        gate.wait_until_entered();
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        assert_eq!(runtime.snapshot().state, RuntimeState::Stopping);
        for command in [RuntimeCommand::Pause, RuntimeCommand::Resume] {
            assert!(matches!(
                runtime.command(command),
                CommandResult::Rejected(_)
            ));
            assert_eq!(runtime.snapshot().state, RuntimeState::Stopping);
        }
        assert!(runtime.shared.control.is_stopped());
        gate.release();
        assert_eq!(wait_for_terminal(&runtime).state, RuntimeState::Stopped);
    }

    #[test]
    fn frame_debugger_restores_caller_and_preserves_previous_invocation_outcome() {
        use super::super::{FrameVariableBoundary, MkCallMacroPayload};
        let root = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::CallMacro(MkCallMacroPayload {
                    macro_id: 2,
                    ..Default::default()
                }),
            )],
        );
        let child = test_macro(
            2,
            true,
            vec![step(
                1,
                MkAction::Text(MkTextPayload {
                    text: "child".into(),
                    mode: MkTextMode::Type,
                }),
            )],
        );
        let program = compile_program(
            &MkMacroDocument {
                macros: vec![root, child],
                ..Default::default()
            },
            1,
        )
        .unwrap();
        let root_context = ExecutionFrameContext::root(1);
        let child_context = ExecutionFrameContext {
            frame_id: 2,
            macro_id: 2,
            caller_step_id: Some(1),
            depth: 2,
        };
        let metadata = |context: ExecutionFrameContext| ExecutionFrameSnapshot {
            context,
            macro_name: Arc::from(program.name(context.macro_id).unwrap()),
            active_step_id: None,
        };
        let mut snapshot = RuntimeSnapshot {
            macro_id: Some(1),
            run_id: 9,
            run_mode: RuntimeRunMode::Debug,
            ..Default::default()
        };
        let apply = |snapshot: &mut RuntimeSnapshot, context, event| {
            apply_execution_event(snapshot, &program, context, event, RuntimeState::Running)
        };
        apply(
            &mut snapshot,
            root_context,
            ExecutionEvent::FrameEntered(metadata(root_context)),
        );
        apply(&mut snapshot, root_context, ExecutionEvent::StepStarted(1));
        apply(
            &mut snapshot,
            child_context,
            ExecutionEvent::FrameEntered(metadata(child_context)),
        );
        let failure = ExecutionDiagnostic::new(DiagnosticKind::Backend, "first invocation failed");
        apply(
            &mut snapshot,
            child_context,
            ExecutionEvent::StepFailed(1, failure.clone()),
        );
        let completed = snapshot.last_completed.clone().unwrap();
        let prior_snapshot = snapshot.clone();
        apply(
            &mut snapshot,
            child_context,
            ExecutionEvent::FrameExited {
                caller_boundary: Some(FrameVariableBoundary {
                    step_id: None,
                    variables: [("caller".into(), MkValue::String("safe parent".into()))]
                        .into_iter()
                        .collect(),
                }),
            },
        );
        assert_eq!(snapshot.active_frame(), Some(root_context));
        assert_eq!(snapshot.active_step_id(), Some(1));
        let debug = snapshot.debug_snapshot.as_ref().unwrap();
        assert_eq!(debug.frame, root_context);
        assert_eq!(debug.reason, DebugSnapshotReason::FrameRestored);
        assert_eq!(
            debug.variables["caller"],
            MkValue::String("safe parent".into())
        );
        let next_child = ExecutionFrameContext {
            frame_id: 3,
            ..child_context
        };
        apply(
            &mut snapshot,
            next_child,
            ExecutionEvent::FrameEntered(metadata(next_child)),
        );
        assert!(snapshot.debug_snapshot.is_none());
        assert!(snapshot.debug_variables.is_empty());
        assert_eq!(
            snapshot.macro_steps[&MacroStepKey::new(2, 1)],
            StepState::Pending
        );
        assert!(!snapshot.macro_failures.contains_key(&MacroDiagnosticKey {
            run_id: 9,
            step: MacroStepKey::new(2, 1)
        }));
        assert_eq!(snapshot.last_completed.as_ref().unwrap().frame.frame_id, 2);
        assert_eq!(completed.outcome, CompletedStepOutcome::Failure(failure));
        assert_eq!(prior_snapshot.active_frame(), Some(child_context));
        assert_eq!(
            prior_snapshot.macro_steps[&MacroStepKey::new(2, 1)],
            StepState::Failed
        );
        apply(&mut snapshot, next_child, ExecutionEvent::StepFinished(1));
        assert_eq!(snapshot.last_completed.as_ref().unwrap().frame.frame_id, 3);
        assert!(matches!(
            completed.outcome,
            CompletedStepOutcome::Failure(_)
        ));
    }

    #[test]
    fn frame_debugger_stale_breakpoint_publication_cannot_reverse_stop_or_resume() {
        let program = compile_program(
            &MkMacroDocument {
                macros: vec![test_macro(
                    1,
                    true,
                    vec![step(1, MkAction::Delay(MkDelayPayload::default()))],
                )],
                ..Default::default()
            },
            1,
        )
        .unwrap();
        let context = ExecutionFrameContext::root(1);
        for state in [
            RuntimeState::Stopping,
            RuntimeState::Running,
            RuntimeState::Paused,
        ] {
            let mut snapshot = RuntimeSnapshot {
                macro_id: Some(1),
                run_id: 1,
                ..Default::default()
            };
            apply_execution_event(
                &mut snapshot,
                &program,
                context,
                ExecutionEvent::FrameEntered(ExecutionFrameSnapshot {
                    context,
                    macro_name: Arc::from("root"),
                    active_step_id: None,
                }),
                state,
            );
            apply_execution_event(
                &mut snapshot,
                &program,
                context,
                ExecutionEvent::BreakpointHit {
                    step_id: 1,
                    variables: RuntimeVariables::new(),
                },
                state,
            );
            assert_eq!(snapshot.state, state);
            assert_eq!(
                snapshot.breakpoint_occurrence().is_some(),
                state == RuntimeState::Paused
            );
            if state != RuntimeState::Paused {
                assert_eq!(snapshot.pause_reason, None);
            }
        }
    }

    struct PanickingSound;
    impl super::super::executor::SoundBackend for PanickingSound {
        fn play(&self, _: &str) -> ExecResult {
            panic!("injected sound panic")
        }
    }

    #[test]
    fn backend_panic_releases_root_resources_and_worker_accepts_subsequent_run() {
        let fake = Arc::new(FakeBackend::default());
        let mut backends = fake.clone().backends();
        backends.sound = Arc::new(PanickingSound);
        let panic_macro = test_macro(
            1,
            true,
            vec![
                step(1, MkAction::KeyDown(super::super::MkKey::Control)),
                step(2, MkAction::MouseDown(MkMouseButton::Left)),
                step(
                    3,
                    MkAction::PlaySound(super::super::MkPlaySoundPayload::default()),
                ),
            ],
        );
        let harmless = test_macro(
            2,
            true,
            vec![step(
                1,
                MkAction::Text(MkTextPayload {
                    text: "after panic".into(),
                    mode: MkTextMode::Type,
                }),
            )],
        );
        let (_dir, runtime, guard) = runtime_with_backends(vec![panic_macro, harmless], backends);
        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        let failed = wait_for_terminal(&runtime);
        assert_eq!(failed.state, RuntimeState::Failed);
        assert_eq!(
            wait_for_run_summary(&runtime, failed.run_id),
            SummaryOutcome::Failed(DiagnosticKind::Panic)
        );
        wait_for_admission_release(&runtime);
        runtime.with_run_summaries(|revision, summaries| {
            assert_eq!(revision, 1);
            assert_eq!(summaries.len(), 1);
            let summary = &summaries[0];
            assert_eq!(summary.run_id, failed.run_id);
            assert_eq!(
                summary.outcome,
                SummaryOutcome::Failed(DiagnosticKind::Panic)
            );
            assert_eq!(summary.failure.unwrap().kind, DiagnosticKind::Panic);
            let debug = format!("{summary:?}");
            assert!(!debug.contains("injected sound panic"));
        });
        assert!(failed.call_stack.is_empty());
        assert_eq!(failed.active_frame(), None);
        assert_eq!(
            failed.latest_failure.as_ref().unwrap().kind,
            DiagnosticKind::Panic
        );
        assert!(
            failed
                .latest_failure
                .as_ref()
                .unwrap()
                .message
                .contains("injected sound panic")
        );
        assert_eq!(
            fake.events(),
            [
                "key_down:Control",
                "button_down:Left",
                "button_up:Left",
                "key_up:Control"
            ]
        );
        // command() shares terminal/admission serialization, so observing terminal
        // state never leaves a window where Pause can replace it or Run is busy.
        assert!(matches!(
            runtime.command(RuntimeCommand::Pause),
            CommandResult::Rejected(_)
        ));
        assert_eq!(runtime.snapshot().state, RuntimeState::Failed);
        assert!(!runtime.shared.control.is_active());
        assert!(guard.claim(Operation::Playback));
        guard.release(Operation::Playback);
        assert_eq!(
            runtime.command(RuntimeCommand::Run(2)),
            CommandResult::Accepted
        );
        assert_eq!(
            wait_for_terminal_after(&runtime, failed.run_id).state,
            RuntimeState::Completed
        );
        assert_eq!(fake.events().last().unwrap(), "text:after panic");
    }

    #[test]
    fn early_admission_failure_clears_activity_and_records_current_run_identity() {
        let (_dir, runtime, guard) = runtime_with(vec![test_macro(1, true, vec![])]);
        assert_eq!(
            runtime.command(RuntimeCommand::Run(999)),
            CommandResult::Accepted
        );
        let failed = wait_for_terminal(&runtime);
        assert_eq!(failed.state, RuntimeState::Failed);
        assert_eq!(failed.macro_id, Some(999));
        assert!(failed.run_id > 0);
        assert_eq!(
            wait_for_run_summary(&runtime, failed.run_id),
            SummaryOutcome::Failed(DiagnosticKind::TargetNotFound)
        );
        wait_for_admission_release(&runtime);
        runtime.with_run_summaries(|revision, summaries| {
            assert_eq!(revision, 1);
            assert_eq!(summaries.len(), 1);
            assert_eq!(summaries[0].run_id, failed.run_id);
            assert_eq!(
                summaries[0].outcome,
                SummaryOutcome::Failed(DiagnosticKind::TargetNotFound)
            );
            assert_eq!(
                summaries[0].invocation_source,
                InvocationSource::UnclassifiedApi
            );
            assert!(summaries[0].worker_preparation.is_some());
            assert_eq!(summaries[0].execution_started_after, None);
            assert_eq!(
                summaries[0].failure.unwrap().kind,
                DiagnosticKind::TargetNotFound
            );
        });
        assert!(matches!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Rejected(_)
        ));
        assert!(matches!(
            runtime.command(RuntimeCommand::Pause),
            CommandResult::Rejected(_)
        ));
        assert!(!runtime.shared.control.is_active());
        assert!(guard.claim(Operation::Playback));
        guard.release(Operation::Playback);
        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        assert_eq!(
            wait_for_terminal_after(&runtime, failed.run_id).state,
            RuntimeState::Completed
        );
    }

    #[test]
    fn admitted_macro_summary_records_source_subset_and_only_safe_visit_metadata() {
        let target = test_macro(
            31,
            true,
            vec![
                step(
                    1,
                    MkAction::Text(MkTextPayload {
                        text: "not selected".into(),
                        mode: MkTextMode::Type,
                    }),
                ),
                step(
                    2,
                    MkAction::Text(MkTextPayload {
                        text: "selected".into(),
                        mode: MkTextMode::Type,
                    }),
                ),
            ],
        );
        let (_dir, runtime, _guard, fake) = runtime_with_effects(vec![target]);
        assert_eq!(
            runtime.submit_command_with_source(
                RuntimeCommand::RunSelection(31, vec![2]),
                None,
                InvocationSource::MacroDialog,
            ),
            CommandResult::Accepted
        );
        let completed = wait_for_terminal(&runtime);
        assert_eq!(completed.state, RuntimeState::Completed);
        assert_eq!(fake.events(), ["text:selected"]);
        assert_eq!(
            wait_for_run_summary(&runtime, completed.run_id),
            SummaryOutcome::Completed
        );
        wait_for_admission_release(&runtime);
        runtime.with_run_summaries(|revision, summaries| {
            assert_eq!(revision, 1);
            assert_eq!(summaries.len(), 1);
            let summary = &summaries[0];
            assert_eq!(summary.run_id, completed.run_id);
            assert_eq!(summary.macro_id, 31);
            assert_eq!(summary.macro_name, "macro 31");
            assert_eq!(summary.invocation_source, InvocationSource::MacroDialog);
            assert_eq!(summary.origin, RuntimeOrigin::Stored);
            assert_eq!(summary.mode, RuntimeRunMode::Normal);
            assert_eq!(summary.subset, SummarySubset::Selected { step_count: 1 });
            assert_eq!(summary.outcome, SummaryOutcome::Completed);
            assert_eq!(summary.visits.started, 1);
            assert_eq!(summary.visits.succeeded, 1);
            assert_eq!(summary.step_aggregates.len(), 1);
            assert_eq!(summary.step_aggregates[0].step_id, 2);
            assert_eq!(
                summary.step_aggregates[0].category,
                SummaryActionCategory::TextEntry
            );
        });

        // Rejected preflight has no admission and must not create a history row.
        assert!(matches!(
            runtime.submit_command_with_source(
                RuntimeCommand::RunSelection(31, Vec::new()),
                None,
                InvocationSource::MacroDialog,
            ),
            CommandResult::Rejected(_)
        ));
        runtime.with_run_summaries(|revision, summaries| {
            assert_eq!(revision, 1);
            assert_eq!(summaries.len(), 1);
        });
    }

    #[test]
    fn stop_after_execution_uses_one_terminal_classification_for_snapshot_and_summary() {
        let target = test_macro(
            81,
            true,
            vec![step(
                1,
                MkAction::SetVariable {
                    name: "finished".into(),
                    value: MkValue::Boolean(true),
                },
            )],
        );
        let (_dir, runtime, _guard, _fake) = runtime_with_effects(vec![target]);
        let terminal_barrier = runtime.install_test_terminal_barrier();

        assert_eq!(
            runtime.command(RuntimeCommand::Run(81)),
            CommandResult::Accepted
        );
        terminal_barrier.wait_until_blocked();
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        terminal_barrier.release();

        let terminal = wait_for_terminal(&runtime);
        assert_eq!(terminal.state, RuntimeState::Stopped);
        assert_eq!(
            wait_for_run_summary(&runtime, terminal.run_id),
            SummaryOutcome::Stopped
        );
        runtime.with_run_summaries(|_, summaries| {
            assert_eq!(summaries.len(), 1);
            assert_eq!(summaries[0].run_id, terminal.run_id);
            assert_eq!(summaries[0].outcome, SummaryOutcome::Stopped);
        });
    }

    #[test]
    fn breakpoint_observer_resume_stop_records_pause_time_without_phantom_visit() {
        let clock = Arc::new(ManualRuntimeClock::default());
        let mut first = step(
            1,
            MkAction::SetVariable {
                name: "resumed".into(),
                value: MkValue::Boolean(true),
            },
        );
        first.breakpoint = true;
        let mut second = step(
            2,
            MkAction::SetVariable {
                name: "never_started".into(),
                value: MkValue::Boolean(true),
            },
        );
        second.breakpoint = true;
        let (_dir, runtime, _guard, _fake) = runtime_with_effects_and_clock(
            vec![test_macro(82, true, vec![first, second])],
            clock.clone(),
        );

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(82)),
            CommandResult::Accepted
        );
        let first_pause = wait_for_state(&runtime, RuntimeState::Paused);
        assert_eq!(first_pause.breakpoint_sequence, 1);
        assert_eq!(first_pause.steps[&1], StepState::Pending);
        clock.set_millis(13);
        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );

        let second_pause = wait_for_state(&runtime, RuntimeState::Paused);
        assert_eq!(second_pause.breakpoint_sequence, 2);
        assert_eq!(second_pause.steps[&1], StepState::Success);
        assert_eq!(second_pause.steps[&2], StepState::Pending);
        clock.set_millis(18);
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );

        let terminal = wait_for_terminal(&runtime);
        assert_eq!(terminal.state, RuntimeState::Stopped);
        assert_eq!(
            wait_for_run_summary(&runtime, terminal.run_id),
            SummaryOutcome::Stopped
        );
        runtime.with_run_summaries(|_, summaries| {
            assert_eq!(summaries.len(), 1);
            let summary = &summaries[0];
            assert_eq!(summary.run_id, terminal.run_id);
            assert_eq!(summary.outcome, SummaryOutcome::Stopped);
            assert_eq!(summary.paused, Duration::from_millis(18));
            assert_eq!(summary.visits.started, 1);
            assert_eq!(summary.visits.succeeded, 1);
            assert_eq!(summary.visits.interrupted, 0);
            assert_eq!(summary.step_aggregates.len(), 1);
            assert_eq!(summary.step_aggregates[0].step_id, 1);
        });
    }

    #[test]
    fn breakpoint_observer_immediately_resumes_and_closes_injected_pause() {
        let clock = Arc::new(ManualRuntimeClock::default());
        let mut breakpoint_step = step(
            1,
            MkAction::SetVariable {
                name: "resumed_in_observer".into(),
                value: MkValue::Boolean(true),
            },
        );
        breakpoint_step.breakpoint = true;
        let (_dir, runtime, _guard, _fake) = runtime_with_effects_and_clock(
            vec![test_macro(85, true, vec![breakpoint_step])],
            clock.clone(),
        );
        let observer_clock = clock.clone();
        runtime.install_test_breakpoint_observer(move |control| {
            observer_clock.set_millis(9);
            control.resume();
        });

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(85)),
            CommandResult::Accepted
        );
        let terminal = wait_for_terminal(&runtime);
        assert_eq!(terminal.state, RuntimeState::Completed);
        assert_eq!(
            wait_for_run_summary(&runtime, terminal.run_id),
            SummaryOutcome::Completed
        );
        let events = runtime.take_test_events();
        assert!(
            events
                .iter()
                .any(|event| matches!(event, ExecutionEvent::BreakpointHit { step_id: 1, .. }))
        );
        assert!(
            events
                .iter()
                .any(|event| matches!(event, ExecutionEvent::StepStarted(1)))
        );

        runtime.with_run_summaries(|_, summaries| {
            assert_eq!(summaries.len(), 1);
            let summary = &summaries[0];
            assert_eq!(summary.run_id, terminal.run_id);
            assert_eq!(summary.outcome, SummaryOutcome::Completed);
            assert_eq!(summary.paused, Duration::from_millis(9));
            assert_eq!(summary.visits.started, 1);
            assert_eq!(summary.visits.succeeded, 1);
            assert_eq!(summary.visits.interrupted, 0);
            assert_eq!(summary.step_aggregates.len(), 1);
            assert_eq!(summary.step_aggregates[0].step_id, 1);
        });
    }

    #[test]
    fn breakpoint_observer_immediately_stops_without_starting_the_step() {
        let clock = Arc::new(ManualRuntimeClock::default());
        let mut breakpoint_step = step(
            1,
            MkAction::SetVariable {
                name: "must_not_start".into(),
                value: MkValue::Boolean(true),
            },
        );
        breakpoint_step.breakpoint = true;
        let (_dir, runtime, _guard, _fake) = runtime_with_effects_and_clock(
            vec![test_macro(86, true, vec![breakpoint_step])],
            clock.clone(),
        );
        let observer_clock = clock.clone();
        runtime.install_test_breakpoint_observer(move |control| {
            observer_clock.set_millis(11);
            control.stop();
        });

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(86)),
            CommandResult::Accepted
        );
        let terminal = wait_for_terminal(&runtime);
        assert_eq!(terminal.state, RuntimeState::Stopped);
        assert_eq!(
            wait_for_run_summary(&runtime, terminal.run_id),
            SummaryOutcome::Stopped
        );
        let events = runtime.take_test_events();
        assert!(
            events
                .iter()
                .any(|event| matches!(event, ExecutionEvent::BreakpointHit { step_id: 1, .. }))
        );
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, ExecutionEvent::StepStarted(1)))
        );

        runtime.with_run_summaries(|_, summaries| {
            assert_eq!(summaries.len(), 1);
            let summary = &summaries[0];
            assert_eq!(summary.run_id, terminal.run_id);
            assert_eq!(summary.outcome, SummaryOutcome::Stopped);
            assert_eq!(summary.paused, Duration::from_millis(11));
            assert_eq!(summary.visits.started, 0);
            assert_eq!(summary.visits.succeeded, 0);
            assert_eq!(summary.visits.interrupted, 0);
            assert!(summary.step_aggregates.is_empty());
        });
    }

    #[test]
    fn typed_root_invocation_applies_arguments_defaults_and_subset_only_to_root() {
        use super::super::{MkCallMacroPayload, MkMacroParameter, MkSignatureId, MkValueType};
        let mut root = test_macro(
            1,
            true,
            vec![
                step(
                    1,
                    MkAction::Text(MkTextPayload {
                        text: "skip root row".into(),
                        mode: MkTextMode::Type,
                    }),
                ),
                step(
                    2,
                    MkAction::CallMacro(MkCallMacroPayload {
                        macro_id: 2,
                        ..Default::default()
                    }),
                ),
                step(
                    3,
                    MkAction::Text(MkTextPayload {
                        text: "${parameter}:${defaulted}".into(),
                        mode: MkTextMode::Type,
                    }),
                ),
            ],
        );
        root.signature.parameters = vec![
            MkMacroParameter {
                id: MkSignatureId(1),
                name: "parameter".into(),
                value_type: MkValueType::String,
                input_kind: Default::default(),
                description: String::new(),
                default_value: None,
            },
            MkMacroParameter {
                id: MkSignatureId(2),
                name: "defaulted".into(),
                value_type: MkValueType::String,
                input_kind: Default::default(),
                description: String::new(),
                default_value: Some(MkValue::String("literal ${missing}".into())),
            },
        ];
        let child = test_macro(
            2,
            true,
            vec![step(
                1,
                MkAction::Text(MkTextPayload {
                    text: "full child".into(),
                    mode: MkTextMode::Type,
                }),
            )],
        );
        let (_dir, runtime, _guard, fake) = runtime_with_effects(vec![root, child]);
        let invocation = MkInvocation {
            macro_id: 1,
            arguments: [(MkSignatureId(1), MkValue::String("supplied".into()))]
                .into_iter()
                .collect(),
            mode: ExecutionMode::Normal,
            subset: MkInvocationSubset::From(2),
        };
        assert_eq!(
            runtime.command(RuntimeCommand::Invoke(invocation)),
            CommandResult::Accepted
        );
        let done = wait_for_terminal(&runtime);
        assert_eq!(done.state, RuntimeState::Completed);
        assert_eq!(
            fake.events(),
            ["text:full child", "text:supplied:literal ${missing}"]
        );
        assert_eq!(done.completed_steps, 2);
        assert!(!done.steps.contains_key(&1));
        assert_eq!(
            runtime.command(RuntimeCommand::DebugRunSelection(1, vec![3])),
            CommandResult::Accepted
        );
        let missing = wait_for_terminal_after(&runtime, done.run_id);
        assert_eq!(missing.state, RuntimeState::Failed);
        assert!(
            missing
                .latest_failure
                .as_ref()
                .unwrap()
                .message
                .contains("Required macro parameters")
        );
        assert_eq!(fake.events().len(), 2);
    }

    #[derive(Default)]
    struct PromptGateState {
        entered: bool,
        released: bool,
    }

    /// A worker-facing fake prompt that makes an action stay inside the
    /// executor until the test explicitly releases it.
    #[derive(Default)]
    struct ControllablePromptBackend {
        state: Mutex<PromptGateState>,
        wake: Condvar,
    }

    impl ControllablePromptBackend {
        fn wait_until_entered(&self) {
            let deadline = Instant::now() + Duration::from_secs(10);
            loop {
                if self.state.lock().unwrap().entered {
                    return;
                }
                assert!(
                    Instant::now() < deadline,
                    "controllable prompt action was not entered"
                );
                thread::sleep(Duration::from_millis(2));
            }
        }

        fn release(&self) {
            self.state.lock().unwrap().released = true;
            self.wake.notify_all();
        }
    }

    impl PromptBackend for ControllablePromptBackend {
        fn prompt(&self, _: PromptRequest, _: &RunControl) -> ExecResult<PromptResponse> {
            let mut state = self.state.lock().unwrap();
            state.entered = true;
            self.wake.notify_all();
            while !state.released {
                state = self.wake.wait(state).unwrap();
            }
            Ok(PromptResponse::Submitted("during-action".into()))
        }
    }

    #[test]
    fn active_run_uses_immutable_callee_plan_after_document_publication_changes() {
        let gate = Arc::new(ControllablePromptBackend::default());
        let fake = Arc::new(FakeBackend::default());
        let mut backends = fake.clone().backends();
        backends.prompt = gate.clone();
        let root = test_macro(
            1,
            true,
            vec![
                step(
                    1,
                    MkAction::PromptInput(MkPromptInputPayload {
                        title: "compile boundary".into(),
                        prompt: "wait".into(),
                        default_value: String::new(),
                        variable: "answer".into(),
                        copy_to_clipboard: false,
                    }),
                ),
                step(
                    2,
                    MkAction::CallMacro(super::super::MkCallMacroPayload {
                        macro_id: 2,
                        ..Default::default()
                    }),
                ),
            ],
        );
        let child = test_macro(
            2,
            true,
            vec![step(
                1,
                MkAction::Text(MkTextPayload {
                    text: "captured child".into(),
                    mode: MkTextMode::Type,
                }),
            )],
        );
        let (_directory, runtime, _guard) = runtime_with_backends(vec![root, child], backends);

        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        gate.wait_until_entered();
        let mut changed = (*runtime.store.snapshot()).clone();
        let MkAction::Text(text) = &mut changed.macros[1].steps[0].action else {
            unreachable!()
        };
        text.text = "newly published child".into();
        runtime.store.save(changed).unwrap();
        gate.release();

        assert_eq!(wait_for_terminal(&runtime).state, RuntimeState::Completed);
        assert_eq!(fake.events(), ["text:captured child"]);
        let published = runtime.store.snapshot();
        let MkAction::Text(text) = &published.macros[1].steps[0].action else {
            unreachable!()
        };
        assert_eq!(text.text, "newly published child");
    }

    #[test]
    fn all_six_runtime_subsets_keep_complete_callee_dependencies() {
        use super::super::MkCallMacroPayload;
        for mode in [ExecutionMode::Normal, ExecutionMode::Debug] {
            for subset in [
                MkInvocationSubset::Whole,
                MkInvocationSubset::From(2),
                MkInvocationSubset::Selected(vec![2]),
            ] {
                let text = |value: &str| {
                    MkAction::Text(MkTextPayload {
                        text: value.into(),
                        mode: MkTextMode::Type,
                    })
                };
                let root = test_macro(
                    1,
                    true,
                    vec![
                        step(1, text("root before")),
                        step(
                            2,
                            MkAction::CallMacro(MkCallMacroPayload {
                                macro_id: 2,
                                ..Default::default()
                            }),
                        ),
                        step(3, text("root after")),
                    ],
                );
                let child = test_macro(
                    2,
                    true,
                    vec![step(1, text("child first")), step(2, text("child second"))],
                );
                let (_directory, runtime, _guard, fake) = runtime_with_effects(vec![root, child]);
                let invocation = MkInvocation {
                    macro_id: 1,
                    arguments: MkInvocationValues::new(),
                    mode,
                    subset: subset.clone(),
                };

                assert_eq!(
                    runtime.command(RuntimeCommand::Invoke(invocation)),
                    CommandResult::Accepted
                );
                assert_eq!(wait_for_terminal(&runtime).state, RuntimeState::Completed);
                let expected = match subset {
                    MkInvocationSubset::Whole => vec![
                        "text:root before",
                        "text:child first",
                        "text:child second",
                        "text:root after",
                    ],
                    MkInvocationSubset::From(_) => {
                        vec!["text:child first", "text:child second", "text:root after"]
                    }
                    MkInvocationSubset::Selected(_) => {
                        vec!["text:child first", "text:child second"]
                    }
                };
                assert_eq!(fake.events(), expected);
            }
        }
    }

    fn failure_for(command: RuntimeCommand, macros: Vec<MkMacro>) -> ExecutionDiagnostic {
        let (_dir, runtime, _guard) = runtime_with(macros);
        assert_eq!(runtime.command(command), CommandResult::Accepted);
        wait_for_terminal(&runtime)
            .latest_failure
            .clone()
            .expect("failed run publishes a diagnostic")
    }

    fn wait_for_admission_release(runtime: &MacroRuntime) {
        let deadline = Instant::now() + Duration::from_secs(10);
        while runtime.shared.admission.lock().unwrap().is_some() {
            assert!(Instant::now() < deadline, "admission lock was not released");
            thread::sleep(Duration::from_millis(1));
        }
    }

    fn command_pairs(macro_id: u64) -> Vec<(RuntimeCommand, RuntimeCommand)> {
        vec![
            (
                RuntimeCommand::Run(macro_id),
                RuntimeCommand::DebugRun(macro_id),
            ),
            (
                RuntimeCommand::RunFrom(macro_id, 1),
                RuntimeCommand::DebugRunFrom(macro_id, 1),
            ),
            (
                RuntimeCommand::RunSelection(macro_id, vec![1]),
                RuntimeCommand::DebugRunSelection(macro_id, vec![1]),
            ),
        ]
    }

    #[test]
    fn normal_and_debug_runs_have_equal_target_and_enabled_validation() {
        let normal_missing = failure_for(RuntimeCommand::Run(404), vec![]);
        let debug_missing = failure_for(RuntimeCommand::DebugRun(404), vec![]);
        assert_eq!(normal_missing, debug_missing);
        assert_eq!(normal_missing.kind, DiagnosticKind::TargetNotFound);

        let disabled = test_macro(1, false, vec![]);
        let normal_disabled = failure_for(RuntimeCommand::Run(1), vec![disabled.clone()]);
        let debug_disabled = failure_for(RuntimeCommand::DebugRun(1), vec![disabled]);
        assert_eq!(normal_disabled, debug_disabled);
        assert_eq!(normal_disabled.kind, DiagnosticKind::InvalidTarget);
    }

    #[test]
    fn normal_and_debug_selections_have_equal_empty_and_invalid_validation() {
        let (_dir, runtime, _guard) = runtime_with(vec![]);
        let normal_empty = runtime.command(RuntimeCommand::RunSelection(1, vec![]));
        let debug_empty = runtime.command(RuntimeCommand::DebugRunSelection(1, vec![]));
        assert_eq!(normal_empty, debug_empty);
        assert!(matches!(
            normal_empty,
            CommandResult::Rejected(ExecutionDiagnostic {
                kind: DiagnosticKind::InvalidSelection,
                ..
            })
        ));

        let target = test_macro(1, true, vec![step(1, MkAction::Delay(Default::default()))]);
        let normal_invalid = failure_for(
            RuntimeCommand::RunSelection(1, vec![999]),
            vec![target.clone()],
        );
        let debug_invalid = failure_for(
            RuntimeCommand::DebugRunSelection(1, vec![999]),
            vec![target],
        );
        assert_eq!(normal_invalid, debug_invalid);
        assert_eq!(normal_invalid.kind, DiagnosticKind::TargetNotFound);
    }

    #[test]
    fn normal_and_debug_run_from_reject_structured_plans_equally() {
        let structured_plans = vec![
            vec![
                step(1, MkAction::If(MkCondition::All { conditions: vec![] })),
                step(2, MkAction::Delay(Default::default())),
                step(3, MkAction::EndIf),
            ],
            vec![
                step(1, MkAction::If(MkCondition::All { conditions: vec![] })),
                step(2, MkAction::Delay(Default::default())),
                step(3, MkAction::Else),
                step(4, MkAction::Delay(Default::default())),
                step(5, MkAction::EndIf),
            ],
            vec![
                step(1, MkAction::RepeatStart { count: 1 }),
                step(2, MkAction::Delay(Default::default())),
                step(3, MkAction::RepeatEnd),
            ],
            vec![
                step(
                    1,
                    MkAction::WhileStart {
                        condition: MkCondition::All { conditions: vec![] },
                    },
                ),
                step(2, MkAction::Delay(Default::default())),
                step(3, MkAction::WhileEnd),
            ],
            vec![
                step(1, MkAction::RepeatStart { count: 1 }),
                step(2, MkAction::Break),
                step(3, MkAction::RepeatEnd),
            ],
            vec![
                step(1, MkAction::RepeatStart { count: 1 }),
                step(2, MkAction::Continue),
                step(3, MkAction::RepeatEnd),
            ],
        ];

        for steps in structured_plans {
            let structured = test_macro(1, true, steps);
            assert!(super::super::compile(&structured).is_ok());
            let normal = failure_for(RuntimeCommand::RunFrom(1, 2), vec![structured.clone()]);
            let debug = failure_for(RuntimeCommand::DebugRunFrom(1, 2), vec![structured]);
            assert_eq!(normal, debug);
            assert_eq!(normal.kind, DiagnosticKind::InvalidSelection);
            assert_eq!(
                normal.message,
                "run-from cannot enter a structured control-flow plan"
            );
        }
    }

    #[test]
    fn debug_selected_uses_the_normal_filtered_plan_and_only_selected_breakpoints() {
        let mut selected_two = step(
            2,
            MkAction::Text(MkTextPayload {
                text: "selected two".into(),
                mode: MkTextMode::Type,
            }),
        );
        selected_two.breakpoint = true;
        let mut excluded_three = step(
            3,
            MkAction::Text(MkTextPayload {
                text: "excluded three".into(),
                mode: MkTextMode::Type,
            }),
        );
        excluded_three.breakpoint = true;
        let mut selected_four = step(
            4,
            MkAction::Text(MkTextPayload {
                text: "selected four".into(),
                mode: MkTextMode::Type,
            }),
        );
        selected_four.breakpoint = true;
        let target = test_macro(
            1,
            true,
            vec![
                step(
                    1,
                    MkAction::Text(MkTextPayload {
                        text: "excluded one".into(),
                        mode: MkTextMode::Type,
                    }),
                ),
                selected_two,
                excluded_three,
                selected_four,
            ],
        );
        let selected = vec![4, 2];
        let lifecycle = |events: &[ExecutionEvent]| {
            events
                .iter()
                .filter_map(|event| match event {
                    ExecutionEvent::StepStarted(id) => Some(("started", *id)),
                    ExecutionEvent::StepFinished(id) => Some(("finished", *id)),
                    _ => None,
                })
                .collect::<Vec<_>>()
        };

        let (_normal_dir, normal, _normal_guard, normal_fake) =
            runtime_with_effects(vec![target.clone()]);
        assert_eq!(
            normal.command(RuntimeCommand::RunSelection(1, selected.clone())),
            CommandResult::Accepted
        );
        let normal_completed = wait_for_terminal(&normal);
        let normal_events = normal.take_test_events();
        assert_eq!(normal_completed.run_mode, RuntimeRunMode::Normal);
        assert_eq!(
            normal_completed.steps.keys().copied().collect::<Vec<_>>(),
            [2, 4]
        );
        assert_eq!(normal_completed.total_steps, 2);
        assert_eq!(normal_completed.completed_steps, 2);
        assert_eq!(
            normal_fake.events(),
            ["text:selected two", "text:selected four"]
        );
        assert!(!normal_events.iter().any(|event| {
            matches!(
                event,
                ExecutionEvent::BreakpointHit { .. } | ExecutionEvent::Paused
            )
        }));

        let (_debug_dir, debug, _debug_guard, debug_fake) = runtime_with_effects(vec![target]);
        assert_eq!(
            debug.command(RuntimeCommand::DebugRunSelection(1, selected)),
            CommandResult::Accepted
        );
        let first_pause = wait_for_state(&debug, RuntimeState::Paused);
        assert_eq!(first_pause.run_mode, RuntimeRunMode::Debug);
        assert_eq!(
            first_pause.pause_reason,
            Some(RuntimePauseReason::Breakpoint {
                step_id: 2,
                frame: ExecutionFrameContext::root(1)
            })
        );
        assert_eq!(first_pause.step_id, Some(2));
        assert_eq!(
            first_pause.steps.keys().copied().collect::<Vec<_>>(),
            [2, 4]
        );
        assert_eq!(first_pause.steps[&2], StepState::Pending);
        assert_eq!(first_pause.steps[&4], StepState::Pending);
        assert_eq!(first_pause.total_steps, 2);
        assert_eq!(first_pause.completed_steps, 0);
        assert!(debug_fake.events().is_empty());

        assert_eq!(
            debug.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        let second_pause = wait_for_state(&debug, RuntimeState::Paused);
        assert_eq!(
            second_pause.pause_reason,
            Some(RuntimePauseReason::Breakpoint {
                step_id: 4,
                frame: ExecutionFrameContext::root(1)
            })
        );
        assert_eq!(second_pause.step_id, Some(4));
        assert_eq!(second_pause.steps[&2], StepState::Success);
        assert_eq!(second_pause.steps[&4], StepState::Pending);
        assert_eq!(debug_fake.events(), ["text:selected two"]);

        assert_eq!(
            debug.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        let debug_completed = wait_for_terminal(&debug);
        let debug_events = debug.take_test_events();
        assert_eq!(debug_completed.state, RuntimeState::Completed);
        assert_eq!(debug_completed.run_mode, RuntimeRunMode::Debug);
        assert_eq!(debug_completed.steps, normal_completed.steps);
        assert_eq!(debug_completed.total_steps, normal_completed.total_steps);
        assert_eq!(
            debug_completed.completed_steps,
            normal_completed.completed_steps
        );
        assert_eq!(
            debug_fake.events(),
            ["text:selected two", "text:selected four"]
        );
        assert_eq!(lifecycle(&debug_events), lifecycle(&normal_events));
        assert_eq!(
            debug_events
                .iter()
                .filter_map(|event| match event {
                    ExecutionEvent::BreakpointHit { step_id, .. } => Some(*step_id),
                    _ => None,
                })
                .collect::<Vec<_>>(),
            [2, 4]
        );
        assert!(
            !debug_events
                .iter()
                .any(|event| { matches!(event, ExecutionEvent::BreakpointHit { step_id: 3, .. }) })
        );
        assert!(!debug_completed.steps.contains_key(&1));
        assert!(!debug_completed.steps.contains_key(&3));
        assert!(
            !debug_fake
                .events()
                .iter()
                .any(|event| { event == "text:excluded one" || event == "text:excluded three" })
        );
    }

    #[test]
    fn all_normal_and_debug_pairs_share_recording_and_playback_admission() {
        let target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::Delay(MkDelayPayload {
                    fixed_ms: 60_000,
                    ..Default::default()
                }),
            )],
        );

        for (normal, debug) in command_pairs(1) {
            let (_dir, runtime, guard) = runtime_with(vec![target.clone()]);
            assert!(guard.claim(Operation::Recording));
            let normal_result = runtime.command(normal);
            let debug_result = runtime.command(debug);
            assert_eq!(normal_result, debug_result);
            assert!(matches!(
                normal_result,
                CommandResult::Rejected(ExecutionDiagnostic {
                    kind: DiagnosticKind::InvalidTarget,
                    ..
                })
            ));
            guard.release(Operation::Recording);
        }

        for (normal, debug) in command_pairs(1) {
            let (_dir, normal_runtime, _guard) = runtime_with(vec![target.clone()]);
            assert_eq!(
                normal_runtime.command(RuntimeCommand::Run(1)),
                CommandResult::Accepted
            );
            wait_for_state(&normal_runtime, RuntimeState::Running);
            let normal_result = normal_runtime.command(normal);

            let (_dir, debug_runtime, _guard) = runtime_with(vec![target.clone()]);
            assert_eq!(
                debug_runtime.command(RuntimeCommand::Run(1)),
                CommandResult::Accepted
            );
            wait_for_state(&debug_runtime, RuntimeState::Running);
            let debug_result = debug_runtime.command(debug);

            assert_eq!(normal_result, debug_result);
            assert_eq!(
                normal_result,
                CommandResult::AlreadyRunning { active_macro_id: 1 }
            );
            assert_eq!(
                normal_runtime.command(RuntimeCommand::Stop),
                CommandResult::Accepted
            );
            assert_eq!(
                debug_runtime.command(RuntimeCommand::Stop),
                CommandResult::Accepted
            );
            assert_eq!(
                wait_for_terminal(&normal_runtime).state,
                RuntimeState::Stopped
            );
            assert_eq!(
                wait_for_terminal(&debug_runtime).state,
                RuntimeState::Stopped
            );
        }
    }

    #[test]
    fn debug_controls_match_normal_playback_controls() {
        let target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::Delay(MkDelayPayload {
                    fixed_ms: 60_000,
                    ..Default::default()
                }),
            )],
        );
        let (_dir, runtime, _guard) = runtime_with(vec![target]);
        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        wait_for_state(&runtime, RuntimeState::Running);
        assert_eq!(
            runtime.command(RuntimeCommand::Pause),
            CommandResult::Accepted
        );
        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        assert_eq!(wait_for_terminal(&runtime).state, RuntimeState::Stopped);
    }

    #[test]
    fn manual_pause_and_resume_publish_reason_in_the_state_transition() {
        let target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::Delay(MkDelayPayload {
                    fixed_ms: 60_000,
                    ..Default::default()
                }),
            )],
        );
        let (_dir, runtime, _guard) = runtime_with(vec![target]);

        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        wait_for_state(&runtime, RuntimeState::Running);
        assert_eq!(
            runtime.command(RuntimeCommand::Pause),
            CommandResult::Accepted
        );
        let paused = runtime.snapshot();
        assert_eq!(paused.state, RuntimeState::Paused);
        assert_eq!(paused.pause_reason, Some(RuntimePauseReason::User));

        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        let resumed = runtime.snapshot();
        assert_eq!(resumed.state, RuntimeState::Running);
        assert_eq!(resumed.pause_reason, None);

        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        assert_eq!(wait_for_terminal(&runtime).pause_reason, None);
    }

    #[test]
    fn breakpoint_resume_clears_reason_in_the_running_transition() {
        let mut breakpoint = step(
            7,
            MkAction::Delay(MkDelayPayload {
                fixed_ms: 60_000,
                ..Default::default()
            }),
        );
        breakpoint.breakpoint = true;
        let target = test_macro(1, true, vec![breakpoint]);
        let (_dir, runtime, _guard) = runtime_with(vec![target]);

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let paused = wait_for_state(&runtime, RuntimeState::Paused);
        assert_eq!(
            paused.pause_reason,
            Some(RuntimePauseReason::Breakpoint {
                step_id: 7,
                frame: ExecutionFrameContext::root(1)
            })
        );

        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        let resumed = runtime.snapshot();
        assert_eq!(resumed.state, RuntimeState::Running);
        assert_eq!(resumed.pause_reason, None);

        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        assert_eq!(wait_for_terminal(&runtime).pause_reason, None);
    }

    #[test]
    fn normal_execution_completely_ignores_persisted_breakpoint_metadata() {
        let mut set_variable = step(
            1,
            MkAction::SetVariable {
                name: "ready".into(),
                value: MkValue::Boolean(true),
            },
        );
        set_variable.breakpoint = true;
        let mut mouse_move = step(
            2,
            MkAction::MouseMove(MkMouseMovePayload {
                target: MkCoordinateTarget::Screen {
                    point: MkPoint { x: 37, y: 91 },
                },
                duration_ms: 0,
            }),
        );
        mouse_move.breakpoint = true;
        let (_dir, runtime, _guard, fake) =
            runtime_with_effects(vec![test_macro(1, true, vec![set_variable, mouse_move])]);

        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        let completed = wait_for_terminal(&runtime);
        let events = runtime.take_test_events();

        assert_eq!(completed.state, RuntimeState::Completed);
        assert_ne!(completed.state, RuntimeState::Paused);
        assert_eq!(completed.pause_reason, None);
        assert_eq!(completed.steps[&1], StepState::Success);
        assert_eq!(completed.steps[&2], StepState::Success);
        assert_eq!(completed.completed_steps, 2);
        assert_eq!(completed.total_steps, 2);
        assert_eq!(fake.events(), ["move:37,91"]);
        assert!(events.iter().all(|event| {
            !matches!(
                event,
                ExecutionEvent::BreakpointHit { .. } | ExecutionEvent::Paused
            )
        }));
        assert!(matches!(
            events.as_slice(),
            [
                ExecutionEvent::StepStarted(1),
                ExecutionEvent::StepFinished(1),
                ExecutionEvent::StepStarted(2),
                ExecutionEvent::StepFinished(2),
            ]
        ));
    }

    #[test]
    fn breakpoint_snapshot_resume_executes_once_and_worker_accepts_next_run() {
        let mut breakpoint = step(
            1,
            MkAction::MouseClick(MkMousePayload {
                target: MkCoordinateTarget::Screen {
                    point: MkPoint { x: 10, y: 20 },
                },
                button: MkMouseButton::Left,
                clicks: 1,
            }),
        );
        breakpoint.breakpoint = true;
        let target = test_macro(1, true, vec![breakpoint]);
        let (_dir, runtime, _guard, fake) = runtime_with_effects(vec![target]);

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let paused = wait_for_state(&runtime, RuntimeState::Paused);
        assert_eq!(
            paused.revision, 4,
            "run initialization, FrameEntered, RunStarted, and BreakpointHit must each publish one revision"
        );
        assert_eq!(paused.step_id, Some(1));
        assert_eq!(paused.steps[&1], StepState::Pending);
        assert_eq!(
            paused.pause_reason,
            Some(RuntimePauseReason::Breakpoint {
                step_id: 1,
                frame: ExecutionFrameContext::root(1)
            })
        );
        let debug = paused.debug_snapshot.as_ref().unwrap();
        assert_eq!(debug.step_id, Some(1));
        assert_eq!(debug.reason, DebugSnapshotReason::Breakpoint);
        assert_eq!(debug.variables.get("macro.id"), Some(&MkValue::Number(1.0)));
        assert_eq!(
            debug.variables.get("last_action_success"),
            Some(&MkValue::Boolean(true))
        );
        assert_eq!(debug.variables.get("step.id"), Some(&MkValue::Number(1.0)));
        assert!(fake.events().is_empty());
        assert_eq!(
            runtime.command(RuntimeCommand::Pause),
            CommandResult::Rejected(ExecutionDiagnostic::new(
                DiagnosticKind::InvalidTarget,
                "command Pause is not valid while runtime is Paused",
            ))
        );
        assert_eq!(
            runtime.command(RuntimeCommand::Pause),
            CommandResult::Rejected(ExecutionDiagnostic::new(
                DiagnosticKind::InvalidTarget,
                "command Pause is not valid while runtime is Paused",
            ))
        );
        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        let completed = wait_for_terminal(&runtime);
        let first_run_events = runtime.take_test_events();
        assert_eq!(completed.state, RuntimeState::Completed);
        assert_eq!(completed.pause_reason, None);
        assert_eq!(completed.steps[&1], StepState::Success);
        assert_eq!(
            first_run_events
                .iter()
                .filter(|event| matches!(event, ExecutionEvent::BreakpointHit { .. }))
                .count(),
            1
        );
        assert_eq!(
            fake.events()
                .iter()
                .filter(|event| *event == "button_down:Left")
                .count(),
            1
        );
        assert_eq!(
            fake.events()
                .iter()
                .filter(|event| *event == "button_up:Left")
                .count(),
            1
        );

        wait_for_admission_release(&runtime);
        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        assert_eq!(
            wait_for_terminal_after(&runtime, completed.run_id).state,
            RuntimeState::Completed
        );
        assert_eq!(
            fake.events()
                .iter()
                .filter(|event| *event == "button_down:Left")
                .count(),
            2,
        );
        assert_eq!(
            fake.events()
                .iter()
                .filter(|event| *event == "button_up:Left")
                .count(),
            2,
        );
        assert_eq!(
            fake.events()
                .iter()
                .filter(|event| *event == "move:10,20")
                .count(),
            2,
            "the same runtime worker must remain usable without a debugger worker"
        );
    }

    #[test]
    fn breakpoint_snapshot_stop_cancels_before_dispatch_and_worker_is_reusable() {
        let held_button = step(1, MkAction::MouseDown(MkMouseButton::Left));
        let mut breakpoint = step(
            2,
            MkAction::MouseClick(MkMousePayload {
                target: MkCoordinateTarget::Screen {
                    point: MkPoint { x: 10, y: 20 },
                },
                button: MkMouseButton::Left,
                clicks: 1,
            }),
        );
        breakpoint.breakpoint = true;
        let target = test_macro(1, true, vec![held_button, breakpoint]);
        let harmless = test_macro(
            2,
            true,
            vec![step(
                1,
                MkAction::SetVariable {
                    name: "harmless".into(),
                    value: MkValue::Boolean(true),
                },
            )],
        );
        let (_dir, runtime, _guard, fake) = runtime_with_effects(vec![target, harmless]);

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let paused = wait_for_state(&runtime, RuntimeState::Paused);
        assert_eq!(
            paused.pause_reason,
            Some(RuntimePauseReason::Breakpoint {
                step_id: 2,
                frame: ExecutionFrameContext::root(1)
            })
        );
        assert_eq!(paused.step_id, Some(2));
        assert_eq!(paused.steps[&1], StepState::Success);
        assert_eq!(paused.steps[&2], StepState::Pending);
        assert_eq!(fake.events(), ["button_down:Left"]);
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        let stopping = runtime.snapshot();
        assert!(matches!(
            stopping.state,
            RuntimeState::Stopping | RuntimeState::Stopped
        ));
        assert_eq!(stopping.pause_reason, None);
        let stopped = wait_for_terminal(&runtime);
        assert_eq!(stopped.state, RuntimeState::Stopped);
        assert_eq!(stopped.pause_reason, None);
        assert_eq!(stopped.latest_failure, None);
        assert_eq!(stopped.steps[&2], StepState::Pending);
        assert_eq!(
            fake.events(),
            ["button_down:Left", "button_up:Left"],
            "stopping at the breakpoint must clean up input owned by an earlier step"
        );
        assert!(!fake.events().iter().any(|event| event.starts_with("move:")));
        let stopped_events = runtime.take_test_events();
        assert!(
            stopped_events
                .iter()
                .any(|event| matches!(event, ExecutionEvent::BreakpointHit { step_id: 2, .. }))
        );
        assert!(
            !stopped_events
                .iter()
                .any(|event| matches!(event, ExecutionEvent::StepFinished(2)))
        );
        assert!(
            !stopped_events
                .iter()
                .any(|event| matches!(event, ExecutionEvent::StepFailed(2, _)))
        );
        assert!(stopped_events.iter().any(|event| {
            matches!(
                event,
                ExecutionEvent::DebugVariables {
                    reason: DebugSnapshotReason::RunCancelled,
                    ..
                }
            )
        }));

        wait_for_admission_release(&runtime);
        assert_eq!(
            runtime.command(RuntimeCommand::Run(2)),
            CommandResult::Accepted
        );
        assert_eq!(
            wait_for_terminal_after(&runtime, stopped.run_id).state,
            RuntimeState::Completed
        );
        assert_eq!(
            fake.events(),
            ["button_down:Left", "button_up:Left"],
            "a harmless follow-up run proves the stopped worker released the breakpoint wait"
        );
    }

    #[test]
    fn queued_manual_pause_cannot_replace_a_breakpoint_reason() {
        let mut breakpoint = step(
            19,
            MkAction::Delay(MkDelayPayload {
                fixed_ms: 60_000,
                ..Default::default()
            }),
        );
        breakpoint.breakpoint = true;
        let target = test_macro(1, true, vec![breakpoint]);
        let (_dir, runtime, _guard) = runtime_with(vec![target]);

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        wait_for_state(&runtime, RuntimeState::Paused);

        // Models a manual Paused event that was queued before BreakpointHit but
        // delivered afterward by either the command or executor event path.
        publish_manual_pause(&runtime.shared);
        let paused = runtime.snapshot();
        assert_eq!(paused.state, RuntimeState::Paused);
        assert_eq!(
            paused.pause_reason,
            Some(RuntimePauseReason::Breakpoint {
                step_id: 19,
                frame: ExecutionFrameContext::root(1)
            })
        );

        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        assert_eq!(wait_for_terminal(&runtime).pause_reason, None);
    }

    #[test]
    fn manual_pause_retains_last_safe_debug_snapshot_until_next_boundary() {
        let target = test_macro(
            1,
            true,
            vec![
                step(
                    1,
                    MkAction::SetVariable {
                        name: "safe".into(),
                        value: MkValue::String("before action".into()),
                    },
                ),
                step(
                    2,
                    MkAction::PromptInput(MkPromptInputPayload {
                        title: "Controlled action".into(),
                        prompt: "wait".into(),
                        default_value: String::new(),
                        variable: "partial".into(),
                        copy_to_clipboard: false,
                    }),
                ),
                step(
                    3,
                    MkAction::Delay(MkDelayPayload {
                        fixed_ms: 60_000,
                        ..Default::default()
                    }),
                ),
            ],
        );
        let fake = Arc::new(FakeBackend::default());
        let prompt = Arc::new(ControllablePromptBackend::default());
        let mut backends = fake.backends();
        backends.prompt = prompt.clone();
        let (_dir, runtime, _guard) = runtime_with_backends(vec![target], backends);

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let safe_boundary =
            wait_for_debug_boundary(&runtime, Some(1), DebugSnapshotReason::StepBoundary);
        prompt.wait_until_entered();

        assert_eq!(
            runtime.command(RuntimeCommand::Pause),
            CommandResult::Accepted
        );
        let paused = runtime.snapshot();
        assert_eq!(paused.state, RuntimeState::Paused);
        assert_eq!(paused.pause_reason, Some(RuntimePauseReason::User));
        assert_eq!(paused.step_id, Some(2));
        let paused_debug = paused
            .debug_snapshot
            .as_ref()
            .expect("Debug playback retains the last safe boundary while paused");
        assert!(
            Arc::ptr_eq(paused_debug, safe_boundary.debug_snapshot.as_ref().unwrap()),
            "manual Pause must not replace the immutable debug snapshot"
        );
        assert_eq!(paused_debug.step_id, Some(1));
        assert_eq!(paused_debug.reason, DebugSnapshotReason::StepBoundary);
        assert_eq!(
            paused_debug.variables.get("safe"),
            Some(&MkValue::String("before action".into()))
        );
        assert!(
            !paused_debug.variables.contains_key("partial"),
            "variables written only after the action returns must not be exposed"
        );

        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        prompt.release();
        let next_boundary =
            wait_for_debug_boundary(&runtime, Some(2), DebugSnapshotReason::StepBoundary);
        let next_debug = next_boundary.debug_snapshot.as_ref().unwrap();
        assert!(!Arc::ptr_eq(next_debug, paused_debug));
        assert_eq!(
            next_debug.variables.get("partial"),
            Some(&MkValue::String("during-action".into()))
        );
        assert_eq!(next_debug.reason, DebugSnapshotReason::StepBoundary);

        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        assert_eq!(wait_for_terminal(&runtime).state, RuntimeState::Stopped);
    }

    #[test]
    fn normal_manual_pause_does_not_reuse_debug_data_from_an_earlier_run() {
        let debug_target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::SetVariable {
                    name: "debug_only".into(),
                    value: MkValue::String("from Debug run".into()),
                },
            )],
        );
        let normal_target = test_macro(
            2,
            true,
            vec![step(
                1,
                MkAction::PromptInput(MkPromptInputPayload {
                    title: "Controlled action".into(),
                    prompt: "wait".into(),
                    default_value: String::new(),
                    variable: "normal_value".into(),
                    copy_to_clipboard: false,
                }),
            )],
        );
        let fake = Arc::new(FakeBackend::default());
        let prompt = Arc::new(ControllablePromptBackend::default());
        let mut backends = fake.backends();
        backends.prompt = prompt.clone();
        let (_dir, runtime, _guard) =
            runtime_with_backends(vec![debug_target, normal_target], backends);

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let previous = wait_for_terminal(&runtime);
        let previous_debug = previous
            .debug_snapshot
            .as_ref()
            .expect("Debug run should publish a terminal snapshot");
        assert_eq!(previous_debug.reason, DebugSnapshotReason::RunFinished);
        assert_eq!(
            previous_debug.variables.get("debug_only"),
            Some(&MkValue::String("from Debug run".into()))
        );
        wait_for_admission_release(&runtime);

        assert_eq!(
            runtime.command(RuntimeCommand::Run(2)),
            CommandResult::Accepted
        );
        prompt.wait_until_entered();
        assert_eq!(
            runtime.command(RuntimeCommand::Pause),
            CommandResult::Accepted
        );
        let paused = runtime.snapshot();
        assert_eq!(paused.run_mode, RuntimeRunMode::Normal);
        assert_eq!(paused.pause_reason, Some(RuntimePauseReason::User));
        assert!(
            paused.debug_snapshot.is_none(),
            "Normal playback has no debug map or snapshot reason, even after a prior Debug run"
        );

        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        prompt.release();
        assert_eq!(wait_for_terminal(&runtime).state, RuntimeState::Completed);
    }

    #[test]
    fn breakpoint_terminal_failure_and_completion_clear_reason() {
        for fail in [false, true] {
            let mut breakpoint = step(
                1,
                MkAction::Text(MkTextPayload {
                    text: "terminal transition".into(),
                    mode: MkTextMode::Type,
                }),
            );
            breakpoint.breakpoint = true;
            let target = test_macro(1, true, vec![breakpoint]);
            let (_dir, runtime, _guard, fake) = runtime_with_effects(vec![target]);
            if fail {
                fake.fail(
                    "text:terminal transition",
                    ExecutionDiagnostic::new(DiagnosticKind::Backend, "injected failure"),
                );
            }

            assert_eq!(
                runtime.command(RuntimeCommand::DebugRun(1)),
                CommandResult::Accepted
            );
            let paused = wait_for_state(&runtime, RuntimeState::Paused);
            assert_eq!(
                paused.pause_reason,
                Some(RuntimePauseReason::Breakpoint {
                    step_id: 1,
                    frame: ExecutionFrameContext::root(1)
                })
            );
            assert_eq!(
                runtime.command(RuntimeCommand::Resume),
                CommandResult::Accepted
            );
            let terminal = wait_for_terminal(&runtime);
            assert_eq!(
                terminal.state,
                if fail {
                    RuntimeState::Failed
                } else {
                    RuntimeState::Completed
                }
            );
            assert_eq!(terminal.pause_reason, None);
        }
    }

    #[test]
    fn run_after_breakpoint_starts_without_a_stale_reason() {
        let mut breakpoint = step(
            23,
            MkAction::Delay(MkDelayPayload {
                fixed_ms: 60_000,
                ..Default::default()
            }),
        );
        breakpoint.breakpoint = true;
        let target = test_macro(1, true, vec![breakpoint]);
        let (_dir, runtime, _guard) = runtime_with(vec![target]);

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        wait_for_state(&runtime, RuntimeState::Paused);
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        let stopped = wait_for_terminal(&runtime);
        assert_eq!(stopped.pause_reason, None);
        wait_for_admission_release(&runtime);

        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        let running = wait_for_state(&runtime, RuntimeState::Running);
        assert!(running.run_id > stopped.run_id);
        assert_eq!(running.pause_reason, None);

        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        assert_eq!(wait_for_terminal(&runtime).pause_reason, None);
    }

    #[test]
    fn snapshots_publish_each_mode_without_leaking_between_runs() {
        assert_eq!(RuntimeSnapshot::default().run_mode, RuntimeRunMode::Normal);
        let target = test_macro(1, true, vec![step(1, MkAction::Delay(Default::default()))]);
        let (_dir, runtime, _guard) = runtime_with(vec![target]);

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let debug_snapshot = wait_for_terminal(&runtime);
        assert_eq!(debug_snapshot.run_mode, RuntimeRunMode::Debug);
        wait_for_admission_release(&runtime);

        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let snapshot = runtime.snapshot();
            if snapshot.run_id > debug_snapshot.run_id && snapshot.state == RuntimeState::Completed
            {
                assert_eq!(snapshot.run_mode, RuntimeRunMode::Normal);
                break;
            }
            assert!(
                Instant::now() < deadline,
                "normal run did not replace debug snapshot: {snapshot:?}"
            );
            thread::sleep(Duration::from_millis(2));
        }
    }

    #[test]
    fn preview_terminal_snapshot_survives_a_later_stored_run() {
        let target = test_macro(1, true, vec![step(1, MkAction::Delay(Default::default()))]);
        let document = MkMacroDocument {
            macros: vec![target.clone()],
            ..Default::default()
        };
        let (_dir, runtime, _guard) = runtime_with(vec![target]);

        runtime.preview(&document, 1, 77).unwrap();
        let preview = wait_for_terminal(&runtime);
        assert_eq!(
            preview.origin,
            RuntimeOrigin::RecordingPreview { ticket: 77 }
        );
        wait_for_admission_release(&runtime);

        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        let stored = wait_for_terminal_after(&runtime, preview.run_id);
        assert_eq!(stored.origin, RuntimeOrigin::Stored);
        let (active, retained) = runtime.recording_preview_status(77);
        assert!(!active);
        assert_eq!(retained.unwrap().run_id, preview.run_id);
    }

    #[test]
    fn preview_requires_a_prepared_program_and_stops_only_its_exact_ticket() {
        let target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::Delay(MkDelayPayload {
                    fixed_ms: 1_000,
                    ..Default::default()
                }),
            )],
        );
        let document = MkMacroDocument {
            macros: vec![target.clone()],
            ..Default::default()
        };
        let (_dir, runtime, _guard) = runtime_with(vec![target]);
        assert!(matches!(
            runtime.command(RuntimeCommand::RecordingPreview {
                macro_id: 1,
                ticket: 41,
            }),
            CommandResult::Rejected(ExecutionDiagnostic {
                kind: DiagnosticKind::InvalidPlan,
                ..
            })
        ));

        runtime.preview(&document, 1, 42).unwrap();
        assert!(!runtime.stop_recording_preview(41));
        assert!(runtime.stop_recording_preview(42));
        let stopped = wait_for_terminal(&runtime);
        assert_eq!(
            stopped.origin,
            RuntimeOrigin::RecordingPreview { ticket: 42 }
        );
        assert_eq!(stopped.state, RuntimeState::Stopped);
    }

    #[test]
    fn preview_executes_the_ephemeral_program_without_publishing_it() {
        let stored = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::Text(MkTextPayload {
                    text: "stored".into(),
                    mode: MkTextMode::Type,
                }),
            )],
        );
        let preview = test_macro(
            1,
            true,
            vec![
                step(
                    10,
                    MkAction::Text(MkTextPayload {
                        text: "preview A".into(),
                        mode: MkTextMode::Type,
                    }),
                ),
                step(
                    20,
                    MkAction::Text(MkTextPayload {
                        text: "preview B".into(),
                        mode: MkTextMode::Type,
                    }),
                ),
            ],
        );
        let document = MkMacroDocument {
            macros: vec![preview],
            ..Default::default()
        };
        let (dir, runtime, _guard, fake) = runtime_with_effects(vec![stored.clone()]);
        let persisted_before = runtime.store.snapshot();
        let macro_file = dir.path().join(MKMACROS_FILE);
        let bytes_before = fs::read(&macro_file).unwrap();

        runtime.preview(&document, 1, 81).unwrap();
        let completed = wait_for_terminal(&runtime);

        assert_eq!(completed.state, RuntimeState::Completed);
        assert_eq!(
            completed.origin,
            RuntimeOrigin::RecordingPreview { ticket: 81 }
        );
        assert_eq!(fake.events(), ["text:preview A", "text:preview B"]);
        assert_eq!(runtime.store.snapshot(), persisted_before);
        assert_eq!(runtime.store.snapshot().macros[0], stored);
        assert_eq!(fs::read(macro_file).unwrap(), bytes_before);
    }

    #[test]
    fn stopping_preview_releases_owned_keyboard_and_mouse_input() {
        let target = test_macro(
            1,
            true,
            vec![
                step(1, MkAction::KeyDown(MkKey::Control)),
                step(2, MkAction::MouseDown(MkMouseButton::Left)),
                step(
                    3,
                    MkAction::Delay(MkDelayPayload {
                        fixed_ms: 60_000,
                        ..Default::default()
                    }),
                ),
            ],
        );
        let document = MkMacroDocument {
            macros: vec![target.clone()],
            ..Default::default()
        };
        let (_dir, runtime, _guard, fake) = runtime_with_effects(vec![target]);
        runtime.preview(&document, 1, 82).unwrap();
        let deadline = Instant::now() + Duration::from_secs(10);
        while fake.events().len() < 2 {
            assert!(Instant::now() < deadline, "preview did not acquire input");
            thread::sleep(Duration::from_millis(2));
        }

        assert!(runtime.stop_recording_preview(82));
        let stopped = wait_for_terminal(&runtime);

        assert_eq!(stopped.state, RuntimeState::Stopped);
        assert_eq!(
            fake.events(),
            [
                "key_down:Control",
                "button_down:Left",
                "button_up:Left",
                "key_up:Control"
            ]
        );
    }

    #[test]
    fn preview_admission_conflicts_with_recording_and_stored_playback_both_ways() {
        let target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::Delay(MkDelayPayload {
                    fixed_ms: 60_000,
                    ..Default::default()
                }),
            )],
        );
        let document = MkMacroDocument {
            macros: vec![target.clone()],
            ..Default::default()
        };
        let (_dir, runtime, guard) = runtime_with(vec![target]);

        assert!(guard.claim(Operation::Recording));
        assert!(matches!(
            runtime.preview(&document, 1, 90),
            Err(ExecutionDiagnostic {
                kind: DiagnosticKind::InvalidTarget,
                ..
            })
        ));
        guard.release(Operation::Recording);
        runtime.with_run_summaries(|revision, summaries| {
            assert_eq!(revision, 0);
            assert!(summaries.is_empty(), "rejected preview is not admitted");
        });

        runtime.preview(&document, 1, 91).unwrap();
        assert!(matches!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::AlreadyRunning { active_macro_id: 1 }
        ));
        assert!(runtime.stop_recording_preview(91));
        let preview = wait_for_terminal(&runtime);
        wait_for_admission_release(&runtime);
        runtime.with_run_summaries(|_, summaries| {
            let summary = summaries
                .iter()
                .find(|summary| summary.run_id == preview.run_id)
                .unwrap();
            assert_eq!(
                summary.invocation_source,
                InvocationSource::RecordingPreview
            );
            assert_eq!(
                summary.origin,
                RuntimeOrigin::RecordingPreview { ticket: 91 }
            );
            assert_eq!(summary.outcome, SummaryOutcome::Stopped);
        });

        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        let running = wait_for_state(&runtime, RuntimeState::Running);
        assert!(running.run_id > preview.run_id);
        assert!(matches!(
            runtime.preview(&document, 1, 92),
            Err(ExecutionDiagnostic {
                kind: DiagnosticKind::RuntimeUnavailable,
                ..
            })
        ));
        assert!(!runtime.stop_recording_preview(91));
        assert_eq!(runtime.snapshot().state, RuntimeState::Running);
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        assert_eq!(wait_for_terminal(&runtime).state, RuntimeState::Stopped);
    }

    #[test]
    fn admitted_preview_blocks_real_recorder_until_exact_ticket_stop_releases_guard() {
        let target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::Delay(MkDelayPayload {
                    fixed_ms: 60_000,
                    ..Default::default()
                }),
            )],
        );
        let document = MkMacroDocument {
            macros: vec![target.clone()],
            ..Default::default()
        };
        let dir = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(dir.path()).unwrap();
        store
            .save(MkMacroDocument {
                macros: vec![target],
                ..Default::default()
            })
            .unwrap();
        let store = Arc::new(store);
        let guard = Arc::new(SharedOperationGuard::default());
        let runtime = MacroRuntime::with_guard(
            store.clone(),
            Arc::new(FakeBackend::default()).backends(),
            guard.clone(),
        );
        let recorder = RecorderRuntime::with_guard_and_components(
            store,
            crate::mkmacro::HookService::with_adapter(AckHookLoop, 8),
            Arc::new(FixedRecorderClock),
            guard,
            Box::new(NoTextTranslator),
            Arc::new(empty_recorder_observer),
            Box::new(NoContextEnricher),
        );
        let barrier = runtime.install_test_worker_barrier();

        runtime.preview(&document, 1, 94).unwrap();
        barrier.wait_until_blocked();
        let error = recorder
            .start_target(
                RecordingTarget {
                    macro_id: 1,
                    insertion_anchor_step_id: None,
                    insertion_anchor_generation: None,
                },
                NormalizationConfig::default(),
                Vec::new(),
            )
            .unwrap_err();
        assert!(error.to_string().contains("playback is active"));

        assert!(runtime.stop_recording_preview(94));
        barrier.release();
        assert_eq!(wait_for_terminal(&runtime).state, RuntimeState::Stopped);
        wait_for_admission_release(&runtime);
        recorder
            .start_target(
                RecordingTarget {
                    macro_id: 1,
                    insertion_anchor_step_id: None,
                    insertion_anchor_generation: None,
                },
                NormalizationConfig::default(),
                Vec::new(),
            )
            .unwrap();
        assert_eq!(recorder.stop().unwrap().target.macro_id, 1);
    }

    #[test]
    fn owned_hotfolder_run_preserves_user_admission_and_cancels_exact_pending_id() {
        let target = test_macro(
            701,
            true,
            vec![step(
                1,
                MkAction::Text(MkTextPayload {
                    text: "user run remains owned".into(),
                    mode: MkTextMode::Type,
                }),
            )],
        );

        let (_user_dir, user_runtime, _user_guard, user_backend) =
            runtime_with_effects(vec![target.clone()]);
        let user_runtime = Arc::new(user_runtime);
        let user_barrier = user_runtime.install_test_worker_barrier();
        assert_eq!(
            user_runtime.command(RuntimeCommand::Run(target.id)),
            CommandResult::Accepted
        );
        user_barrier.wait_until_blocked();
        let user_run_id = user_runtime
            .shared
            .admission
            .lock()
            .unwrap()
            .as_ref()
            .expect("user run is admitted before worker start")
            .run_id;
        assert!(matches!(
            user_runtime.start_owned_hotfolder_macro(&target, std::slice::from_ref(&target)),
            Err(ExecutionDiagnostic {
                kind: DiagnosticKind::RuntimeUnavailable,
                ..
            })
        ));
        assert_eq!(
            user_runtime
                .shared
                .admission
                .lock()
                .unwrap()
                .as_ref()
                .map(|active| active.run_id),
            Some(user_run_id)
        );
        user_barrier.release();
        let user_terminal = wait_for_terminal(&user_runtime);
        assert_eq!(user_terminal.run_id, user_run_id);
        assert_eq!(user_terminal.state, RuntimeState::Completed);
        assert_eq!(user_backend.events(), ["text:user run remains owned"]);
        user_runtime.with_run_summaries(|_, summaries| {
            assert_eq!(summaries.len(), 1);
            assert_eq!(summaries[0].run_id, user_run_id);
            assert_eq!(
                summaries[0].invocation_source,
                InvocationSource::UnclassifiedApi
            );
        });

        let root = test_macro(
            702,
            true,
            vec![step(
                1,
                MkAction::CallMacro(crate::mkmacro::MkCallMacroPayload {
                    macro_id: 703,
                    ..Default::default()
                }),
            )],
        );
        let child = test_macro(
            703,
            true,
            vec![step(1, MkAction::Delay(MkDelayPayload::default()))],
        );
        let validated_document = crate::mkmacro::MkMacroDocument {
            macros: vec![root.clone(), child.clone()],
            ..Default::default()
        };
        let (validated_action, validated_dependencies) =
            crate::hotfolder::bind_mkmacro_action_with_dependencies(&validated_document, root.id)
                .expect("capture the validated dependency closure");
        assert!(matches!(
            validated_action,
            crate::hotfolder::RuleAction::MkMacro { .. }
        ));
        let mut edited_child = child;
        edited_child.steps[0].action = MkAction::Process(crate::mkmacro::MkProcessPayload {
            program: r"C:\Fixture\unsafe.exe".into(),
            arguments: Vec::new(),
            working_directory: None,
            wait: false,
        });
        let (_race_dir, raced_runtime, _race_guard, _race_backend) =
            runtime_with_effects(vec![root.clone(), edited_child]);
        let raced_runtime = Arc::new(raced_runtime);
        assert!(matches!(
            raced_runtime.start_owned_hotfolder_macro(&root, &validated_dependencies),
            Err(ExecutionDiagnostic {
                kind: DiagnosticKind::InvalidTarget,
                ..
            })
        ));
        assert!(
            raced_runtime.shared.admission.lock().unwrap().is_none(),
            "an edited transitive dependency must fail before run admission"
        );

        let (_owned_dir, owned_runtime, _owned_guard, owned_backend) =
            runtime_with_effects(vec![target.clone()]);
        let owned_runtime = Arc::new(owned_runtime);
        let owned_barrier = owned_runtime.install_test_worker_barrier();
        let owned = owned_runtime
            .start_owned_hotfolder_macro(&target, std::slice::from_ref(&target))
            .expect("owned invocation is admitted");
        owned_barrier.wait_until_blocked();
        let owned_run_id = owned.run_id();
        assert!(matches!(
            owned_runtime.command(RuntimeCommand::Run(target.id)),
            CommandResult::AlreadyRunning {
                active_macro_id: 701
            }
        ));

        let cancellation = crate::file_operations::ScanCancellation::new();
        cancellation.cancel();
        assert!(!owned.activate_if_not_cancelled(&cancellation));
        assert!(owned.stop_if_current());
        owned_barrier.release();
        let terminal = owned
            .wait_completion(Duration::from_secs(2))
            .expect("owned invocation returns its exact terminal receipt");
        assert_eq!(terminal.run_id, owned_run_id);
        assert_eq!(terminal.macro_id, target.id);
        assert_eq!(terminal.state, RuntimeState::Stopped);
        assert!(owned_backend.events().is_empty());
        assert_eq!(owned_runtime.snapshot().run_id, owned_run_id);
        owned_runtime.with_run_summaries(|_, summaries| {
            assert_eq!(summaries.len(), 1);
            assert_eq!(summaries[0].run_id, owned_run_id);
            assert_eq!(summaries[0].invocation_source, InvocationSource::HotFolder);
            assert_eq!(summaries[0].outcome, SummaryOutcome::Stopped);
        });

        let next_barrier = owned_runtime.install_test_worker_barrier();
        assert_eq!(
            owned_runtime.command(RuntimeCommand::Run(target.id)),
            CommandResult::Accepted
        );
        next_barrier.wait_until_blocked();
        let next_run_id = owned_runtime
            .shared
            .admission
            .lock()
            .unwrap()
            .as_ref()
            .expect("next user run is admitted")
            .run_id;
        assert!(next_run_id > owned_run_id);
        assert!(!owned.stop_if_current());
        assert_eq!(
            owned_runtime
                .shared
                .admission
                .lock()
                .unwrap()
                .as_ref()
                .map(|active| active.run_id),
            Some(next_run_id)
        );
        next_barrier.release();
        assert_eq!(
            wait_for_terminal_after(&owned_runtime, owned_run_id).state,
            RuntimeState::Completed
        );
    }

    #[test]
    fn failed_preview_retains_diagnostic_for_its_exact_ticket() {
        let target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::Text(MkTextPayload {
                    text: "fail preview".into(),
                    mode: MkTextMode::Type,
                }),
            )],
        );
        let document = MkMacroDocument {
            macros: vec![target.clone()],
            ..Default::default()
        };
        let (_dir, runtime, _guard, fake) = runtime_with_effects(vec![target]);
        let expected = ExecutionDiagnostic::new(DiagnosticKind::Backend, "preview failed")
            .context("operation", "recording preview")
            .context("ticket", "93");
        fake.fail("text:fail preview", expected.clone());

        runtime.preview(&document, 1, 93).unwrap();
        let failed = wait_for_terminal(&runtime);
        let (active, retained) = runtime.recording_preview_status(93);

        assert_eq!(failed.state, RuntimeState::Failed);
        assert_eq!(
            failed.origin,
            RuntimeOrigin::RecordingPreview { ticket: 93 }
        );
        let failure = failed.latest_failure.as_ref().unwrap();
        assert_eq!(failure.kind, DiagnosticKind::Backend);
        assert_eq!(failure.message, "preview failed");
        for (key, value) in [
            ("attempt", "1"),
            ("attempts_exhausted", "true"),
            ("backend_operation", "SendInput"),
            ("operation", "recording preview"),
            ("origin_macro_id", "1"),
            ("origin_step_id", "1"),
            ("step", "1"),
            ("step_id", "1"),
            ("ticket", "93"),
        ] {
            assert_eq!(failure.context.get(key).map(String::as_str), Some(value));
        }
        assert!(!active);
        let retained = retained.unwrap();
        assert_eq!(retained.run_id, failed.run_id);
        assert_eq!(retained.latest_failure, failed.latest_failure);
        let (wrong_active, wrong_snapshot) = runtime.recording_preview_status(92);
        assert!(!wrong_active);
        assert!(wrong_snapshot.is_none());
    }

    #[test]
    fn g08_history_registry_unlock_concurrent_publish_clear_and_generation_release() {
        let (_first_dir, first_runtime, _first_guard) = runtime_with(Vec::new());
        let first_runtime = Arc::new(first_runtime);
        let (_replacement_dir, replacement, _replacement_guard) = runtime_with(Vec::new());
        let replacement = Arc::new(replacement);
        let registry = Arc::new(RwLock::new(Some(first_runtime.clone())));
        let request = HistoryViewRequest {
            page: 0,
            detail_page: 0,
            filter: HistoryFilter::All,
            selected: None,
        };
        let generation = first_runtime.generation;
        let worker_registry = registry.clone();
        let worker_runtime = first_runtime.clone();
        let worker_replacement = replacement.clone();
        let (completed_tx, completed_rx) = mpsc::channel();

        let (result, worker_completed, worker) =
            with_registered_history_view(registry.as_ref(), request, |projection| {
                assert_eq!(projection.generation, generation);
                assert_eq!(projection.total_runs, 0);
                let worker = thread::spawn(move || {
                    {
                        let mut history = worker_runtime.shared.summary_history.lock().unwrap();
                        let accumulator = history
                            .begin(
                                1,
                                77,
                                Some("concurrent publication"),
                                InvocationSource::MacroDialog,
                                RuntimeOrigin::Stored,
                                RuntimeRunMode::Normal,
                                SummarySubset::Whole,
                                Arc::new(ManualRuntimeClock::default()),
                            )
                            .unwrap();
                        history.publish(
                            accumulator,
                            SummaryOutcome::Completed,
                            None,
                            Duration::ZERO,
                        );
                    }
                    let clear = worker_runtime.clear_completed_history();
                    *worker_registry.write().unwrap() = Some(worker_replacement.clone());
                    completed_tx.send(clear.is_ok()).unwrap();
                });
                let clear_was_deferred = completed_rx.recv_timeout(Duration::from_secs(3)).ok();
                assert!(first_runtime.history_view_bytes() > 0);
                (
                    (projection.revision, projection.total_runs),
                    clear_was_deferred,
                    worker,
                )
            })
            .unwrap();
        worker.join().expect("history worker joins");

        assert_eq!(result, (0, 0));
        assert_eq!(
            worker_completed,
            Some(true),
            "canonical clear completes while the frame copy remains leased"
        );
        assert_eq!(first_runtime.history_view_bytes(), 0);
        assert!(first_runtime.clear_completed_history().is_ok());
        assert!(first_runtime.with_run_summaries(|_, rows| rows.is_empty()));
        assert_eq!(
            registry.read().unwrap().as_ref().unwrap().generation,
            replacement.generation
        );
        let unwind = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let _ = first_runtime.with_history_view(request, |_| -> () {
                panic!("exercise history-view lease unwinding");
            });
        }));
        assert!(unwind.is_err());
        assert_eq!(first_runtime.history_view_bytes(), 0);
    }

    #[test]
    fn g08_history_paused_and_busy_admission_absent_until_terminal() {
        let target = test_macro(
            1,
            true,
            vec![step(
                1,
                MkAction::Delay(MkDelayPayload {
                    fixed_ms: 60_000,
                    ..Default::default()
                }),
            )],
        );
        let (_directory, runtime, _guard) = runtime_with(vec![target]);
        let runtime = Arc::new(runtime);
        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        wait_for_state(&runtime, RuntimeState::Running);
        assert_eq!(
            runtime.command(RuntimeCommand::Pause),
            CommandResult::Accepted
        );
        wait_for_state(&runtime, RuntimeState::Paused);
        assert!(matches!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::AlreadyRunning { active_macro_id: 1 }
        ));

        let request = HistoryViewRequest {
            page: 0,
            detail_page: 0,
            filter: HistoryFilter::All,
            selected: None,
        };
        let during_run = runtime
            .with_history_view(request, |projection| {
                assert!(
                    runtime
                        .shared
                        .summary_history
                        .try_lock()
                        .unwrap()
                        .active_bytes()
                        > 0
                );
                (projection.total_runs, projection.header_count)
            })
            .unwrap();
        assert_eq!(
            during_run,
            (0, 0),
            "active and busy runs are not history rows"
        );

        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        let terminal = wait_for_terminal(&runtime);
        assert_eq!(terminal.state, RuntimeState::Stopped);
        wait_for_admission_release(&runtime);
        let after_terminal = runtime
            .with_history_view(request, |projection| {
                (
                    projection.total_runs,
                    projection.headers[0].unwrap().outcome,
                    projection.headers[0].unwrap().key,
                )
            })
            .unwrap();
        assert_eq!(after_terminal.0, 1);
        assert_eq!(after_terminal.1, SummaryOutcome::Stopped);
        assert_eq!(after_terminal.2.generation, runtime.generation);
        assert_eq!(after_terminal.2.run_id, terminal.run_id);
    }
}

#[cfg(test)]
mod facade_tests {
    use super::*;
    use crate::mkmacro::{
        MkAction, MkMacro, MkMacroDocument, MkStep, MkTextMode, MkTextPayload, SCHEMA_VERSION,
        executor::fake::FakeBackend,
    };
    use serial_test::serial;
    use std::time::{Duration, Instant};

    fn step(id: u64, text: &str) -> MkStep {
        MkStep {
            metadata: Default::default(),
            id,
            enabled: true,
            breakpoint: false,
            repeat: 1,
            delay_after_ms: 0,
            on_error: Default::default(),
            action: MkAction::Text(MkTextPayload {
                text: text.into(),
                mode: MkTextMode::Type,
            }),
        }
    }

    fn wait_for_terminal(runtime: &MacroRuntime) {
        let deadline = Instant::now() + Duration::from_secs(2);
        loop {
            let snapshot = runtime.snapshot();
            if snapshot.state == RuntimeState::Completed {
                return;
            }
            assert!(
                !matches!(snapshot.state, RuntimeState::Failed | RuntimeState::Stopped),
                "debug facade run failed: {snapshot:?}"
            );
            assert!(Instant::now() < deadline, "debug facade run did not finish");
            thread::sleep(Duration::from_millis(2));
        }
    }

    fn wait_for_admission_release(runtime: &MacroRuntime) {
        let deadline = Instant::now() + Duration::from_secs(2);
        while runtime.shared.admission.lock().unwrap().is_some() {
            assert!(
                Instant::now() < deadline,
                "runtime admission was not released"
            );
            thread::sleep(Duration::from_millis(1));
        }
    }

    #[test]
    #[serial]
    fn debug_facades_submit_the_matching_commands_without_rewriting_arguments() {
        let directory = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(directory.path()).unwrap();
        store
            .save(MkMacroDocument {
                schema_version: SCHEMA_VERSION,
                macros: vec![MkMacro {
                    signature: Default::default(),
                    id: 7301,
                    name: "debug facade target".into(),
                    description: String::new(),
                    enabled: true,
                    hotkey: None,
                    hotkey_scope: Default::default(),
                    folder_id: None,
                    playback: Default::default(),
                    steps: vec![step(10, "first"), step(20, "second"), step(30, "third")],
                }],
                ..Default::default()
            })
            .unwrap();
        let fake = Arc::new(FakeBackend::default());
        set_shared_store_with_backends(Arc::new(store), fake.backends());
        let runtime = RUNTIME.read().unwrap().as_ref().unwrap().clone();

        debug_run(7301).unwrap();
        assert_eq!(
            runtime.take_test_commands(),
            vec![RuntimeCommand::DebugRun(7301)]
        );
        wait_for_terminal(&runtime);
        assert_eq!(runtime.snapshot().macro_id, Some(7301));
        assert_eq!(runtime.snapshot().run_mode, RuntimeRunMode::Debug);
        wait_for_admission_release(&runtime);

        debug_run_from(7301, 20).unwrap();
        assert_eq!(
            runtime.take_test_commands(),
            vec![RuntimeCommand::DebugRunFrom(7301, 20)]
        );
        wait_for_terminal(&runtime);
        assert_eq!(runtime.snapshot().macro_id, Some(7301));
        assert_eq!(runtime.snapshot().run_mode, RuntimeRunMode::Debug);
        wait_for_admission_release(&runtime);

        let selection = vec![30, 10, 20];
        debug_run_selection(7301, selection.clone()).unwrap();
        assert_eq!(
            runtime.take_test_commands(),
            vec![RuntimeCommand::DebugRunSelection(7301, selection)]
        );
        wait_for_terminal(&runtime);
        assert_eq!(runtime.snapshot().macro_id, Some(7301));
        assert_eq!(runtime.snapshot().run_mode, RuntimeRunMode::Debug);
    }
}

#[cfg(test)]
mod recording_controller_tests {
    use super::*;
    use crate::mkmacro::{
        AuxiliaryObservationWorker, CallbackSender, HookCommand, HookCommandRequest, HookEvent,
        HookLoopAdapter, HookService, KeyTranslation, KeyboardTranslationRequest, MkMacro,
        MkMacroDocument, MkPlayback, ObservationBaseline, RawWindowObservation,
        RecorderObserverSession, SCHEMA_VERSION, WindowEventSource, executor::fake::FakeBackend,
    };

    struct FakeHookLoop;
    impl HookLoopAdapter for FakeHookLoop {
        fn run(self, commands: mpsc::Receiver<HookCommandRequest>, _callback: CallbackSender) {
            while let Ok(request) = commands.recv() {
                let shutdown = request.command == HookCommand::Shutdown;
                request.acknowledge(true);
                if shutdown {
                    break;
                }
            }
        }
    }
    struct SyntheticTranslator;
    impl KeyboardTranslator for SyntheticTranslator {
        fn initial_key_state(&mut self) -> [u8; 256] {
            [0; 256]
        }
        fn translate(&mut self, _: &KeyboardTranslationRequest) -> KeyTranslation {
            KeyTranslation::None
        }
    }
    struct SyntheticEnricher;
    impl EventEnricher for SyntheticEnricher {
        fn enrich(&mut self, _: &HookEvent) -> Option<crate::mkmacro::EventContext> {
            None
        }
    }

    struct BlockingObservationSource {
        gate: Arc<(Mutex<(bool, bool)>, Condvar)>,
    }
    impl WindowEventSource for BlockingObservationSource {
        fn drain(&mut self) -> Vec<RawWindowObservation> {
            Vec::new()
        }
        fn shutdown_and_drain(&mut self) -> Vec<RawWindowObservation> {
            let (lock, wake) = &*self.gate;
            let mut state = lock.lock().unwrap();
            state.0 = true;
            wake.notify_all();
            while !state.1 {
                state = wake.wait(state).unwrap();
            }
            Vec::new()
        }
    }

    #[test]
    #[serial_test::serial]
    fn toggle_requires_a_target_and_assigns_the_stopped_session_only_to_it() {
        let dir = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(dir.path()).unwrap();
        store
            .save(MkMacroDocument {
                schema_version: SCHEMA_VERSION,
                folders: vec![],
                settings: Default::default(),
                macros: [1, 2]
                    .into_iter()
                    .map(|id| MkMacro {
                        signature: Default::default(),
                        id,
                        name: format!("macro {id}"),
                        description: String::new(),
                        enabled: true,
                        hotkey: None,
                        hotkey_scope: Default::default(),
                        folder_id: None,
                        playback: MkPlayback::default(),
                        steps: vec![],
                    })
                    .collect(),
            })
            .unwrap();
        let store = Arc::new(store);
        let fake = Arc::new(FakeBackend::default());
        let observation_gate = Arc::new((Mutex::new((false, false)), Condvar::new()));
        let observer_factory = {
            let gate = observation_gate.clone();
            Arc::new(move || {
                RecorderObserverSession::with_sources(
                    ObservationBaseline::default(),
                    AuxiliaryObservationWorker::spawn(None, None),
                    Some(Box::new(BlockingObservationSource { gate: gate.clone() })),
                )
            })
        };
        set_shared_store_components(
            store.clone(),
            fake.backends(),
            &[],
            HookService::with_adapter(FakeHookLoop, 16),
            false,
            Some((
                Box::new(SyntheticTranslator),
                observer_factory,
                Box::new(SyntheticEnricher),
            )),
        );
        take_pending_recordings();

        arm_recording(None, NormalizationConfig::default());
        toggle_recording();
        assert_eq!(
            recorder_snapshot().unwrap().state,
            super::super::RecorderRuntimeState::Idle
        );
        assert_eq!(
            recording_status().as_deref(),
            Some("Select a macro before starting recording")
        );

        arm_recording(
            Some(RecordingTarget {
                macro_id: 2,
                insertion_anchor_step_id: None,
                insertion_anchor_generation: None,
            }),
            NormalizationConfig::default(),
        );
        assert_eq!(recording_status(), None);
        toggle_recording();
        assert_eq!(recorder_snapshot().unwrap().macro_id, Some(2));
        let unchanged = store.snapshot();
        assert!(request_record_stop_for_review().unwrap());
        {
            let (lock, wake) = &*observation_gate;
            let state = lock.lock().unwrap();
            let (mut state, timeout) = wake
                .wait_timeout_while(state, std::time::Duration::from_secs(2), |state| !state.0)
                .unwrap();
            assert!(
                !timeout.timed_out(),
                "recording finalization did not reach its barrier"
            );
            assert!(record_stop_pending());
            assert_eq!(
                recorder_snapshot().unwrap().state,
                super::super::RecorderRuntimeState::Stopping
            );
            assert!(!request_record_stop_for_review().unwrap());
            assert!(
                run(1)
                    .unwrap_err()
                    .to_string()
                    .contains("recording is active")
            );
            assert_eq!(*unchanged, *store.snapshot());
            state.1 = true;
            wake.notify_all();
        }
        let (pending_lock, pending_wake) = &*RECORD_STOP_COORDINATOR;
        let pending = pending_lock
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let (pending, timeout) = pending_wake
            .wait_timeout_while(pending, std::time::Duration::from_secs(2), |pending| {
                *pending
            })
            .unwrap_or_else(|error| error.into_inner());
        assert!(!timeout.timed_out(), "recording stop did not complete");
        assert!(!*pending);
        drop(pending);
        assert_eq!(
            recorder_snapshot().unwrap().state,
            super::super::RecorderRuntimeState::Idle
        );
        let results = take_pending_recordings();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].target.macro_id, 2);
        assert!(results[0].plan.steps.is_empty());
        assert_eq!(*unchanged, *store.snapshot());
        assert!(request_record_stop_for_review().is_err());
        assert!(take_pending_recordings().is_empty());
    }
}

#[cfg(test)]
mod step_outcome_tests {
    use super::*;

    #[test]
    fn image_match_and_continued_miss_are_distinct_success_details() {
        let matched = StepOutcome {
            last_image_found: Some(true),
            ..StepOutcome::default()
        };
        let missed = StepOutcome {
            last_image_found: Some(false),
            ..StepOutcome::default()
        };
        assert_ne!(matched.detail(), missed.detail());
        assert_eq!(matched.last_image_found, Some(true));
        assert_eq!(missed.last_image_found, Some(false));
        assert_eq!(
            missed.detail(),
            Some("Success — image not found; continued.")
        );
        // Outcome metadata augments, rather than changes, the successful state.
        assert_eq!(StepState::Success, StepState::Success);
    }

    #[test]
    fn unrelated_step_has_no_inherited_image_status() {
        let unrelated = StepOutcome::default();
        assert_eq!(unrelated.last_image_found, None);
        assert_eq!(unrelated.last_ocr_found, None);
        assert_eq!(unrelated.detail(), None);
    }

    #[test]
    fn ocr_match_and_continued_miss_are_distinct_success_details() {
        let matched = StepOutcome {
            last_ocr_found: Some(true),
            ..StepOutcome::default()
        };
        let missed = StepOutcome {
            last_ocr_found: Some(false),
            ..StepOutcome::default()
        };
        assert_eq!(matched.detail(), Some("Success — OCR text found."));
        assert_eq!(
            missed.detail(),
            Some("Success — OCR text not found; continued.")
        );
    }
}

#[cfg(test)]
mod runtime_snapshot_tests {
    use super::*;
    use crate::mkmacro::{
        MkAction, MkCoordinateTarget, MkDelayPayload, MkImageNotFoundPolicy, MkImageOutputs,
        MkImagePayload, MkImageRef, MkLauncherCommandPayload, MkMacro, MkMacroDocument,
        MkMouseMovePayload, MkOcrFindPayload, MkOcrSearchSpec, MkPoint, MkStep, MkTextMode,
        MkTextPayload, MkValue, MkWaitOptions, OcrDocument, OcrLine, OcrWord, ScreenCaptureBackend,
        ScreenRect, SearchRegion,
        executor::{ClipboardBackend, LauncherBackend, fake::FakeBackend},
    };
    use std::io::{self, Write};
    use std::sync::{Arc, Mutex};
    use std::time::{Duration, Instant};

    struct SentinelTextClipboard(&'static str);

    #[derive(Debug, Clone, PartialEq, Eq)]
    enum MemoryClipboardOperation {
        ReadText,
        WriteText(String),
    }

    #[derive(Debug)]
    struct MemoryClipboardState {
        text: String,
        operations: Vec<MemoryClipboardOperation>,
    }

    struct MemoryTextClipboard(Mutex<MemoryClipboardState>);

    impl MemoryTextClipboard {
        fn new(text: &str) -> Self {
            Self(Mutex::new(MemoryClipboardState {
                text: text.to_owned(),
                operations: Vec::new(),
            }))
        }
    }

    impl ClipboardBackend for SentinelTextClipboard {
        fn snapshot_text(&self) -> ExecResult<String> {
            Ok(self.0.to_owned())
        }

        fn set_text(&self, _text: &str) -> ExecResult {
            Ok(())
        }
    }

    impl ClipboardBackend for MemoryTextClipboard {
        fn snapshot_text(&self) -> ExecResult<String> {
            let mut state = self.0.lock().unwrap();
            state.operations.push(MemoryClipboardOperation::ReadText);
            Ok(state.text.clone())
        }

        fn set_text(&self, text: &str) -> ExecResult {
            let mut state = self.0.lock().unwrap();
            state.text = text.to_owned();
            state
                .operations
                .push(MemoryClipboardOperation::WriteText(text.to_owned()));
            Ok(())
        }
    }

    struct LeakingQueryFailure;

    impl LauncherBackend for LeakingQueryFailure {
        fn launch_process(&self, _payload: &crate::mkmacro::MkProcessPayload) -> ExecResult {
            Ok(())
        }

        fn command(&self, query: &str, control: &RunControl) -> ExecResult {
            control.checkpoint()?;
            Err(ExecutionDiagnostic::new(
                DiagnosticKind::Backend,
                format!("launcher rejected query: {query}"),
            )
            .context("backend", "launcher")
            .context("query", query))
        }

        fn resolved_legacy(
            &self,
            _action: &crate::actions::Action,
            _control: &RunControl,
        ) -> ExecResult {
            Ok(())
        }
    }

    #[derive(Clone)]
    struct SharedTraceWriter(Arc<Mutex<Vec<u8>>>);

    impl Write for SharedTraceWriter {
        fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
            self.0.lock().unwrap().extend_from_slice(bytes);
            Ok(bytes.len())
        }

        fn flush(&mut self) -> io::Result<()> {
            Ok(())
        }
    }

    fn step(id: u64, action: MkAction) -> MkStep {
        MkStep {
            metadata: Default::default(),
            id,
            enabled: true,
            breakpoint: false,
            repeat: 1,
            delay_after_ms: 0,
            on_error: Default::default(),
            action,
        }
    }

    fn test_macro(steps: Vec<MkStep>) -> MkMacro {
        MkMacro {
            signature: Default::default(),
            id: 1,
            name: "runtime snapshot test".into(),
            description: String::new(),
            enabled: true,
            hotkey: None,
            hotkey_scope: Default::default(),
            folder_id: None,
            playback: Default::default(),
            steps,
        }
    }

    fn image_payload(policy: MkImageNotFoundPolicy) -> MkImagePayload {
        MkImagePayload {
            image: MkImageRef::from_filename("10.png"),
            wait: MkWaitOptions {
                timeout_ms: 0,
                poll_interval_ms: 1,
            },
            region: Default::default(),
            tolerance: 0,
            alpha: Default::default(),
            return_point: Default::default(),
            not_found_policy: policy,
            outputs: MkImageOutputs {
                point: Some("target_point".into()),
                ..Default::default()
            },
        }
    }

    fn variable_move() -> MkAction {
        MkAction::MouseMove(MkMouseMovePayload {
            target: MkCoordinateTarget::Variable {
                name: "target_point".into(),
            },
            duration_ms: 0,
        })
    }

    fn document_for(target: MkMacro) -> MkMacroDocument {
        MkMacroDocument {
            macros: vec![target],
            ..Default::default()
        }
    }

    fn runtime_with(target: MkMacro) -> (tempfile::TempDir, MacroRuntime, Arc<FakeBackend>) {
        let directory = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(directory.path()).unwrap();
        store
            .save(MkMacroDocument {
                macros: vec![target],
                ..Default::default()
            })
            .unwrap();
        let fake = Arc::new(FakeBackend::default());
        let runtime = MacroRuntime::new(Arc::new(store), fake.clone().backends());
        (directory, runtime, fake)
    }

    struct OcrCapture;

    impl ScreenCaptureBackend for OcrCapture {
        fn virtual_desktop(&self) -> crate::mkmacro::ExecResult<ScreenRect> {
            Ok(ScreenRect::new(0, 0, 200, 100))
        }

        fn region_bounds(&self, _: &SearchRegion) -> crate::mkmacro::ExecResult<ScreenRect> {
            Ok(ScreenRect::new(10, 20, 100, 40))
        }

        fn capture_rect(
            &self,
            rect: ScreenRect,
            _: &dyn Fn() -> bool,
        ) -> crate::mkmacro::ExecResult<image::RgbaImage> {
            Ok(image::RgbaImage::new(rect.width, rect.height))
        }
    }

    fn ocr_document(text: &str) -> OcrDocument {
        OcrDocument {
            image_width: 100,
            image_height: 40,
            lines: vec![OcrLine {
                text: text.into(),
                words: vec![OcrWord {
                    text: text.into(),
                    bounds: ScreenRect::new(2, 3, 30, 10),
                }],
            }],
            ..OcrDocument::default()
        }
    }

    fn runtime_with_ocr(
        target: MkMacro,
        recognized: &str,
    ) -> (tempfile::TempDir, MacroRuntime, Arc<FakeBackend>) {
        let directory = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(directory.path()).unwrap();
        store.save(document_for(target)).unwrap();
        let fake = Arc::new(FakeBackend::default());
        fake.script_ocr(Ok(ocr_document(recognized)));
        let mut backends = fake.clone().backends();
        backends.screenshot_capture = Arc::new(OcrCapture);
        let runtime = MacroRuntime::new(Arc::new(store), backends);
        (directory, runtime, fake)
    }

    #[test]
    fn runtime_observes_ocr_match_and_continued_miss_step_outcomes() {
        for (recognized, expected_found) in [("target", true), ("other", false)] {
            let action = MkAction::OcrFindText(MkOcrFindPayload {
                search: MkOcrSearchSpec {
                    text: "target".into(),
                    ..Default::default()
                },
                wait: MkWaitOptions {
                    timeout_ms: 100,
                    poll_interval_ms: 100,
                },
                not_found_policy: MkImageNotFoundPolicy::Continue,
                ..Default::default()
            });
            let (_directory, runtime, _fake) =
                runtime_with_ocr(test_macro(vec![step(1, action)]), recognized);
            assert_eq!(
                runtime.command(RuntimeCommand::Run(1)),
                CommandResult::Accepted
            );
            let completed = wait_for_terminal(&runtime);
            assert_eq!(completed.state, RuntimeState::Completed, "{completed:?}");
            let expected = StepOutcome {
                last_ocr_found: Some(expected_found),
                ..StepOutcome::default()
            };
            assert_eq!(completed.step_outcomes.get(&1), Some(&expected));
            assert_eq!(
                completed.last_completed.as_ref().map(|step| &step.outcome),
                Some(&CompletedStepOutcome::Success(Some(expected.clone())))
            );
            assert!(runtime.take_test_events().iter().any(|event| {
                matches!(event, ExecutionEvent::StepOutcome(1, outcome) if outcome == &expected)
            }));
        }
    }

    fn wait_for_terminal(runtime: &MacroRuntime) -> Arc<RuntimeSnapshot> {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let snapshot = runtime.snapshot();
            if matches!(
                snapshot.state,
                RuntimeState::Completed | RuntimeState::Failed | RuntimeState::Stopped
            ) {
                return snapshot;
            }
            assert!(
                Instant::now() < deadline,
                "runtime did not finish: {snapshot:?}"
            );
            std::thread::sleep(Duration::from_millis(2));
        }
    }

    fn wait_for_terminal_after(
        runtime: &MacroRuntime,
        previous_run_id: u64,
    ) -> Arc<RuntimeSnapshot> {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let snapshot = runtime.snapshot();
            if snapshot.run_id > previous_run_id
                && matches!(
                    snapshot.state,
                    RuntimeState::Completed | RuntimeState::Failed | RuntimeState::Stopped
                )
            {
                return snapshot;
            }
            assert!(
                Instant::now() < deadline,
                "runtime did not finish after run {previous_run_id}: {snapshot:?}"
            );
            std::thread::sleep(Duration::from_millis(2));
        }
    }

    fn wait_for_state(runtime: &MacroRuntime, state: RuntimeState) -> Arc<RuntimeSnapshot> {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let snapshot = runtime.snapshot();
            if snapshot.state == state {
                return snapshot;
            }
            assert!(
                Instant::now() < deadline,
                "runtime did not reach {state:?}: {snapshot:?}"
            );
            std::thread::sleep(Duration::from_millis(2));
        }
    }

    fn wait_for_debug_boundary(
        runtime: &MacroRuntime,
        step_id: Option<u64>,
        reason: DebugSnapshotReason,
    ) -> Arc<RuntimeSnapshot> {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let snapshot = runtime.snapshot();
            if snapshot
                .debug_snapshot
                .as_ref()
                .is_some_and(|debug| debug.step_id == step_id && debug.reason == reason)
            {
                return snapshot;
            }
            assert!(
                Instant::now() < deadline,
                "runtime did not publish debug boundary {step_id:?}/{reason:?}: {snapshot:?}"
            );
            std::thread::sleep(Duration::from_millis(2));
        }
    }

    fn assert_debug_fields(
        snapshot: &RuntimeSnapshot,
        step_id: Option<u64>,
        reason: DebugSnapshotReason,
    ) {
        assert_eq!(snapshot.debug_variables_step_id, step_id);
        assert_eq!(snapshot.debug_snapshot_reason, Some(reason));
        let debug = snapshot
            .debug_snapshot
            .as_ref()
            .expect("debug event also publishes the compatibility snapshot");
        assert_eq!(debug.step_id, step_id);
        assert_eq!(debug.reason, reason);
        assert_eq!(&*snapshot.debug_variables, &*debug.variables);
    }

    #[test]
    fn clipboard_action_integration_saved_reopened_workflow_is_exact_and_stops_on_wrong_type() {
        use crate::mkmacro::{MkErrorPolicy, MkValueSource, MkWriteClipboardTextPayload};

        let initial_text = "source 雪\nraw ${literal}";
        let replacement_text = "replacement café\nraw ${still_literal}";
        let write_variable = |name: &str| {
            MkAction::WriteClipboardText(MkWriteClipboardTextPayload {
                source: MkValueSource::Variable { name: name.into() },
            })
        };
        let workflow = test_macro(vec![
            step(
                101,
                MkAction::ReadClipboardText {
                    variable: "clipboard_text".into(),
                },
            ),
            step(102, write_variable("clipboard_text")),
            step(
                103,
                MkAction::SetVariable {
                    name: "clipboard_text".into(),
                    value: MkValue::String(replacement_text.into()),
                },
            ),
            step(104, write_variable("clipboard_text")),
        ]);
        let expected_steps = workflow.steps.clone();

        // Keep the wrong-type source uncertain to authoring analysis: the
        // selected runtime branch writes a Number, while the other branch
        // writes a String. Runtime still validates the actual value.
        let mut wrong_type = test_macro(vec![
            step(
                201,
                MkAction::If(crate::mkmacro::MkCondition::WindowExists {
                    matcher: crate::mkmacro::MkWindowMatcher {
                        title: Some("M8-C wrong-type branch".into()),
                        ..Default::default()
                    },
                }),
            ),
            step(
                202,
                MkAction::SetVariable {
                    name: "runtime_value".into(),
                    value: MkValue::String("alternate branch".into()),
                },
            ),
            step(203, MkAction::Else),
            step(
                204,
                MkAction::SetVariable {
                    name: "runtime_value".into(),
                    value: MkValue::Number(42.0),
                },
            ),
            step(205, MkAction::EndIf),
            {
                let mut write = step(206, write_variable("runtime_value"));
                write.on_error = MkErrorPolicy::Stop;
                write
            },
            step(
                207,
                MkAction::WriteClipboardText(MkWriteClipboardTextPayload {
                    source: MkValueSource::Literal(MkValue::String("must not be written".into())),
                }),
            ),
        ]);
        wrong_type.id = 2;

        let directory = tempfile::tempdir().unwrap();
        {
            let (store, _) = MkMacroStore::open(directory.path()).unwrap();
            store
                .save(MkMacroDocument {
                    macros: vec![workflow, wrong_type],
                    ..Default::default()
                })
                .unwrap();
        }

        // Reopen the persisted document before constructing the runtime so
        // this exercises the stored representation, not an in-memory plan.
        let (store, _) = MkMacroStore::open(directory.path()).unwrap();
        let reopened = store.snapshot();
        let reopened_workflow = reopened.macros.iter().find(|item| item.id == 1).unwrap();
        assert_eq!(reopened_workflow.steps, expected_steps);
        assert!(matches!(
            &reopened_workflow.steps[1].action,
            MkAction::WriteClipboardText(MkWriteClipboardTextPayload {
                source: MkValueSource::Variable { name }
            }) if name == "clipboard_text"
        ));
        assert_eq!(
            reopened_workflow
                .steps
                .iter()
                .map(|item| item.id)
                .collect::<Vec<_>>(),
            [101, 102, 103, 104]
        );

        let clipboard = Arc::new(MemoryTextClipboard::new(initial_text));
        let mut backends = Arc::new(FakeBackend::default()).backends();
        backends.clipboard = clipboard.clone();
        let runtime = MacroRuntime::new(Arc::new(store), backends);

        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        let completed = wait_for_terminal(&runtime);
        assert_eq!(completed.state, RuntimeState::Completed);
        assert_eq!(completed.macro_id, Some(1));
        let expected_operations = vec![
            MemoryClipboardOperation::ReadText,
            MemoryClipboardOperation::WriteText(initial_text.into()),
            MemoryClipboardOperation::WriteText(replacement_text.into()),
        ];
        {
            let state = clipboard.0.lock().unwrap();
            assert_eq!(state.operations, expected_operations);
            assert_eq!(state.text, replacement_text);
        }

        let successful_run_id = completed.run_id;
        assert_eq!(
            runtime.command(RuntimeCommand::Run(2)),
            CommandResult::Accepted
        );
        let failed = wait_for_terminal_after(&runtime, successful_run_id);
        assert_eq!(failed.state, RuntimeState::Failed);
        let failure = failed.latest_failure.as_ref().unwrap();
        assert_eq!(failure.kind, DiagnosticKind::TypeMismatch);
        assert_eq!(
            failure.context.get("origin_step_id").map(String::as_str),
            Some("206")
        );
        let state = clipboard.0.lock().unwrap();
        assert_eq!(state.operations, expected_operations);
        assert_eq!(state.text, replacement_text);
    }

    #[test]
    fn clipboard_action_runtime_debug_snapshot_redacts_only_affected_runs() {
        use crate::mkmacro::MkCallMacroPayload;

        let sentinel = "runtime_clipboard_private_sentinel";
        let root = test_macro(vec![
            step(
                1,
                MkAction::SetVariable {
                    name: "caller_private".into(),
                    value: MkValue::String(sentinel.into()),
                },
            ),
            step(
                2,
                MkAction::CallMacro(MkCallMacroPayload {
                    macro_id: 2,
                    ..Default::default()
                }),
            ),
        ]);
        let mut child = test_macro(vec![
            step(
                1,
                MkAction::ReadClipboardText {
                    variable: "clipboard_text".into(),
                },
            ),
            step(
                2,
                MkAction::SetVariable {
                    name: "child_private".into(),
                    value: MkValue::String(sentinel.into()),
                },
            ),
            {
                let mut breakpoint = step(
                    3,
                    MkAction::SetVariable {
                        name: "child_done".into(),
                        value: MkValue::String("yes".into()),
                    },
                );
                breakpoint.breakpoint = true;
                breakpoint
            },
        ]);
        child.id = 2;
        let mut disabled_clipboard = step(
            1,
            MkAction::ReadClipboardText {
                variable: "disabled_clipboard_text".into(),
            },
        );
        disabled_clipboard.enabled = false;
        let mut ordinary = test_macro(vec![
            disabled_clipboard,
            step(
                2,
                MkAction::SetVariable {
                    name: "ordinary_private".into(),
                    value: MkValue::String(sentinel.into()),
                },
            ),
            {
                let mut breakpoint = step(
                    3,
                    MkAction::SetVariable {
                        name: "ordinary_done".into(),
                        value: MkValue::String("yes".into()),
                    },
                );
                breakpoint.breakpoint = true;
                breakpoint
            },
        ]);
        ordinary.id = 3;
        let mut subset_root = test_macro(vec![
            step(
                1,
                MkAction::CallMacro(crate::mkmacro::MkCallMacroPayload {
                    macro_id: 2,
                    ..Default::default()
                }),
            ),
            step(
                2,
                MkAction::SetVariable {
                    name: "subset_private".into(),
                    value: MkValue::String(sentinel.into()),
                },
            ),
            {
                let mut breakpoint = step(
                    3,
                    MkAction::SetVariable {
                        name: "subset_done".into(),
                        value: MkValue::String("yes".into()),
                    },
                );
                breakpoint.breakpoint = true;
                breakpoint
            },
        ]);
        subset_root.id = 4;

        let directory = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(directory.path()).unwrap();
        store
            .save(MkMacroDocument {
                macros: vec![root, child, ordinary, subset_root],
                ..Default::default()
            })
            .unwrap();
        let fake = Arc::new(FakeBackend::default());
        let runtime = MacroRuntime::new(Arc::new(store), fake.clone().backends());

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let paused = wait_for_state(&runtime, RuntimeState::Paused);
        assert_eq!(paused.active_macro_id(), Some(2));
        assert!(paused.debug_values_redacted);
        assert!(paused.debug_variables.is_empty());
        assert!(paused.debug_snapshot.as_ref().unwrap().variables.is_empty());
        assert!(!format!("{paused:?}").contains(sentinel));
        let clipboard_events = runtime.take_test_events();
        assert!(clipboard_events.iter().all(|event| match event {
            ExecutionEvent::DebugVariables { variables, .. }
            | ExecutionEvent::BreakpointHit { variables, .. } => variables.is_empty(),
            ExecutionEvent::FrameExited {
                caller_boundary: Some(boundary),
            } => boundary.variables.is_empty(),
            _ => true,
        }));
        assert!(!format!("{clipboard_events:?}").contains(sentinel));
        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        let completed = wait_for_terminal(&runtime);
        assert!(completed.debug_values_redacted);
        assert!(completed.debug_variables.is_empty());
        assert!(
            completed
                .debug_snapshot
                .as_ref()
                .is_none_or(|debug| debug.variables.is_empty())
        );
        assert!(!format!("{completed:?}").contains(sentinel));
        assert!(!format!("{:?}", runtime.take_test_events()).contains(sentinel));

        // A run-from subset can omit a clipboard callee even though the
        // compiled program retains that callee's full plan.
        assert_eq!(
            runtime.command(RuntimeCommand::DebugRunFrom(4, 2)),
            CommandResult::Accepted
        );
        let subset_paused = wait_for_state(&runtime, RuntimeState::Paused);
        assert!(!subset_paused.debug_values_redacted);
        assert_eq!(
            subset_paused.debug_variables.get("subset_private"),
            Some(&MkValue::String(sentinel.into()))
        );
        let subset_events = runtime.take_test_events();
        assert!(format!("{subset_events:?}").contains(sentinel));
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        wait_for_terminal(&runtime);

        // The privacy policy is derived for each invocation, not stored on the
        // runtime or debugger. An ordinary macro can still publish its values.
        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(3)),
            CommandResult::Accepted
        );
        let ordinary_paused = wait_for_state(&runtime, RuntimeState::Paused);
        assert!(!ordinary_paused.debug_values_redacted);
        assert_eq!(
            ordinary_paused.debug_variables.get("ordinary_private"),
            Some(&MkValue::String(sentinel.into()))
        );
        assert_eq!(
            ordinary_paused
                .debug_snapshot
                .as_ref()
                .unwrap()
                .variables
                .get("ordinary_private"),
            Some(&MkValue::String(sentinel.into()))
        );
        let ordinary_events = runtime.take_test_events();
        assert!(ordinary_events.iter().any(|event| matches!(
            event,
            ExecutionEvent::BreakpointHit { variables, .. }
                if variables.get("ordinary_private") == Some(&MkValue::String(sentinel.into()))
        )));
        assert!(format!("{ordinary_events:?}").contains(sentinel));
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        wait_for_terminal(&runtime);
    }

    #[test]
    fn clipboard_action_runtime_failure_payload_is_redacted_before_publication() {
        let sentinel = "failure_clipboard_payload_sentinel";
        let clipboard_macro = test_macro(vec![
            step(
                1,
                MkAction::ReadClipboardText {
                    variable: "clipboard_text".into(),
                },
            ),
            step(
                2,
                MkAction::LauncherCommand(MkLauncherCommandPayload {
                    query: "${clipboard_text}".into(),
                    legacy_resolved_action: None,
                }),
            ),
        ]);
        let mut ordinary_macro = test_macro(vec![step(
            1,
            MkAction::LauncherCommand(MkLauncherCommandPayload {
                query: "ordinary_failure_detail_sentinel".into(),
                legacy_resolved_action: None,
            }),
        )]);
        ordinary_macro.id = 2;

        let traced_run = |executor: &Executor, plan: &crate::mkmacro::MkExecutionPlan| {
            let trace_bytes = Arc::new(Mutex::new(Vec::new()));
            let trace_writer = trace_bytes.clone();
            let subscriber = tracing_subscriber::fmt()
                .with_ansi(false)
                .without_time()
                .with_max_level(tracing::Level::WARN)
                .with_writer(move || SharedTraceWriter(trace_writer.clone()))
                .finish();
            let observed = Mutex::new(Vec::new());
            let result = tracing::subscriber::with_default(subscriber, || {
                executor.execute(plan, ExecutionOptions::normal(), &|event| {
                    observed.lock().unwrap().push(event);
                })
            });
            let events = observed.into_inner().unwrap();
            let trace = String::from_utf8(trace_bytes.lock().unwrap().clone()).unwrap();
            (result, events, trace)
        };

        let fake = Arc::new(FakeBackend::default());
        let mut backends = fake.clone().backends();
        backends.clipboard = Arc::new(SentinelTextClipboard(sentinel));
        backends.launcher = Arc::new(LeakingQueryFailure);
        let control = Arc::new(RunControl::default());
        control.reset();
        let executor = Executor::new(backends.clone(), control.clone());

        let clipboard_plan = crate::mkmacro::compile(&clipboard_macro).unwrap();
        let (clipboard_result, clipboard_events, clipboard_log) =
            traced_run(&executor, &clipboard_plan);
        let clipboard_error = clipboard_result.as_ref().unwrap_err();
        assert_eq!(clipboard_error.kind, DiagnosticKind::Backend);
        assert_eq!(
            clipboard_error.message,
            "Macro step backend operation failed"
        );
        assert_eq!(
            clipboard_error
                .context
                .get("origin_macro_id")
                .map(String::as_str),
            Some("1")
        );
        assert_eq!(
            clipboard_error
                .context
                .get("origin_step_id")
                .map(String::as_str),
            Some("2")
        );
        assert!(!clipboard_error.context.contains_key("query"));
        assert!(
            !format!("{clipboard_result:?}{clipboard_events:?}{clipboard_log}").contains(sentinel)
        );
        assert!(clipboard_log.contains("Macro step backend operation failed"));
        let failed_event = clipboard_events.iter().find_map(|event| match event {
            ExecutionEvent::StepFailed(2, diagnostic) => Some(diagnostic),
            _ => None,
        });
        assert_eq!(failed_event, Some(clipboard_error));

        // A direct ordinary failure remains fully diagnostic, including the
        // query detail that is suppressed only for clipboard-enabled plans.
        control.reset();
        let ordinary_plan = crate::mkmacro::compile(&ordinary_macro).unwrap();
        let (ordinary_result, ordinary_events, ordinary_log) =
            traced_run(&executor, &ordinary_plan);
        let ordinary_error = ordinary_result.as_ref().unwrap_err();
        assert!(
            ordinary_error
                .message
                .contains("ordinary_failure_detail_sentinel")
        );
        assert_eq!(
            ordinary_error.context.get("query").map(String::as_str),
            Some("ordinary_failure_detail_sentinel")
        );
        assert!(
            format!("{ordinary_result:?}{ordinary_events:?}{ordinary_log}")
                .contains("ordinary_failure_detail_sentinel")
        );

        let directory = tempfile::tempdir().unwrap();
        let (store, _) = MkMacroStore::open(directory.path()).unwrap();
        store
            .save(MkMacroDocument {
                macros: vec![clipboard_macro, ordinary_macro],
                ..Default::default()
            })
            .unwrap();
        let mut runtime_backends = fake.clone().backends();
        runtime_backends.clipboard = Arc::new(SentinelTextClipboard(sentinel));
        runtime_backends.launcher = Arc::new(LeakingQueryFailure);
        let runtime = MacroRuntime::new(Arc::new(store), runtime_backends);

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let clipboard_terminal = wait_for_terminal(&runtime);
        assert_eq!(clipboard_terminal.state, RuntimeState::Failed);
        assert!(clipboard_terminal.debug_values_redacted);
        let terminal_error = clipboard_terminal.latest_failure.as_ref().unwrap();
        assert_eq!(
            terminal_error.message,
            "Macro step backend operation failed"
        );
        assert!(!terminal_error.context.contains_key("query"));
        assert!(!format!("{clipboard_terminal:?}").contains(sentinel));
        let clipboard_runtime_events = runtime.take_test_events();
        assert!(!format!("{clipboard_runtime_events:?}").contains(sentinel));
        let document = runtime.store.snapshot();
        let inspector =
            crate::gui::mkmacro_dialog::runtime_inspector::RuntimeInspectorViewModel::from_snapshot(
                &clipboard_terminal,
                &document,
            );
        assert!(inspector.value_redaction_notice.is_some());
        assert!(inspector.outcome.is_some() || inspector.run_failure.is_some());
        assert!(!format!("{inspector:?}").contains(sentinel));

        // A subsequent ordinary run on the same runtime retains its useful
        // failure details, proving the privacy policy is not sticky.
        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(2)),
            CommandResult::Accepted
        );
        let ordinary_terminal = wait_for_terminal_after(&runtime, clipboard_terminal.run_id);
        assert_eq!(ordinary_terminal.state, RuntimeState::Failed);
        assert!(!ordinary_terminal.debug_values_redacted);
        let ordinary_failure = ordinary_terminal.latest_failure.as_ref().unwrap();
        assert!(
            ordinary_failure
                .message
                .contains("ordinary_failure_detail_sentinel")
        );
        assert_eq!(
            ordinary_failure.context.get("query").map(String::as_str),
            Some("ordinary_failure_detail_sentinel")
        );
        let ordinary_runtime_events = runtime.take_test_events();
        assert!(
            format!("{ordinary_terminal:?}{ordinary_runtime_events:?}")
                .contains("ordinary_failure_detail_sentinel")
        );
    }

    #[test]
    fn debug_run_from_starts_at_set_b_and_resumes_into_mouse_move() {
        let target = test_macro(vec![
            step(
                1,
                MkAction::SetVariable {
                    name: "A".into(),
                    value: MkValue::String("Set A".into()),
                },
            ),
            {
                let mut breakpoint = step(
                    2,
                    MkAction::SetVariable {
                        name: "B".into(),
                        value: MkValue::String("Set B".into()),
                    },
                );
                breakpoint.breakpoint = true;
                breakpoint
            },
            step(
                3,
                MkAction::MouseMove(MkMouseMovePayload {
                    target: MkCoordinateTarget::Screen {
                        point: MkPoint { x: 19, y: 27 },
                    },
                    duration_ms: 0,
                }),
            ),
        ]);
        let (_directory, runtime, fake) = runtime_with(target);

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRunFrom(1, 2)),
            CommandResult::Accepted
        );
        let paused = wait_for_debug_boundary(&runtime, Some(2), DebugSnapshotReason::Breakpoint);
        assert_eq!(paused.state, RuntimeState::Paused);
        assert_eq!(paused.step_id, Some(2));
        assert_eq!(
            paused.pause_reason,
            Some(RuntimePauseReason::Breakpoint {
                step_id: 2,
                frame: ExecutionFrameContext::root(1)
            })
        );
        assert!(!paused.steps.contains_key(&1));
        assert_eq!(paused.steps[&2], StepState::Pending);
        assert_eq!(paused.steps[&3], StepState::Pending);
        assert!(!paused.debug_variables.contains_key("A"));
        assert!(!paused.debug_variables.contains_key("B"));
        assert!(fake.events().is_empty());

        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        let completed = wait_for_terminal(&runtime);
        let events = runtime.take_test_events();
        assert_eq!(completed.state, RuntimeState::Completed);
        assert_eq!(completed.run_mode, RuntimeRunMode::Debug);
        assert_eq!(completed.steps[&2], StepState::Success);
        assert_eq!(completed.steps[&3], StepState::Success);
        assert_eq!(completed.total_steps, 2);
        assert_eq!(completed.completed_steps, 2);
        assert_eq!(
            completed.debug_variables.get("B"),
            Some(&MkValue::String("Set B".into()))
        );
        assert_eq!(fake.events(), ["move:19,27"]);
        assert_eq!(
            events
                .iter()
                .filter_map(|event| match event {
                    ExecutionEvent::StepStarted(id) | ExecutionEvent::StepFinished(id) => {
                        Some(*id)
                    }
                    _ => None,
                })
                .collect::<Vec<_>>(),
            [2, 2, 3, 3]
        );
    }

    #[test]
    fn debug_breakpoint_snapshot_exposes_image_point_before_mouse_move() {
        let point = MkPoint { x: 823, y: 441 };
        let mut mouse_move = step(2, variable_move());
        mouse_move.breakpoint = true;
        let target = test_macro(vec![
            step(
                1,
                MkAction::ImageFind(image_payload(MkImageNotFoundPolicy::Fail)),
            ),
            mouse_move,
        ]);
        let (_directory, runtime, fake) = runtime_with(target);
        fake.script_image(MkImageRef::from_filename("10.png"), Ok(Some(point)));

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let paused = wait_for_debug_boundary(&runtime, Some(2), DebugSnapshotReason::Breakpoint);
        assert_eq!(paused.state, RuntimeState::Paused);
        assert_eq!(
            paused.pause_reason,
            Some(RuntimePauseReason::Breakpoint {
                step_id: 2,
                frame: ExecutionFrameContext::root(1)
            })
        );
        assert_eq!(
            paused.debug_variables.get("target_point"),
            Some(&MkValue::Point(point))
        );
        assert_debug_fields(&paused, Some(2), DebugSnapshotReason::Breakpoint);
        assert_eq!(paused.steps[&2], StepState::Pending);
        assert!(
            !fake.events().iter().any(|event| event.starts_with("move:")),
            "Mouse Move must not execute before its breakpoint is resumed"
        );

        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        let completed = wait_for_terminal(&runtime);
        assert_eq!(completed.state, RuntimeState::Completed);
        assert_eq!(completed.steps[&2], StepState::Success);
        assert_eq!(
            fake.events()
                .iter()
                .filter(|event| event.as_str() == "move:823,441")
                .count(),
            1
        );
    }

    #[test]
    fn debug_breakpoint_snapshot_preserves_image_miss_as_null_for_inspection() {
        let mut mouse_move = step(2, variable_move());
        mouse_move.breakpoint = true;
        let target = test_macro(vec![
            step(
                1,
                MkAction::ImageFind(image_payload(MkImageNotFoundPolicy::Continue)),
            ),
            mouse_move,
        ]);
        let document = document_for(target.clone());
        let (_directory, runtime, fake) = runtime_with(target);
        fake.script_image(MkImageRef::from_filename("10.png"), Ok(None));

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let paused = wait_for_debug_boundary(&runtime, Some(2), DebugSnapshotReason::Breakpoint);
        assert_eq!(
            paused.debug_variables.get("target_point"),
            Some(&MkValue::Null)
        );
        assert_debug_fields(&paused, Some(2), DebugSnapshotReason::Breakpoint);
        assert_eq!(paused.steps[&2], StepState::Pending);
        assert!(
            !fake.events().iter().any(|event| event.starts_with("move:")),
            "Mouse Move must not execute before its breakpoint is resumed"
        );

        let view =
            crate::gui::mkmacro_dialog::runtime_inspector::RuntimeInspectorViewModel::from_snapshot(
                &paused, &document,
            );
        let row = view
            .variables
            .user
            .iter()
            .find(|entry| entry.name == "target_point")
            .expect("target_point is visible as a user variable");
        assert_eq!(row.name, "target_point");
        assert_eq!(row.value.type_name, "Null");
        assert_eq!(row.value.table_text, "null");

        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        let failed = wait_for_terminal(&runtime);
        assert_eq!(failed.state, RuntimeState::Failed);
        assert_eq!(failed.steps[&2], StepState::Failed);
        let diagnostic = failed
            .latest_failure
            .as_ref()
            .expect("Mouse Move publishes its type diagnostic");
        assert_eq!(diagnostic.kind, DiagnosticKind::TypeMismatch);
        assert_eq!(
            diagnostic.message,
            "Variable 'target_point' contains Null; coordinate target requires Point"
        );
        assert_eq!(
            diagnostic.context.get("expected").map(String::as_str),
            Some("Point")
        );
        assert!(
            !fake.events().iter().any(|event| event.starts_with("move:")),
            "a Null coordinate target must not move the pointer"
        );
    }

    #[test]
    fn default_snapshot_and_new_run_reset_all_debugger_fields() {
        let default = RuntimeSnapshot::default();
        assert_eq!(default.run_mode, RuntimeRunMode::Normal);
        assert_eq!(default.pause_reason, None);
        assert!(!default.debug_values_redacted);
        assert!(default.debug_variables.is_empty());
        assert_eq!(default.debug_variables_step_id, None);
        assert_eq!(default.debug_snapshot_reason, None);
        assert_eq!(default.last_completed_step_id, None);

        let mut breakpoint = step(
            1,
            MkAction::Delay(MkDelayPayload {
                fixed_ms: 60_000,
                ..Default::default()
            }),
        );
        breakpoint.breakpoint = true;
        let (_directory, runtime, _fake) = runtime_with(test_macro(vec![breakpoint]));

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        wait_for_state(&runtime, RuntimeState::Paused);
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        let stopped = wait_for_terminal(&runtime);
        assert_eq!(
            stopped.debug_snapshot_reason,
            Some(DebugSnapshotReason::RunCancelled)
        );
        assert!(!stopped.debug_variables.is_empty());

        assert_eq!(
            runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        let running = wait_for_state(&runtime, RuntimeState::Running);
        assert_eq!(running.run_mode, RuntimeRunMode::Normal);
        assert_eq!(running.pause_reason, None);
        assert!(running.debug_variables.is_empty());
        assert_eq!(running.debug_variables_step_id, None);
        assert_eq!(running.debug_snapshot_reason, None);
        assert_eq!(running.last_completed_step_id, None);
        assert!(running.debug_snapshot.is_none());
        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        assert_eq!(wait_for_terminal(&runtime).pause_reason, None);
    }

    #[test]
    fn debugger_fields_update_together_at_breakpoints_and_step_boundaries() {
        let mut breakpoint = step(
            2,
            MkAction::SetVariable {
                name: "after_breakpoint".into(),
                value: MkValue::Boolean(true),
            },
        );
        breakpoint.breakpoint = true;
        let mut hold = step(
            3,
            MkAction::Delay(MkDelayPayload {
                fixed_ms: 60_000,
                ..Default::default()
            }),
        );
        hold.breakpoint = false;
        let (_directory, runtime, _fake) = runtime_with(test_macro(vec![
            step(
                1,
                MkAction::SetVariable {
                    name: "before_breakpoint".into(),
                    value: MkValue::String("ready".into()),
                },
            ),
            breakpoint,
            hold,
        ]));

        assert_eq!(
            runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let paused = wait_for_state(&runtime, RuntimeState::Paused);
        assert_debug_fields(&paused, Some(2), DebugSnapshotReason::Breakpoint);
        assert_eq!(
            paused.pause_reason,
            Some(RuntimePauseReason::Breakpoint {
                step_id: 2,
                frame: ExecutionFrameContext::root(1)
            })
        );
        assert!(!paused.debug_variables.contains_key("after_breakpoint"));

        assert_eq!(
            runtime.command(RuntimeCommand::Resume),
            CommandResult::Accepted
        );
        let boundary_deadline = Instant::now() + Duration::from_secs(10);
        let boundary = loop {
            let snapshot = runtime.snapshot();
            if snapshot.debug_snapshot_reason == Some(DebugSnapshotReason::StepBoundary)
                && snapshot.debug_variables_step_id == Some(2)
            {
                break snapshot;
            }
            assert!(
                Instant::now() < boundary_deadline,
                "step boundary was not published: {snapshot:?}"
            );
            std::thread::sleep(Duration::from_millis(2));
        };
        assert_debug_fields(&boundary, Some(2), DebugSnapshotReason::StepBoundary);
        assert_eq!(
            boundary.debug_variables.get("after_breakpoint"),
            Some(&MkValue::Boolean(true))
        );
        assert_eq!(boundary.last_completed_step_id, Some(2));

        assert_eq!(
            runtime.command(RuntimeCommand::Stop),
            CommandResult::Accepted
        );
        assert_eq!(wait_for_terminal(&runtime).pause_reason, None);
    }
    #[test]
    fn completion_failure_and_skip_policy_preserve_runtime_correlation() {
        let (_directory, success_runtime, _fake) = runtime_with(test_macro(vec![step(
            10,
            MkAction::SetVariable {
                name: "completed".into(),
                value: MkValue::Boolean(true),
            },
        )]));
        assert_eq!(
            success_runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let success = wait_for_terminal(&success_runtime);
        assert_eq!(success.state, RuntimeState::Completed);
        assert_eq!(success.pause_reason, None);
        assert_eq!(success.last_completed_step_id, Some(10));
        assert_eq!(success.steps[&10], StepState::Success);
        assert_debug_fields(&success, Some(10), DebugSnapshotReason::RunFinished);

        let (_directory, failure_runtime, fake) = runtime_with(test_macro(vec![
            step(
                20,
                MkAction::SetVariable {
                    name: "safe".into(),
                    value: MkValue::String("before failure".into()),
                },
            ),
            step(
                21,
                MkAction::Text(MkTextPayload {
                    text: "failure".into(),
                    mode: MkTextMode::Type,
                }),
            ),
        ]));
        fake.fail(
            "text:failure",
            ExecutionDiagnostic::new(DiagnosticKind::Backend, "injected failure"),
        );
        assert_eq!(
            failure_runtime.command(RuntimeCommand::DebugRun(1)),
            CommandResult::Accepted
        );
        let failure = wait_for_terminal(&failure_runtime);
        assert_eq!(failure.state, RuntimeState::Failed);
        assert_eq!(failure.pause_reason, None);
        assert_eq!(failure.last_completed_step_id, Some(21));
        assert_eq!(failure.steps[&21], StepState::Failed);
        assert!(failure.failures.contains_key(&DiagnosticKey {
            run_id: failure.run_id,
            step_id: 21,
        }));
        assert_debug_fields(&failure, Some(20), DebugSnapshotReason::RunFailed);
        assert_eq!(
            failure.debug_variables.get("safe"),
            Some(&MkValue::String("before failure".into()))
        );

        let mut skipped = step(30, MkAction::Delay(Default::default()));
        skipped.enabled = false;
        let (_directory, skipped_runtime, _fake) = runtime_with(test_macro(vec![skipped]));
        assert_eq!(
            skipped_runtime.command(RuntimeCommand::Run(1)),
            CommandResult::Accepted
        );
        let skipped_snapshot = wait_for_terminal(&skipped_runtime);
        assert_eq!(skipped_snapshot.state, RuntimeState::Completed);
        assert_eq!(skipped_snapshot.steps[&30], StepState::Skipped);
        assert_eq!(skipped_snapshot.completed_steps, 0);
        // Skipped steps do not count as completed: they never produced an
        // execution outcome and therefore leave this correlation unset.
        assert_eq!(skipped_snapshot.last_completed_step_id, None);
    }
}
