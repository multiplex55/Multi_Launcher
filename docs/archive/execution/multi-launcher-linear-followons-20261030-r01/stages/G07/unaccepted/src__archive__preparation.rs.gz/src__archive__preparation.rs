//! Session-bound physical ZIP32 Stored-entry validation and native stage
//! reservation. This module intentionally does not copy payload bytes.

use std::io::{self, Read, Seek, SeekFrom};
use std::path::PathBuf;
use std::sync::atomic::{AtomicU64, Ordering};

use crate::file_operations::ScanCancellation;

use super::catalog::read_catalog;
use super::model::{
    ArchiveCatalog, ArchiveEntry, ArchiveEntryId, ArchiveFormat, ArchiveLimits, ArchiveRevision,
    CatalogError, EntryKind,
};
use super::plan::{
    ArchiveSelection, CapturedOutputPolicy, ExtractionPlan, PlanBuildError, SelectionTarget,
    build_extraction_plan,
};

const MAX_SOURCE_BYTES: u64 = 512 * 1024 * 1024;
const MAX_SELECTED_FILES: usize = 128;
const MAX_ENTRY_BYTES: u64 = 64 * 1024 * 1024;
const MAX_TOTAL_BYTES: u64 = 256 * 1024 * 1024;
const UTF8_NAME_FLAG: u16 = 1 << 11;
const CENTRAL_SIGNATURE: u32 = 0x0201_4b50;
const LOCAL_SIGNATURE: u32 = 0x0403_4b50;
const CENTRAL_FIXED_BYTES: usize = 46;
const LOCAL_FIXED_BYTES: usize = 30;
static NEXT_REVISION: AtomicU64 = AtomicU64::new(1);
static NEXT_STAGE: AtomicU64 = AtomicU64::new(1);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ExecutionRefusal {
    Zip64,
    OutputPolicy,
    TooManyFiles,
    DirectoryOutput,
    UnsupportedEntry,
    CentralRecordChanged,
    LocalRecordMismatch,
    UnsupportedExtraFields,
    UnsupportedCreator,
    UnsupportedVersion,
    UnsupportedEncoding,
    InvalidRange,
    OverlappingRanges,
}

#[derive(Debug)]
enum PreparationError {
    SourceTooLarge,
    Cancelled,
    Catalog(CatalogError),
    Plan(PlanBuildError),
    Refused(ExecutionRefusal),
    Io(io::Error),
    Reservation(ReservationFailure),
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ValidatedStoredEntry {
    id: ArchiveEntryId,
    output_path: String,
    record_start: u64,
    record_end: u64,
    payload_offset: u64,
    payload_length: u64,
    crc32: u32,
}

struct ArchiveSession<R> {
    source: R,
    catalog: ArchiveCatalog,
    limits: ArchiveLimits,
}

impl<R: Read + Seek> ArchiveSession<R> {
    fn from_reader(
        mut source: R,
        revision: ArchiveRevision,
        caller_limits: ArchiveLimits,
        cancellation: &ScanCancellation,
    ) -> Result<Self, PreparationError> {
        if cancellation.is_cancelled() {
            return Err(PreparationError::Cancelled);
        }
        let length = source.seek(SeekFrom::End(0)).map_err(PreparationError::Io)?;
        if length > MAX_SOURCE_BYTES {
            return Err(PreparationError::SourceTooLarge);
        }
        let limits = captured_limits(caller_limits);
        let catalog = read_catalog(&mut source, revision, limits, cancellation)
            .map_err(PreparationError::Catalog)?;
        if catalog.source().archive_len != length {
            return Err(PreparationError::Refused(ExecutionRefusal::CentralRecordChanged));
        }
        Ok(Self {
            source,
            catalog,
            limits,
        })
    }

    fn plan(
        &self,
        selection: &ArchiveSelection,
        cancellation: &ScanCancellation,
    ) -> Result<ExtractionPlan, PreparationError> {
        if cancellation.is_cancelled() {
            return Err(PreparationError::Cancelled);
        }
        build_extraction_plan(&self.catalog, selection, None, cancellation)
            .map_err(PreparationError::Plan)
    }

    fn validate_plan(
        &mut self,
        plan: &ExtractionPlan,
        cancellation: &ScanCancellation,
    ) -> Result<Vec<ValidatedStoredEntry>, PreparationError> {
        if cancellation.is_cancelled() {
            return Err(PreparationError::Cancelled);
        }
        if plan.source() != self.catalog.source()
            || !matches!(self.catalog.source().format, ArchiveFormat::Zip32)
        {
            return Err(PreparationError::Refused(ExecutionRefusal::Zip64));
        }
        let policy = plan.policy();
        if !policy.no_overwrite
            || policy.max_actual_entry_output_bytes > MAX_ENTRY_BYTES
            || policy.max_actual_total_output_bytes > MAX_TOTAL_BYTES
            || policy.max_expansion_ratio > 1
            || self.limits.max_selection_entries > MAX_SELECTED_FILES
        {
            return Err(PreparationError::Refused(ExecutionRefusal::OutputPolicy));
        }
        if plan.directories().next().is_some() {
            return Err(PreparationError::Refused(ExecutionRefusal::DirectoryOutput));
        }
        let files: Vec<_> = plan.files().collect();
        if files.is_empty() || files.len() > MAX_SELECTED_FILES {
            return Err(PreparationError::Refused(ExecutionRefusal::TooManyFiles));
        }

        let mut validated = Vec::new();
        validated
            .try_reserve_exact(files.len())
            .map_err(|_| PreparationError::Io(io::Error::other("allocation failed")))?;
        let mut record_ranges = Vec::new();
        record_ranges
            .try_reserve_exact(files.len())
            .map_err(|_| PreparationError::Io(io::Error::other("allocation failed")))?;
        let mut total = 0_u64;

        for output in files {
            if cancellation.is_cancelled() {
                return Err(PreparationError::Cancelled);
            }
            if output.path().components().count() != 1 {
                return Err(PreparationError::Refused(ExecutionRefusal::DirectoryOutput));
            }
            let Some(id) = output.source_entry() else {
                return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEntry));
            };
            let Some(entry) = self.catalog.entry(id).cloned() else {
                return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEntry));
            };
            if id.revision() != self.catalog.source().revision
                || entry.kind != EntryKind::File
                || output.kind() != EntryKind::File
                || output.declared_output_size() > MAX_ENTRY_BYTES
                || output.declared_output_size() > policy.max_actual_entry_output_bytes
                || output.compressed_size() != output.declared_output_size()
            {
                return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEntry));
            }
            total = total
                .checked_add(output.declared_output_size())
                .ok_or(PreparationError::Refused(ExecutionRefusal::TooManyFiles))?;
            if total > MAX_TOTAL_BYTES || total > policy.max_actual_total_output_bytes {
                return Err(PreparationError::Refused(ExecutionRefusal::TooManyFiles));
            }
            let mut current = self.validate_physical_entry(&entry, cancellation)?;
            let safe_name = entry.name.as_utf8().ok_or(PreparationError::Refused(
                ExecutionRefusal::UnsupportedEncoding,
            ))?;
            if output.path().as_str() != safe_name {
                return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEntry));
            }
            current.output_path = output.path().as_str().to_owned();
            record_ranges.push(current.record_start..current.record_end);
            validated.push(current);
        }

        record_ranges.sort_by_key(|range| (range.start, range.end));
        if record_ranges
            .windows(2)
            .any(|pair| pair[1].start < pair[0].end)
        {
            return Err(PreparationError::Refused(ExecutionRefusal::OverlappingRanges));
        }
        Ok(validated)
    }

    fn validate_physical_entry(
        &mut self,
        entry: &ArchiveEntry,
        cancellation: &ScanCancellation,
    ) -> Result<ValidatedStoredEntry, PreparationError> {
        if cancellation.is_cancelled() {
            return Err(PreparationError::Cancelled);
        }
        let source = self.catalog.source();
        let central_start = entry.central_header_offset;
        let central_fixed_end = central_start
            .checked_add(CENTRAL_FIXED_BYTES as u64)
            .ok_or(PreparationError::Refused(ExecutionRefusal::InvalidRange))?;
        if central_start < source.central_directory_offset
            || central_fixed_end > source.central_directory_end
        {
            return Err(PreparationError::Refused(ExecutionRefusal::InvalidRange));
        }
        let mut central = [0_u8; CENTRAL_FIXED_BYTES];
        read_exact_at(&mut self.source, central_start, &mut central)?;
        if le_u32(&central, 0) != CENTRAL_SIGNATURE {
            return Err(PreparationError::Refused(ExecutionRefusal::CentralRecordChanged));
        }
        let central_name_len = usize::from(le_u16(&central, 28));
        let central_extra_len = usize::from(le_u16(&central, 30));
        let central_comment_len = usize::from(le_u16(&central, 32));
        if central_name_len > self.limits.max_name_bytes
            || central_extra_len > self.limits.max_extra_bytes
            || central_comment_len > self.limits.max_comment_bytes
        {
            return Err(PreparationError::Refused(ExecutionRefusal::InvalidRange));
        }
        if central_extra_len != 0 {
            return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedExtraFields));
        }
        let central_end = central_fixed_end
            .checked_add(central_name_len as u64)
            .and_then(|end| end.checked_add(central_extra_len as u64))
            .and_then(|end| end.checked_add(central_comment_len as u64))
            .ok_or(PreparationError::Refused(ExecutionRefusal::InvalidRange))?;
        if central_end > source.central_directory_end {
            return Err(PreparationError::Refused(ExecutionRefusal::InvalidRange));
        }
        let mut central_name = vec![0_u8; central_name_len];
        read_exact_at(
            &mut self.source,
            central_fixed_end,
            &mut central_name,
        )?;
        if central_name.as_slice() != entry.name.raw_bytes()
            || (le_u16(&central, 6) != 10 && le_u16(&central, 6) != 20)
            || le_u16(&central, 4) != entry.version_made_by
            || le_u16(&central, 8) != entry.flags
            || le_u16(&central, 10) != entry.compression.method_code()
            || le_u32(&central, 16) != entry.crc32
            || u64::from(le_u32(&central, 20)) != entry.compressed_size
            || u64::from(le_u32(&central, 24)) != entry.uncompressed_size
            || u64::from(le_u32(&central, 42)) != entry.local_header_offset
            || le_u32(&central, 38) != entry.external_attributes
            || le_u16(&central, 34) != 0
            || le_u16(&central, 28) as usize != entry.name.raw_bytes().len()
            || le_u16(&central, 30) != 0
        {
            return Err(PreparationError::Refused(ExecutionRefusal::CentralRecordChanged));
        }
        let version_needed = le_u16(&central, 6);
        let flags = le_u16(&central, 8);
        let method = le_u16(&central, 10);
        let crc32 = le_u32(&central, 16);
        let compressed = u64::from(le_u32(&central, 20));
        let expanded = u64::from(le_u32(&central, 24));
        let host = (le_u16(&central, 4) >> 8) as u8;
        let external = le_u32(&central, 38);
        if compressed == u64::from(u32::MAX)
            || expanded == u64::from(u32::MAX)
            || le_u32(&central, 42) == u32::MAX
            || le_u16(&central, 34) == u16::MAX
        {
            return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEntry));
        }
        if !matches!(host, 0 | 10 | 3 | 19) {
            return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedCreator));
        }
        if matches!(host, 3 | 19) {
            let file_type = (external >> 16) & 0o170000;
            if !matches!(file_type, 0 | 0o100000) {
                return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEntry));
            }
        }
        if external & (0x10 | 0x400 | (0x10 << 16) | (0x400 << 16)) != 0 {
            return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEntry));
        }
        if !matches!(version_needed, 10 | 20) {
            return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedVersion));
        }
        if flags & !UTF8_NAME_FLAG != 0 || method != 0 || compressed != expanded {
            return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEntry));
        }
        if flags & UTF8_NAME_FLAG != 0 {
            if std::str::from_utf8(&central_name).is_err() {
                return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEncoding));
            }
        } else if !central_name.is_ascii() {
            return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEncoding));
        }
        if central_name.iter().any(|byte| *byte == 0) {
            return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEncoding));
        }

        let local_start = entry.local_header_offset;
        let local_fixed_end = local_start
            .checked_add(LOCAL_FIXED_BYTES as u64)
            .ok_or(PreparationError::Refused(ExecutionRefusal::InvalidRange))?;
        if local_fixed_end > source.central_directory_offset || local_start >= source.archive_len {
            return Err(PreparationError::Refused(ExecutionRefusal::InvalidRange));
        }
        let mut local = [0_u8; LOCAL_FIXED_BYTES];
        read_exact_at(&mut self.source, local_start, &mut local)?;
        if le_u32(&local, 0) != LOCAL_SIGNATURE {
            return Err(PreparationError::Refused(ExecutionRefusal::LocalRecordMismatch));
        }
        let local_name_len = usize::from(le_u16(&local, 26));
        let local_extra_len = usize::from(le_u16(&local, 28));
        if local_extra_len != 0 {
            return Err(PreparationError::Refused(ExecutionRefusal::UnsupportedExtraFields));
        }
        if local_name_len != central_name_len
            || le_u16(&local, 4) != version_needed
            || le_u16(&local, 6) != flags
            || le_u16(&local, 8) != method
            || le_u32(&local, 14) != crc32
            || u64::from(le_u32(&local, 18)) != compressed
            || u64::from(le_u32(&local, 22)) != expanded
        {
            return Err(PreparationError::Refused(ExecutionRefusal::LocalRecordMismatch));
        }
        let local_name_end = local_fixed_end
            .checked_add(local_name_len as u64)
            .ok_or(PreparationError::Refused(ExecutionRefusal::InvalidRange))?;
        let payload_end = local_name_end
            .checked_add(compressed)
            .ok_or(PreparationError::Refused(ExecutionRefusal::InvalidRange))?;
        if local_name_end > source.central_directory_offset
            || payload_end > source.central_directory_offset
            || payload_end > source.archive_len
        {
            return Err(PreparationError::Refused(ExecutionRefusal::InvalidRange));
        }
        let mut local_name = vec![0_u8; local_name_len];
        read_exact_at(&mut self.source, local_fixed_end, &mut local_name)?;
        if local_name != central_name {
            return Err(PreparationError::Refused(ExecutionRefusal::LocalRecordMismatch));
        }
        Ok(ValidatedStoredEntry {
            id: entry.id,
            output_path: String::new(),
            record_start: local_start,
            record_end: payload_end,
            payload_offset: local_name_end,
            payload_length: compressed,
            crc32,
        })
    }
}

fn captured_limits(mut limits: ArchiveLimits) -> ArchiveLimits {
    limits.max_selection_entries = limits.max_selection_entries.min(MAX_SELECTED_FILES);
    limits.max_entry_declared_output_bytes = limits
        .max_entry_declared_output_bytes
        .min(MAX_ENTRY_BYTES);
    limits.max_total_declared_output_bytes = limits
        .max_total_declared_output_bytes
        .min(MAX_TOTAL_BYTES);
    limits.max_expansion_ratio = limits.max_expansion_ratio.min(1);
    limits.max_actual_entry_output_bytes = limits
        .max_actual_entry_output_bytes
        .min(MAX_ENTRY_BYTES);
    limits.max_actual_total_output_bytes = limits
        .max_actual_total_output_bytes
        .min(MAX_TOTAL_BYTES);
    limits
}

fn read_exact_at<R: Read + Seek>(
    reader: &mut R,
    offset: u64,
    buffer: &mut [u8],
) -> Result<(), PreparationError> {
    reader
        .seek(SeekFrom::Start(offset))
        .map_err(PreparationError::Io)?;
    reader.read_exact(buffer).map_err(PreparationError::Io)
}

fn le_u16(bytes: &[u8], offset: usize) -> u16 {
    u16::from_le_bytes([bytes[offset], bytes[offset + 1]])
}

fn le_u32(bytes: &[u8], offset: usize) -> u32 {
    u32::from_le_bytes([
        bytes[offset],
        bytes[offset + 1],
        bytes[offset + 2],
        bytes[offset + 3],
    ])
}

#[derive(Debug)]
struct RetainedStage {
    path: PathBuf,
    identity: Option<crate::file_operations::NativeFileIdentity>,
    reason: String,
    capability: Option<crate::file_operations::archive_io::ArchiveStageHandle>,
}

#[derive(Debug)]
enum ReservationCause {
    Cancelled,
    Create(io::Error),
}

#[derive(Debug)]
struct ReservationFailure {
    cause: ReservationCause,
    retained: Vec<RetainedStage>,
}

#[derive(Debug)]
struct StageCreateFailure {
    error: io::Error,
    retained: Option<RetainedStage>,
}

#[derive(Debug)]
struct ArchiveAbortReceipt {
    retired_stage_count: usize,
    retained: Vec<RetainedStage>,
}

fn reserve_stages<T>(
    count: usize,
    cancellation: &ScanCancellation,
    mut create: impl FnMut(usize) -> Result<T, StageCreateFailure>,
    mut retire: impl FnMut(T) -> Option<RetainedStage>,
) -> Result<Vec<T>, ReservationFailure> {
    let mut stages = Vec::new();
    if stages.try_reserve_exact(count).is_err() {
        return Err(ReservationFailure {
            cause: ReservationCause::Create(io::Error::other("stage vector allocation failed")),
            retained: Vec::new(),
        });
    }
    for index in 0..count {
        if cancellation.is_cancelled() {
            let retained = stages.into_iter().filter_map(&mut retire).collect();
            return Err(ReservationFailure {
                cause: ReservationCause::Cancelled,
                retained,
            });
        }
        match create(index) {
            Ok(stage) => stages.push(stage),
            Err(failure) => {
                let mut retained: Vec<_> = stages.into_iter().filter_map(&mut retire).collect();
                retained.extend(failure.retained);
                return Err(ReservationFailure {
                    cause: ReservationCause::Create(failure.error),
                    retained,
                });
            }
        }
        if cancellation.is_cancelled() {
            let retained = stages.into_iter().filter_map(&mut retire).collect();
            return Err(ReservationFailure {
                cause: ReservationCause::Cancelled,
                retained,
            });
        }
    }
    Ok(stages)
}

#[cfg(windows)]
impl ArchiveSession<crate::file_operations::archive_io::ArchiveSourceLease> {
    fn open_native(
        path: &std::path::Path,
        caller_limits: ArchiveLimits,
        cancellation: &ScanCancellation,
    ) -> Result<Self, PreparationError> {
        let source = crate::file_operations::archive_io::open_source(path)
            .map_err(PreparationError::Io)?;
        let revision = NEXT_REVISION
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |current| {
                current.checked_add(1)
            })
            .map_err(|_| PreparationError::Refused(ExecutionRefusal::UnsupportedEntry))?;
        Self::from_reader(source, ArchiveRevision::new(revision), caller_limits, cancellation)
    }

    fn prepare_native(
        mut self,
        plan: ExtractionPlan,
        destination_path: &std::path::Path,
        cancellation: &ScanCancellation,
    ) -> Result<PreparedArchive, PreparationError> {
        self.source.revalidate().map_err(PreparationError::Io)?;
        let entries = self.validate_plan(&plan, cancellation)?;
        self.source.revalidate().map_err(PreparationError::Io)?;
        let destination = crate::file_operations::archive_io::open_destination(destination_path)
            .map_err(PreparationError::Io)?;
        for entry in &entries {
            let leaf = std::ffi::OsStr::new(entry.output_path.as_str());
            if destination.leaf_occupancy(leaf).map_err(PreparationError::Io)? {
                return Err(PreparationError::Io(io::Error::new(
                    io::ErrorKind::AlreadyExists,
                    "archive output was occupied at reservation time",
                )));
            }
        }
        let destination = std::sync::Arc::new(destination);
        let stages = reserve_stages(
            entries.len(),
            cancellation,
            |index| {
                let entry = &entries[index];
                for attempt in 0..8_u8 {
                    let sequence = NEXT_STAGE.fetch_add(1, Ordering::Relaxed);
                    let stage_leaf = format!(".ml-archive-{}-{sequence}-{attempt}.stage", std::process::id());
                    match destination.create_stage(
                        std::ffi::OsStr::new(&stage_leaf),
                        std::ffi::OsStr::new(entry.output_path.as_str()),
                    ) {
                        Ok(stage) => return Ok(stage),
                        Err(error)
                            if error.error.kind() == io::ErrorKind::AlreadyExists
                                && error.retained.is_none() =>
                        {
                            continue;
                        }
                        Err(error) => {
                            let retained = error.retained.map(|stage| RetainedStage {
                                path: stage.path().to_path_buf(),
                                identity: stage.identity(),
                                reason: "stage creation failed and held cleanup did not complete"
                                    .to_owned(),
                                capability: Some(stage),
                            });
                            return Err(StageCreateFailure {
                                error: error.error,
                                retained,
                            });
                        }
                    }
                }
                Err(StageCreateFailure {
                    error: io::Error::new(
                        io::ErrorKind::AlreadyExists,
                        "bounded archive stage-name collisions exhausted",
                    ),
                    retained: None,
                })
            },
            |stage: crate::file_operations::archive_io::ArchiveStageHandle| {
                retire_native_stage(stage)
            },
        )
        .map_err(PreparationError::Reservation)?;
        Ok(PreparedArchive {
            source: self.source,
            catalog: self.catalog,
            plan,
            entries,
            destination,
            stages,
        })
    }
}

#[cfg(windows)]
struct PreparedArchive {
    source: crate::file_operations::archive_io::ArchiveSourceLease,
    catalog: ArchiveCatalog,
    plan: ExtractionPlan,
    entries: Vec<ValidatedStoredEntry>,
    destination: std::sync::Arc<crate::file_operations::archive_io::ArchiveDestinationGuard>,
    stages: Vec<crate::file_operations::archive_io::ArchiveStageHandle>,
}

#[cfg(windows)]
impl PreparedArchive {
    fn abort(self) -> ArchiveAbortReceipt {
        let mut receipt = ArchiveAbortReceipt {
            retired_stage_count: 0,
            retained: Vec::new(),
        };
        for stage in self.stages {
            if let Some(retained) = retire_native_stage(stage) {
                receipt.retained.push(retained);
            } else {
                receipt.retired_stage_count += 1;
            }
        }
        receipt
    }
}

#[cfg(windows)]
fn retire_native_stage(
    stage: crate::file_operations::archive_io::ArchiveStageHandle,
) -> Option<RetainedStage> {
    let path = stage.path().to_path_buf();
    let identity = stage.identity();
    match stage.abort() {
        Ok(()) => None,
        Err(error) => Some(RetainedStage {
            path,
            identity,
            reason: format!("held-handle stage retirement failed: {}", error.error),
            capability: error.retained,
        }),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::cell::RefCell;
    use std::io::Cursor;
    use std::ops::Range;
    use std::rc::Rc;

    #[derive(Clone)]
    struct ZipMember<'a> {
        name: &'a [u8],
        payload: &'a [u8],
        flags: u16,
        method: u16,
        version: u16,
        host: u8,
        central_extra: &'a [u8],
        local_extra: &'a [u8],
        declared_size: Option<u32>,
    }

    impl<'a> ZipMember<'a> {
        fn file(name: &'a [u8], payload: &'a [u8]) -> Self {
            Self {
                name,
                payload,
                flags: 0,
                method: 0,
                version: 20,
                host: 0,
                central_extra: &[],
                local_extra: &[],
                declared_size: None,
            }
        }
    }

    #[derive(Debug)]
    struct ZipLocation {
        local_offset: usize,
        payload_range: Range<usize>,
        central_offset: usize,
    }

    fn put16(output: &mut Vec<u8>, value: u16) {
        output.extend_from_slice(&value.to_le_bytes());
    }

    fn put32(output: &mut Vec<u8>, value: u32) {
        output.extend_from_slice(&value.to_le_bytes());
    }

    fn crc32(bytes: &[u8]) -> u32 {
        let mut crc = !0_u32;
        for byte in bytes {
            crc ^= u32::from(*byte);
            for _ in 0..8 {
                crc = (crc >> 1) ^ (0xEDB8_8320 & (0_u32.wrapping_sub(crc & 1)));
            }
        }
        !crc
    }

    fn make_zip(members: &[ZipMember<'_>]) -> (Vec<u8>, Vec<ZipLocation>) {
        let mut output = Vec::new();
        let mut locations = Vec::new();
        let mut local_offsets = Vec::new();
        for member in members {
            let local_offset = output.len();
            local_offsets.push(local_offset);
            let size = member.declared_size.unwrap_or(member.payload.len() as u32);
            let checksum = crc32(member.payload);
            put32(&mut output, LOCAL_SIGNATURE);
            put16(&mut output, member.version);
            put16(&mut output, member.flags);
            put16(&mut output, member.method);
            put16(&mut output, 0);
            put16(&mut output, 0);
            put32(&mut output, checksum);
            put32(&mut output, size);
            put32(&mut output, size);
            put16(&mut output, member.name.len() as u16);
            put16(&mut output, member.local_extra.len() as u16);
            output.extend_from_slice(member.name);
            output.extend_from_slice(member.local_extra);
            let payload_start = output.len();
            output.extend_from_slice(member.payload);
            locations.push(ZipLocation {
                local_offset,
                payload_range: payload_start..output.len(),
                central_offset: 0,
            });
        }
        let central_start = output.len();
        for (index, member) in members.iter().enumerate() {
            let checksum = crc32(member.payload);
            let size = member.declared_size.unwrap_or(member.payload.len() as u32);
            let central_offset = output.len();
            locations[index].central_offset = central_offset;
            put32(&mut output, CENTRAL_SIGNATURE);
            put16(&mut output, (u16::from(member.host) << 8) | 20);
            put16(&mut output, member.version);
            put16(&mut output, member.flags);
            put16(&mut output, member.method);
            put16(&mut output, 0);
            put16(&mut output, 0);
            put32(&mut output, checksum);
            put32(&mut output, size);
            put32(&mut output, size);
            put16(&mut output, member.name.len() as u16);
            put16(&mut output, member.central_extra.len() as u16);
            put16(&mut output, 0);
            put16(&mut output, 0);
            put16(&mut output, 0);
            put32(&mut output, 0);
            put32(&mut output, local_offsets[index] as u32);
            output.extend_from_slice(member.name);
            output.extend_from_slice(member.central_extra);
        }
        let central_size = output.len() - central_start;
        put32(&mut output, 0x0605_4b50);
        put16(&mut output, 0);
        put16(&mut output, 0);
        put16(&mut output, members.len() as u16);
        put16(&mut output, members.len() as u16);
        put32(&mut output, central_size as u32);
        put32(&mut output, central_start as u32);
        put16(&mut output, 0);
        (output, locations)
    }

    #[derive(Clone)]
    struct TrackingReader {
        inner: Cursor<Vec<u8>>,
        reads: Rc<RefCell<Vec<Range<u64>>>>,
    }

    impl Read for TrackingReader {
        fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
            let start = self.inner.position();
            let read = self.inner.read(buffer)?;
            if read != 0 {
                self.reads
                    .borrow_mut()
                    .push(start..start.saturating_add(read as u64));
            }
            Ok(read)
        }
    }

    impl Seek for TrackingReader {
        fn seek(&mut self, position: SeekFrom) -> io::Result<u64> {
            self.inner.seek(position)
        }
    }

    fn new_session<R: Read + Seek>(
        reader: R,
        revision: u64,
        limits: ArchiveLimits,
    ) -> ArchiveSession<R> {
        ArchiveSession::from_reader(
            reader,
            ArchiveRevision::new(revision),
            limits,
            &ScanCancellation::new(),
        )
        .expect("small synthetic ZIP catalog")
    }

    fn plan_for<R: Read + Seek>(
        session: &ArchiveSession<R>,
        ids: &[ArchiveEntryId],
    ) -> Result<ExtractionPlan, PreparationError> {
        let mut selection = ArchiveSelection::new();
        for id in ids {
            selection
                .add(SelectionTarget::Entry(*id), &session.limits)
                .expect("selection within captured limit");
        }
        session.plan(&selection, &ScanCancellation::new())
    }

    fn only_ids<R>(session: &ArchiveSession<R>, ordinals: &[u64]) -> Vec<ArchiveEntryId> {
        ordinals
            .iter()
            .map(|ordinal| {
                session.catalog.entries()[*ordinal as usize].id()
            })
            .collect()
    }

    #[test]
    fn g07_captured_quotas_cannot_be_raised_and_refuse_early() {
        let mut caller = ArchiveLimits::default();
        caller.max_selection_entries = 7;
        caller.max_entry_declared_output_bytes = 1024;
        caller.max_total_declared_output_bytes = 2048;
        caller.max_expansion_ratio = 20;
        caller.max_actual_entry_output_bytes = 3072;
        caller.max_actual_total_output_bytes = 4096;
        let captured = captured_limits(caller);
        assert_eq!(captured.max_selection_entries, 7);
        assert_eq!(captured.max_entry_declared_output_bytes, 1024);
        assert_eq!(captured.max_total_declared_output_bytes, 2048);
        assert_eq!(captured.max_expansion_ratio, 1);
        assert_eq!(captured.max_actual_entry_output_bytes, 3072);
        assert_eq!(captured.max_actual_total_output_bytes, 4096);

        let mut caller_limited = ArchiveLimits::default();
        caller_limited.max_entry_declared_output_bytes = 1024;
        let (caller_limited_zip, _) = make_zip(&[ZipMember {
            declared_size: Some(2048),
            ..ZipMember::file(b"caller-limited.bin", b"x")
        }]);
        let caller_limited_session = new_session(
            Cursor::new(caller_limited_zip),
            58,
            caller_limited,
        );
        assert!(matches!(
            plan_for(&caller_limited_session, &only_ids(&caller_limited_session, &[0])),
            Err(PreparationError::Plan(PlanBuildError::Rejected(_)))
        ));

        let member = ZipMember {
            declared_size: Some(65 * 1024 * 1024),
            ..ZipMember::file(b"large.bin", b"x")
        };
        let (bytes, _) = make_zip(&[member]);
        let session = new_session(Cursor::new(bytes), 51, ArchiveLimits::default());
        let ids = only_ids(&session, &[0]);
        let planned = plan_for(&session, &ids);
        assert!(matches!(planned, Err(PreparationError::Plan(PlanBuildError::Rejected(_)))));

        struct OversizeReader;
        impl Read for OversizeReader {
            fn read(&mut self, _buffer: &mut [u8]) -> io::Result<usize> {
                Ok(0)
            }
        }
        impl Seek for OversizeReader {
            fn seek(&mut self, position: SeekFrom) -> io::Result<u64> {
                match position {
                    SeekFrom::End(0) => Ok(MAX_SOURCE_BYTES + 1),
                    SeekFrom::Start(offset) => Ok(offset),
                    SeekFrom::Current(0) => Ok(0),
                    _ => Err(io::Error::new(io::ErrorKind::Unsupported, "bounded fake reader")),
                }
            }
        }
        assert!(matches!(
            ArchiveSession::from_reader(
                OversizeReader,
                ArchiveRevision::new(57),
                ArchiveLimits::default(),
                &ScanCancellation::new()
            ),
            Err(PreparationError::SourceTooLarge)
        ));
    }

    #[test]
    fn g07_physical_duplicates_bind_the_selected_range_without_reading_payload() {
        let (bytes, locations) = make_zip(&[
            ZipMember::file(b"same.txt", b"first payload"),
            ZipMember::file(b"same.txt", b"second payload"),
            ZipMember::file(b"empty.txt", b""),
        ]);
        let reads = Rc::new(RefCell::new(Vec::new()));
        let reader = TrackingReader {
            inner: Cursor::new(bytes),
            reads: Rc::clone(&reads),
        };
        let mut session = new_session(reader, 52, ArchiveLimits::default());
        let selected = only_ids(&session, &[1, 2]);
        let plan = plan_for(&session, &selected).expect("one physical duplicate is selectable");
        let validated = session
            .validate_plan(&plan, &ScanCancellation::new())
            .expect("physical second entry is valid");
        assert_eq!(validated.len(), 2);
        let second = validated.iter().find(|entry| entry.id == selected[0]).unwrap();
        assert_eq!(second.payload_offset as usize, locations[1].payload_range.start);
        assert_eq!(second.payload_length as usize, locations[1].payload_range.len());
        assert_eq!(second.crc32, crc32(b"second payload"));
        let empty = validated.iter().find(|entry| entry.id == selected[1]).unwrap();
        assert_eq!(empty.payload_offset as usize, locations[2].payload_range.start);
        assert_eq!(empty.payload_length, 0);
        for read in reads.borrow().iter() {
            for payload in &locations {
                if payload.payload_range.is_empty() {
                    continue;
                }
                assert!(
                    read.end <= payload.payload_range.start as u64
                        || read.start >= payload.payload_range.end as u64,
                    "metadata/physical validation read overlapped payload range: {read:?} / {payload:?}"
                );
            }
        }
    }

    #[test]
    fn g07_physical_headers_ranges_and_execution_subset_refuse_before_reservation() {
        let (mut mismatch, first) = make_zip(&[ZipMember::file(b"a.txt", b"payload")]);
        mismatch[first[0].local_offset + 6] = 1;
        let mut session = new_session(Cursor::new(mismatch), 53, ArchiveLimits::default());
        let plan = plan_for(&session, &only_ids(&session, &[0])).expect("central plan is metadata-valid");
        assert!(matches!(
            session.validate_plan(&plan, &ScanCancellation::new()),
            Err(PreparationError::Refused(ExecutionRefusal::LocalRecordMismatch))
        ));

        let (with_extra, _) = make_zip(&[ZipMember {
            central_extra: b"\x34\x12\x00\x00",
            ..ZipMember::file(b"extra.txt", b"payload")
        }]);
        let mut session = new_session(Cursor::new(with_extra), 54, ArchiveLimits::default());
        let plan = plan_for(&session, &only_ids(&session, &[0])).expect("central extra remains catalog-visible");
        assert!(matches!(
            session.validate_plan(&plan, &ScanCancellation::new()),
            Err(PreparationError::Refused(ExecutionRefusal::UnsupportedExtraFields))
        ));

        let (deflated, _) = make_zip(&[ZipMember {
            method: 8,
            ..ZipMember::file(b"deflated.txt", b"not a decoder input")
        }]);
        let mut session = new_session(Cursor::new(deflated), 55, ArchiveLimits::default());
        let plan = plan_for(&session, &only_ids(&session, &[0])).expect("deflate remains catalog-visible");
        assert!(matches!(
            session.validate_plan(&plan, &ScanCancellation::new()),
            Err(PreparationError::Refused(ExecutionRefusal::UnsupportedEntry))
        ));

        let nested_header = {
            let mut prefix = Vec::new();
            let crc = crc32(b"nested");
            put32(&mut prefix, LOCAL_SIGNATURE);
            put16(&mut prefix, 20);
            put16(&mut prefix, 0);
            put16(&mut prefix, 0);
            put16(&mut prefix, 0);
            put16(&mut prefix, 0);
            put32(&mut prefix, crc);
            put32(&mut prefix, 6);
            put32(&mut prefix, 6);
            put16(&mut prefix, 5);
            put16(&mut prefix, 0);
            prefix.extend_from_slice(b"b.txt");
            prefix.extend_from_slice(b"nested");
            prefix
        };
        let (mut overlapping, overlap_locations) = make_zip(&[
            ZipMember::file(b"a.txt", &nested_header),
            ZipMember::file(b"b.txt", b"nested"),
        ]);
        let second_central_local_offset = overlap_locations[1].central_offset + 42;
        overlapping[second_central_local_offset..second_central_local_offset + 4]
            .copy_from_slice(&(overlap_locations[0].payload_range.start as u32).to_le_bytes());
        let mut session = new_session(Cursor::new(overlapping), 56, ArchiveLimits::default());
        let plan = plan_for(&session, &only_ids(&session, &[0, 1])).expect("distinct output names plan cleanly");
        assert!(matches!(
            session.validate_plan(&plan, &ScanCancellation::new()),
            Err(PreparationError::Refused(ExecutionRefusal::OverlappingRanges))
        ));
    }

    #[test]
    fn g07_preparation_cancellation_and_create_failure_abort_owned_stages() {
        #[derive(Debug)]
        struct FakeStage {
            index: usize,
            retired: bool,
        }

        let cancellation = ScanCancellation::new();
        let mut created = 0;
        let cancelled = reserve_stages(
            3,
            &cancellation,
            |_| {
                let stage = FakeStage {
                    index: created,
                    retired: false,
                };
                created += 1;
                if created == 1 {
                    cancellation.cancel();
                }
                Ok(stage)
            },
            |mut stage| {
                stage.retired = true;
                assert_eq!(stage.index, 0);
                None
            },
        );
        assert!(matches!(cancelled, Err(ReservationFailure { cause: ReservationCause::Cancelled, retained }) if retained.is_empty()));

        let cancellation = ScanCancellation::new();
        let mut created = 0;
        let failed = reserve_stages(
            3,
            &cancellation,
            |_| {
                if created == 1 {
                    return Err(StageCreateFailure {
                        error: io::Error::other("injected stage create failure"),
                        retained: None,
                    });
                }
                created += 1;
                Ok(FakeStage {
                    index: 0,
                    retired: false,
                })
            },
            |mut stage| {
                stage.retired = true;
                assert_eq!(stage.index, 0);
                None
            },
        );
        assert!(matches!(failed, Err(ReservationFailure { cause: ReservationCause::Create(error), retained }) if error.to_string() == "injected stage create failure" && retained.is_empty()));
    }
}
