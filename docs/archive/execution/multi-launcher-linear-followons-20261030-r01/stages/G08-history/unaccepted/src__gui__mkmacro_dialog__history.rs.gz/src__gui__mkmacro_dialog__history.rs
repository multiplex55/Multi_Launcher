use super::MkMacroDialog;
use crate::mkmacro::runtime::{
    HistoryAccessError, HistoryFilter, HistoryProjection, HistoryViewRequest, RunKey,
    RuntimeOrigin, RuntimeRunMode, SummaryOutcome, SummarySubset,
};
use eframe::egui;
use std::time::{Duration, Instant};

const NOTICE_LIFETIME: Duration = Duration::from_secs(5);

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub(super) enum HistoryTab {
    #[default]
    Editor,
    History,
}

#[derive(Debug, Clone, Copy)]
enum HistoryNotice {
    Cleared,
    Changed,
}

/// Dialog-persistent state contains only finite view controls and stable keys.
/// Projection rows are acquired and discarded within one visible frame.
#[derive(Debug, Default)]
pub(super) struct HistoryState {
    pub tab: HistoryTab,
    filter: HistoryFilter,
    page: usize,
    detail_page: usize,
    selected: Option<RunKey>,
    notice: Option<(HistoryNotice, Instant)>,
}

pub(super) fn show_tab_controls(ui: &mut egui::Ui, dialog: &mut MkMacroDialog) {
    ui.separator();
    ui.selectable_value(&mut dialog.history_state.tab, HistoryTab::Editor, "Editor");
    ui.selectable_value(
        &mut dialog.history_state.tab,
        HistoryTab::History,
        "History",
    );
}

pub(super) fn is_active(dialog: &MkMacroDialog) -> bool {
    dialog.history_state.tab == HistoryTab::History
}

trait HistoryViewSource {
    fn with_view<R>(
        &mut self,
        request: HistoryViewRequest,
        inspect: impl FnOnce(&HistoryProjection) -> R,
    ) -> Result<R, HistoryAccessError>;

    fn clear_completed(&mut self, generation: u64) -> Result<(), HistoryAccessError>;
}

struct SharedHistorySource;

impl HistoryViewSource for SharedHistorySource {
    fn with_view<R>(
        &mut self,
        request: HistoryViewRequest,
        inspect: impl FnOnce(&HistoryProjection) -> R,
    ) -> Result<R, HistoryAccessError> {
        crate::mkmacro::runtime::with_history_view(request, inspect)
    }

    fn clear_completed(&mut self, generation: u64) -> Result<(), HistoryAccessError> {
        crate::mkmacro::runtime::clear_run_history(generation)
    }
}

pub(super) fn show_body(ui: &mut egui::Ui, dialog: &mut MkMacroDialog) {
    let mut source = SharedHistorySource;
    show_body_with_source(ui, &mut dialog.history_state, &mut source);
}

fn show_body_with_source(
    ui: &mut egui::Ui,
    state: &mut HistoryState,
    source: &mut impl HistoryViewSource,
) {
    expire_notice(state);
    let request = HistoryViewRequest {
        page: state.page,
        detail_page: state.detail_page,
        filter: state.filter,
        selected: state.selected,
    };
    let render = source.with_view(request, |projection| {
        state.page = projection.page;
        if projection.selection_missing {
            state.selected = None;
            state.detail_page = 0;
        } else if state.selected.is_none() {
            state.selected = projection
                .selected_index
                .and_then(|index| projection.headers[index])
                .map(|header| header.key);
        }
        state.detail_page = projection.detail_page;
        let clear_requested = render_projection(ui, state, projection);
        (projection.generation, clear_requested)
    });

    match render {
        Ok((generation, true)) => match source.clear_completed(generation) {
            Ok(()) => {
                state.selected = None;
                state.detail_page = 0;
                set_notice(state, HistoryNotice::Cleared);
            }
            Err(HistoryAccessError::Busy | HistoryAccessError::RuntimeUnavailable) => {
                set_notice(state, HistoryNotice::Changed);
            }
            Err(HistoryAccessError::Budget) => {
                set_notice(state, HistoryNotice::Changed);
            }
        },
        Ok((_, false)) => {}
        Err(HistoryAccessError::RuntimeUnavailable) => {
            ui.heading("Run history");
            ui.label("History is unavailable while the runtime is stopped.");
        }
        Err(HistoryAccessError::Busy) => {
            ui.heading("Run history");
            ui.label("History is busy.");
        }
        Err(HistoryAccessError::Budget) => {
            ui.heading("Run history");
            ui.label("History view capacity is unavailable.");
        }
    }

    if let Some((notice, expires_at)) = state.notice {
        if Instant::now() < expires_at {
            ui.label(match notice {
                HistoryNotice::Cleared => "Completed history cleared.",
                HistoryNotice::Changed => "History changed before it could be cleared.",
            });
        } else {
            state.notice = None;
        }
    }
}

fn set_notice(state: &mut HistoryState, notice: HistoryNotice) {
    state.notice = Some((notice, Instant::now() + NOTICE_LIFETIME));
}

fn expire_notice(state: &mut HistoryState) {
    if state
        .notice
        .is_some_and(|(_, expires_at)| Instant::now() >= expires_at)
    {
        state.notice = None;
    }
}

fn render_projection(
    ui: &mut egui::Ui,
    state: &mut HistoryState,
    projection: &HistoryProjection,
) -> bool {
    expire_notice(state);
    ui.heading("Run history");
    ui.horizontal(|ui| {
        ui.label("Completed runs");
        egui::ComboBox::from_id_salt("mkmacro_history_filter")
            .selected_text(match state.filter {
                HistoryFilter::All => "All",
                HistoryFilter::Failed => "Failed",
            })
            .show_ui(ui, |ui| {
                ui.selectable_value(&mut state.filter, HistoryFilter::All, "All");
                ui.selectable_value(&mut state.filter, HistoryFilter::Failed, "Failed");
            });
        ui.label(format!("{} shown", projection.total_runs));
    });

    let mut clear_requested = false;
    ui.horizontal(|ui| {
        if ui
            .add_enabled(
                projection.completed_count > 0,
                egui::Button::new("Clear completed"),
            )
            .clicked()
        {
            clear_requested = true;
        }
        if projection.page_count > 1 {
            if ui
                .add_enabled(projection.page > 0, egui::Button::new("Previous"))
                .clicked()
            {
                state.page = state.page.saturating_sub(1);
            }
            ui.label(format!(
                "Page {} of {}",
                projection.page + 1,
                projection.page_count
            ));
            if ui
                .add_enabled(
                    projection.page + 1 < projection.page_count,
                    egui::Button::new("Next"),
                )
                .clicked()
            {
                state.page = state.page.saturating_add(1);
            }
        }
    });

    if projection.header_count == 0 {
        ui.label("No completed runs.");
    } else {
        egui::ScrollArea::vertical()
            .id_salt("mkmacro_history_rows")
            .max_height(220.0)
            .show(ui, |ui| {
                for index in 0..projection.header_count {
                    let Some(header) = projection.headers[index] else {
                        continue;
                    };
                    let suffix = if header.name_truncated { "…" } else { "" };
                    let label = format!(
                        "Run {} · Macro {} · {}{}  ·  {}  ·  {}  ·  {:.2}s",
                        header.key.run_id,
                        header.macro_id,
                        header.name(),
                        suffix,
                        header.invocation_source.label(),
                        outcome_label(header.outcome),
                        header.elapsed.as_secs_f64()
                    );
                    let selected = projection.selected_index == Some(index);
                    let label = if index == crate::mkmacro::runtime::HISTORY_PAGE_SIZE {
                        format!("Selected outside page  ·  {label}")
                    } else {
                        label
                    };
                    let response =
                        ui.push_id(header.key, |ui| ui.selectable_label(selected, label));
                    if response.inner.clicked() {
                        state.selected = Some(header.key);
                        state.detail_page = 0;
                    }
                }
            });
    }

    ui.separator();
    if let Some(index) = projection.selected_index {
        if let Some(header) = projection.headers[index] {
            ui.heading(header.name());
            ui.label(format!(
                "Run {} · generation {} · macro {} · {} · {} · {} · {}",
                header.key.run_id,
                header.key.generation,
                header.macro_id,
                origin_label(header.origin),
                mode_label(header.mode),
                subset_label(header.subset),
                header.invocation_source.label(),
            ));
            ui.label(format!(
                "{} · {} started, {} succeeded, {} skipped, {} failed, {} interrupted",
                outcome_label(header.outcome),
                header.visits.started,
                header.visits.succeeded,
                header.visits.skipped,
                header.visits.failed,
                header.visits.interrupted
            ));
            ui.label(format!(
                "Elapsed {:.2}s · paused {:.2}s",
                header.elapsed.as_secs_f64(),
                header.paused.as_secs_f64()
            ));
            if let Some(reason) = header.failure_reason {
                ui.label(reason);
            }
            if header.omitted_visit_details > 0 || header.detail_truncated {
                ui.label("Some step details were omitted by the history limit.");
            }
            if header.counter_overflowed {
                ui.label("Some counters reached the history limit.");
            }
            if projection.details_total > 0 {
                ui.label(format!(
                    "Step details: {} retained",
                    projection.details_total
                ));
            }
            if projection.detail_page_count > 1 {
                ui.horizontal(|ui| {
                    if ui
                        .add_enabled(
                            projection.detail_page > 0,
                            egui::Button::new("Previous details"),
                        )
                        .clicked()
                    {
                        state.detail_page = state.detail_page.saturating_sub(1);
                    }
                    ui.label(format!(
                        "Details page {} of {}",
                        projection.detail_page + 1,
                        projection.detail_page_count
                    ));
                    if ui
                        .add_enabled(
                            projection.detail_page + 1 < projection.detail_page_count,
                            egui::Button::new("Next details"),
                        )
                        .clicked()
                    {
                        state.detail_page = state.detail_page.saturating_add(1);
                    }
                });
            }
            for detail in projection
                .details
                .iter()
                .take(projection.detail_count)
                .flatten()
            {
                ui.label(format!(
                    "Macro {} · Step {} · {} · {} visits, {} succeeded, {} skipped, {} failed, {} interrupted · {:.2}s",
                    detail.macro_id,
                    detail.step_id,
                    detail.category.label(),
                    detail.visits_started,
                    detail.visits_succeeded,
                    detail.visits_skipped,
                    detail.visits_failed,
                    detail.visits_interrupted,
                    detail.inclusive_elapsed.as_secs_f64()
                ));
            }
            if projection.details_total == 0 {
                ui.label("No step details were retained.");
            }
        }
    } else {
        ui.label("Select a completed run to see its safe summary.");
    }
    clear_requested
}

fn outcome_label(outcome: SummaryOutcome) -> &'static str {
    match outcome {
        SummaryOutcome::Completed => "Completed",
        SummaryOutcome::Stopped => "Stopped",
        SummaryOutcome::Failed(_) => "Failed",
    }
}

fn origin_label(origin: RuntimeOrigin) -> &'static str {
    match origin {
        RuntimeOrigin::Stored => "Stored run",
        RuntimeOrigin::RecordingPreview { .. } => "Recording preview",
    }
}

fn mode_label(mode: RuntimeRunMode) -> &'static str {
    match mode {
        RuntimeRunMode::Normal => "Normal mode",
        RuntimeRunMode::Debug => "Debug mode",
    }
}

fn subset_label(subset: SummarySubset) -> String {
    match subset {
        SummarySubset::Whole => "Whole macro".into(),
        SummarySubset::FromStep { step_id } => format!("From step {step_id}"),
        SummarySubset::Selected { step_count } => format!("Selected steps ({step_count})"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mkmacro::{RecorderSnapshot, RuntimeSnapshot};
    use eframe::egui::accesskit::Role;
    use std::collections::HashMap;
    use std::sync::Arc;

    struct SyntheticStatus {
        recording: Option<String>,
        runtime: Option<Arc<RuntimeSnapshot>>,
        recorder: Option<Arc<RecorderSnapshot>>,
        stop_pending: bool,
    }

    impl super::super::toolbar::ToolbarStatusProvider for SyntheticStatus {
        fn recording_status(&self) -> Option<String> {
            self.recording.clone()
        }

        fn snapshot(&self) -> Option<Arc<RuntimeSnapshot>> {
            self.runtime.clone()
        }

        fn recorder_snapshot(&self) -> Option<Arc<RecorderSnapshot>> {
            self.recorder.clone()
        }

        fn record_stop_pending(&self) -> bool {
            self.stop_pending
        }
    }

    #[derive(Default)]
    struct InertHistorySource {
        in_view: bool,
        cleared_generations: Vec<u64>,
    }

    impl HistoryViewSource for InertHistorySource {
        fn with_view<R>(
            &mut self,
            request: HistoryViewRequest,
            inspect: impl FnOnce(&HistoryProjection) -> R,
        ) -> Result<R, HistoryAccessError> {
            let mut projection = clearable_projection();
            projection.page = request.page.min(projection.page_count.saturating_sub(1));
            self.in_view = true;
            let result = inspect(&projection);
            self.in_view = false;
            Ok(result)
        }

        fn clear_completed(&mut self, generation: u64) -> Result<(), HistoryAccessError> {
            assert!(!self.in_view, "the view lease is retired before clear");
            self.cleared_generations.push(generation);
            Ok(())
        }
    }

    fn clearable_projection() -> HistoryProjection {
        let mut name = [0; 256];
        let safe_name = b"clear target";
        name[..safe_name.len()].copy_from_slice(safe_name);
        let mut projection = HistoryProjection {
            generation: 91,
            revision: 1,
            completed_count: 1,
            total_runs: 1,
            page: 0,
            page_count: 1,
            details_total: 0,
            detail_page: 0,
            detail_page_count: 0,
            header_count: 1,
            headers: [None; crate::mkmacro::runtime::HISTORY_PAGE_SIZE + 1],
            selected_index: Some(0),
            detail_count: 0,
            details: [None; crate::mkmacro::runtime::HISTORY_DETAIL_LIMIT],
            details_truncated: false,
            selection_missing: false,
        };
        projection.headers[0] = Some(crate::mkmacro::runtime::HistoryHeader {
            key: RunKey {
                generation: 91,
                run_id: 92,
            },
            macro_id: 93,
            name,
            name_len: safe_name.len() as u16,
            name_truncated: false,
            invocation_source: crate::mkmacro::runtime::InvocationSource::MacroDialog,
            origin: RuntimeOrigin::Stored,
            mode: RuntimeRunMode::Normal,
            subset: SummarySubset::Whole,
            outcome: SummaryOutcome::Completed,
            elapsed: Duration::ZERO,
            paused: Duration::ZERO,
            visits: Default::default(),
            omitted_visit_details: 0,
            detail_truncated: false,
            counter_overflowed: false,
            failure_reason: None,
        });
        projection
    }

    fn raw_input(screen: egui::Rect, events: Vec<egui::Event>) -> egui::RawInput {
        egui::RawInput {
            screen_rect: Some(screen),
            focused: true,
            events,
            ..Default::default()
        }
    }

    fn pointer_button_events(position: egui::Pos2, pressed: bool) -> Vec<egui::Event> {
        vec![
            egui::Event::PointerMoved(position),
            egui::Event::PointerButton {
                pos: position,
                button: egui::PointerButton::Primary,
                pressed,
                modifiers: egui::Modifiers::NONE,
            },
        ]
    }

    fn accesskit_labels_and_bounds(
        output: &egui::FullOutput,
    ) -> (Vec<String>, HashMap<String, egui::Rect>) {
        let mut labels = Vec::new();
        let mut bounds = HashMap::new();
        if let Some(update) = output.platform_output.accesskit_update.as_ref() {
            for (_, node) in &update.nodes {
                let Some(label) = node.label() else {
                    continue;
                };
                labels.push(label.to_owned());
                if let Some(rect) = node.bounds() {
                    bounds.entry(label.to_owned()).or_insert_with(|| {
                        egui::Rect::from_min_max(
                            egui::pos2(rect.x0 as f32, rect.y0 as f32),
                            egui::pos2(rect.x1 as f32, rect.y1 as f32),
                        )
                    });
                }
            }
        }
        (labels, bounds)
    }

    fn render_main_dialog(
        ctx: &egui::Context,
        dialog: &mut MkMacroDialog,
        screen: egui::Rect,
        events: Vec<egui::Event>,
    ) -> (Vec<String>, HashMap<String, egui::Rect>) {
        let output = ctx.run_ui(raw_input(screen, events), |ctx| {
            egui::CentralPanel::default().show(ctx, |ui| {
                dialog.show_contents_with_table_viewport(ui, None);
            });
        });
        let result = accesskit_labels_and_bounds(&output);
        output.drop_without_applying_deltas();
        result
    }

    fn click_main_dialog(
        ctx: &egui::Context,
        dialog: &mut MkMacroDialog,
        screen: egui::Rect,
        position: egui::Pos2,
    ) -> (Vec<String>, HashMap<String, egui::Rect>) {
        let _ = render_main_dialog(ctx, dialog, screen, pointer_button_events(position, true));
        render_main_dialog(ctx, dialog, screen, pointer_button_events(position, false))
    }

    fn render_projection_frame(
        ctx: &egui::Context,
        state: &mut HistoryState,
        projection: &HistoryProjection,
        screen: egui::Rect,
        events: Vec<egui::Event>,
    ) -> (bool, Vec<String>, HashMap<String, egui::Rect>) {
        let mut clear_requested = false;
        let output = ctx.run_ui(raw_input(screen, events), |ctx| {
            egui::CentralPanel::default().show(ctx, |ui| {
                clear_requested = render_projection(ui, state, projection);
            });
        });
        let (labels, bounds) = accesskit_labels_and_bounds(&output);
        output.drop_without_applying_deltas();
        (clear_requested, labels, bounds)
    }

    fn render_source_body_frame(
        ctx: &egui::Context,
        state: &mut HistoryState,
        source: &mut InertHistorySource,
        screen: egui::Rect,
        events: Vec<egui::Event>,
    ) -> (Vec<String>, HashMap<String, egui::Rect>) {
        let output = ctx.run_ui(raw_input(screen, events), |ctx| {
            egui::CentralPanel::default().show(ctx, |ui| {
                show_body_with_source(ui, state, source);
            });
        });
        let result = accesskit_labels_and_bounds(&output);
        output.drop_without_applying_deltas();
        result
    }

    fn click_source_body(
        ctx: &egui::Context,
        state: &mut HistoryState,
        source: &mut InertHistorySource,
        screen: egui::Rect,
        position: egui::Pos2,
    ) -> (Vec<String>, HashMap<String, egui::Rect>) {
        let _ = render_source_body_frame(
            ctx,
            state,
            source,
            screen,
            pointer_button_events(position, true),
        );
        render_source_body_frame(
            ctx,
            state,
            source,
            screen,
            pointer_button_events(position, false),
        )
    }

    fn click_projection(
        ctx: &egui::Context,
        state: &mut HistoryState,
        projection: &HistoryProjection,
        screen: egui::Rect,
        position: egui::Pos2,
    ) -> (bool, Vec<String>, HashMap<String, egui::Rect>) {
        let _ = render_projection_frame(
            ctx,
            state,
            projection,
            screen,
            pointer_button_events(position, true),
        );
        render_projection_frame(
            ctx,
            state,
            projection,
            screen,
            pointer_button_events(position, false),
        )
    }

    fn render_toolbar(
        dialog: &mut MkMacroDialog,
        status: &dyn super::super::toolbar::ToolbarStatusProvider,
    ) -> (Vec<String>, HashMap<String, bool>) {
        let ctx = egui::Context::default();
        ctx.enable_accesskit();
        let screen = egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(1200.0, 900.0));
        let (labels, buttons, _) = render_toolbar_frame(&ctx, dialog, status, screen, Vec::new());
        (labels, buttons)
    }

    fn render_toolbar_frame(
        ctx: &egui::Context,
        dialog: &mut MkMacroDialog,
        status: &dyn super::super::toolbar::ToolbarStatusProvider,
        screen: egui::Rect,
        events: Vec<egui::Event>,
    ) -> (
        Vec<String>,
        HashMap<String, bool>,
        HashMap<String, egui::Rect>,
    ) {
        let output = ctx.run_ui(raw_input(screen, events), |ctx| {
            egui::CentralPanel::default().show(ctx, |ui| {
                let mut order = 0;
                super::super::toolbar::show_with_status(ui, dialog, None, &mut order, status);
                if is_active(dialog) {
                    show_body(ui, dialog);
                } else {
                    ui.label("Editor body");
                }
            });
        });
        let (labels, bounds) = accesskit_labels_and_bounds(&output);
        let mut buttons = HashMap::new();
        if let Some(update) = output.platform_output.accesskit_update.as_ref() {
            for (_, node) in &update.nodes {
                if let Some(label) = node.label() {
                    if node.role() == Role::Button {
                        buttons.insert(label.to_owned(), !node.is_disabled());
                    }
                }
            }
        }
        output.drop_without_applying_deltas();
        (labels, buttons, bounds)
    }

    #[test]
    fn g08_history_actual_controls_visible_lifecycle_and_document_preservation() {
        let directory = tempfile::tempdir().unwrap();
        let (store, _) = crate::mkmacro::MkMacroStore::open(directory.path()).unwrap();
        let mut dialog = MkMacroDialog::new(std::sync::Arc::new(store));
        dialog.open = true;
        dialog.create_macro();
        let before = (dialog.draft.clone(), dialog.dirty, dialog.draft_revision());
        let ctx = egui::Context::default();
        ctx.enable_accesskit();
        let screen = egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(1200.0, 900.0));
        let (editor_labels, editor_bounds) =
            render_main_dialog(&ctx, &mut dialog, screen, Vec::new());
        assert!(!editor_labels.iter().any(|label| label == "Run history"));
        let history_rect = *editor_bounds
            .get("History")
            .expect("History tab is visible");
        let (history_labels, history_bounds) =
            click_main_dialog(&ctx, &mut dialog, screen, history_rect.center());
        assert_eq!(dialog.history_state.tab, HistoryTab::History);
        assert!(history_labels.iter().any(|label| label == "Run history"));
        assert!(
            history_labels
                .iter()
                .any(|label| label == "History is unavailable while the runtime is stopped.")
        );

        let editor_rect = *history_bounds.get("Editor").expect("Editor tab is visible");
        let (editor_labels, _) = click_main_dialog(&ctx, &mut dialog, screen, editor_rect.center());
        assert_eq!(dialog.history_state.tab, HistoryTab::Editor);
        assert!(!editor_labels.iter().any(|label| label == "Run history"));

        let status = SyntheticStatus {
            recording: None,
            runtime: None,
            recorder: None,
            stop_pending: false,
        };
        let (output_labels, _buttons) = render_toolbar(&mut dialog, &status);
        assert!(output_labels.iter().any(|label| label == "History"));
        assert!(output_labels.iter().any(|label| label == "Editor"));
        assert_eq!(
            (dialog.draft.clone(), dialog.dirty, dialog.draft_revision()),
            before
        );
        assert_eq!(dialog.history_state.selected, None);
        assert!(dialog.history_state.notice.is_none());

        let mut inert_state = HistoryState::default();
        let mut inert_source = InertHistorySource::default();
        let inert_ctx = egui::Context::default();
        inert_ctx.enable_accesskit();
        let inert_screen = egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(960.0, 720.0));
        let (clear_labels, clear_bounds) = render_source_body_frame(
            &inert_ctx,
            &mut inert_state,
            &mut inert_source,
            inert_screen,
            Vec::new(),
        );
        assert!(clear_labels.iter().any(|label| label == "Clear completed"));
        let clear_rect = *clear_bounds
            .get("Clear completed")
            .expect("inert local history exposes Clear completed");
        let _ = click_source_body(
            &inert_ctx,
            &mut inert_state,
            &mut inert_source,
            inert_screen,
            clear_rect.center(),
        );
        assert_eq!(inert_source.cleared_generations, [91]);
        assert!(!inert_source.in_view);
    }

    #[test]
    fn g08_history_render_safe_labels_fallback_expiry_and_payload_exclusion() {
        let mut state = HistoryState::default();
        state.selected = Some(RunKey {
            generation: 9,
            run_id: 44,
        });
        set_notice(&mut state, HistoryNotice::Cleared);
        let expired = Some((
            HistoryNotice::Cleared,
            Instant::now() - Duration::from_secs(1),
        ));
        state.notice = expired;
        let mut projection = HistoryProjection {
            generation: 9,
            revision: 3,
            completed_count: 1,
            total_runs: 21,
            page: 0,
            page_count: 2,
            details_total: 0,
            detail_page: 0,
            detail_page_count: 0,
            header_count: 1,
            headers: [None; crate::mkmacro::runtime::HISTORY_PAGE_SIZE + 1],
            selected_index: Some(0),
            detail_count: 0,
            details: [None; crate::mkmacro::runtime::HISTORY_DETAIL_LIMIT],
            details_truncated: false,
            selection_missing: false,
        };
        let mut name = [0; 256];
        let safe_name = b"safe title";
        name[..safe_name.len()].copy_from_slice(safe_name);
        projection.headers[0] = Some(crate::mkmacro::runtime::HistoryHeader {
            key: RunKey {
                generation: 9,
                run_id: 44,
            },
            macro_id: 7,
            name,
            name_len: safe_name.len() as u16,
            name_truncated: false,
            invocation_source: crate::mkmacro::runtime::InvocationSource::MacroDialog,
            origin: RuntimeOrigin::RecordingPreview { ticket: 12 },
            mode: RuntimeRunMode::Debug,
            subset: SummarySubset::Selected { step_count: 3 },
            outcome: SummaryOutcome::Failed(crate::mkmacro::executor::DiagnosticKind::Backend),
            elapsed: Duration::from_secs(1),
            paused: Duration::ZERO,
            visits: Default::default(),
            omitted_visit_details: 0,
            detail_truncated: false,
            counter_overflowed: true,
            failure_reason: Some("Backend operation failed"),
        });
        let ctx = egui::Context::default();
        ctx.enable_accesskit();
        let screen = egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(960.0, 720.0));
        let (clear_requested, first_labels, first_bounds) =
            render_projection_frame(&ctx, &mut state, &projection, screen, Vec::new());
        let labels = first_labels;
        assert!(!clear_requested);
        assert!(!labels.is_empty(), "the Accessibility tree is available");
        assert!(state.notice.is_none(), "expired notices are discarded");
        assert_eq!(state.selected.unwrap().run_id, 44);
        assert!(labels.iter().any(|label| label.contains("safe title")));
        assert!(!labels.iter().any(|label| label.contains("PRIVATE_PAYLOAD")));
        assert_eq!(projection.headers[0].unwrap().name(), "safe title");
        assert_eq!(
            projection.headers[0].unwrap().failure_reason,
            Some("Backend operation failed")
        );
        assert!(
            labels
                .iter()
                .any(|label| label == "Backend operation failed")
        );
        let displayed = labels.join("\n");
        for safe_metadata in [
            "Run 44",
            "generation 9",
            "macro 7",
            "Recording preview",
            "Debug mode",
            "Selected steps (3)",
            "Some counters reached the history limit.",
        ] {
            assert!(displayed.contains(safe_metadata), "missing {safe_metadata}");
        }
        for control in ["All", "Clear completed", "Next", "Page 1 of 2"] {
            assert!(
                displayed.contains(control),
                "missing History control {control}"
            );
        }

        let filter_rect = *first_bounds.get("All").expect("All filter is visible");
        let (_, open_filter_labels, open_filter_bounds) =
            click_projection(&ctx, &mut state, &projection, screen, filter_rect.center());
        assert!(open_filter_labels.iter().any(|label| label == "Failed"));
        let failed_rect = *open_filter_bounds
            .get("Failed")
            .expect("Failed filter option is visible");
        let (_, failed_labels, failed_bounds) =
            click_projection(&ctx, &mut state, &projection, screen, failed_rect.center());
        assert_eq!(state.filter, HistoryFilter::Failed);
        assert!(failed_labels.iter().any(|label| label == "Failed"));

        let next_rect = *failed_bounds.get("Next").expect("Next page is visible");
        let _ = click_projection(&ctx, &mut state, &projection, screen, next_rect.center());
        assert_eq!(state.page, 1, "the Next control advances the page");
        projection.page = state.page;
        let (_, page_two_labels, _) =
            render_projection_frame(&ctx, &mut state, &projection, screen, Vec::new());
        let page_two_text = page_two_labels.join("\n");
        assert!(page_two_text.contains("Failed"));
        assert!(page_two_text.contains("Previous"));
        assert!(page_two_text.contains("Page 2 of 2"));
    }

    #[test]
    fn g08_history_r1_real_toolbar_composition_preserves_editor_diagnostics_and_controls() {
        let directory = tempfile::tempdir().unwrap();
        let (store, _) = crate::mkmacro::MkMacroStore::open(directory.path()).unwrap();
        let mut dialog = MkMacroDialog::new(Arc::new(store));
        dialog.create_macro();
        let macro_id = dialog.selected_macro_id.unwrap();
        dialog.draft.macros[0].name = "PRIVATE_CURRENT_MACRO".into();
        dialog.draft.macros[0].steps.push(crate::mkmacro::MkStep {
            metadata: Default::default(),
            id: 77,
            enabled: true,
            breakpoint: false,
            repeat: 1,
            delay_after_ms: 0,
            on_error: Default::default(),
            action: crate::mkmacro::MkAction::PlaySound(crate::mkmacro::MkPlaySoundPayload {
                sound: "PRIVATE_PAYLOAD".into(),
            }),
        });
        dialog.mark_dirty();
        dialog.command_error = Some("PRIVATE_COMMAND_DIAGNOSTIC".into());
        let original_document = dialog.draft.clone();
        let original_error = dialog.command_error.clone();

        let mut runtime = RuntimeSnapshot::default();
        runtime.state = crate::mkmacro::RuntimeState::Running;
        runtime.macro_id = Some(macro_id);
        runtime.completed_steps = 2;
        runtime.total_steps = 9;
        let recorder = Arc::new(RecorderSnapshot {
            state: crate::mkmacro::RecorderRuntimeState::Recording,
            macro_id: Some(macro_id),
            elapsed: Duration::from_secs(61),
            raw_event_count: 777,
            estimated_action_count: 88,
            dropped_event_count: 9,
            revision: 4,
        });
        let status = SyntheticStatus {
            recording: Some("PRIVATE_RECORDING_DETAILS".into()),
            runtime: Some(Arc::new(runtime)),
            recorder: Some(recorder),
            stop_pending: false,
        };

        dialog.history_state.tab = HistoryTab::History;
        let (history_labels, history_buttons) = render_toolbar(&mut dialog, &status);
        let history_text = history_labels.join("\n");
        for private in [
            "PRIVATE_COMMAND_DIAGNOSTIC",
            "PRIVATE_RECORDING_DETAILS",
            "PRIVATE_CURRENT_MACRO",
            "777 raw events",
            "88 actions",
            "9 events dropped",
        ] {
            assert!(!history_text.contains(private), "History leaked {private}");
        }
        assert!(history_text.contains("See the Editor for details"));
        assert!(history_text.contains("Recording is active"));
        assert!(history_text.contains("Step 3/9"));

        dialog.history_state.tab = HistoryTab::Editor;
        let (editor_labels, editor_buttons) = render_toolbar(&mut dialog, &status);
        let editor_text = editor_labels.join("\n");
        for private in [
            "PRIVATE_COMMAND_DIAGNOSTIC",
            "PRIVATE_RECORDING_DETAILS",
            "PRIVATE_CURRENT_MACRO",
            "777 raw events",
            "88 actions",
            "9 events dropped",
        ] {
            assert!(editor_text.contains(private), "Editor lost {private}");
        }
        for label in [
            "Run",
            "Pause",
            "Resume",
            "Stop",
            "Run From Here",
            "Run Selected",
            "Debug",
            "Record",
        ] {
            assert_eq!(
                history_buttons.get(label),
                editor_buttons.get(label),
                "History changed the actual toolbar enablement for {label}"
            );
        }
        assert_eq!(history_buttons.get("Run"), Some(&false));
        assert_eq!(history_buttons.get("Pause"), Some(&true));
        assert_eq!(history_buttons.get("Resume"), Some(&false));
        assert_eq!(history_buttons.get("Stop"), Some(&true));
        assert_eq!(history_buttons.get("Run From Here"), Some(&false));
        assert_eq!(history_buttons.get("Run Selected"), Some(&false));
        assert_eq!(history_buttons.get("Debug"), Some(&true));
        assert_eq!(history_buttons.get("Record"), Some(&false));

        let idle_status = SyntheticStatus {
            recording: None,
            runtime: None,
            recorder: None,
            stop_pending: false,
        };
        assert!(
            dialog
                .playback_block_reason()
                .as_deref()
                .is_some_and(|reason| reason.contains("PRIVATE_PAYLOAD")),
            "the disabled Run tooltip receives the invalid sound diagnostic"
        );
        let tooltip_ctx = egui::Context::default();
        tooltip_ctx.enable_accesskit();
        tooltip_ctx.global_style_mut(|style| style.interaction.tooltip_delay = 0.0);
        let tooltip_screen = egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(1200.0, 900.0));
        dialog.history_state.tab = HistoryTab::History;
        let (_, _, history_tooltip_bounds) = render_toolbar_frame(
            &tooltip_ctx,
            &mut dialog,
            &idle_status,
            tooltip_screen,
            Vec::new(),
        );
        let run_rect = *history_tooltip_bounds
            .get("Run")
            .expect("disabled Run control is accessible in History");
        let (history_tooltip_labels, _, _) = render_toolbar_frame(
            &tooltip_ctx,
            &mut dialog,
            &idle_status,
            tooltip_screen,
            vec![egui::Event::PointerMoved(run_rect.center())],
        );
        let history_tooltip = history_tooltip_labels.join("\n");
        assert!(history_tooltip.contains("Playback details are available in the Editor"));
        assert!(!history_tooltip.contains("PRIVATE_PAYLOAD"));

        dialog.history_state.tab = HistoryTab::Editor;
        let (_, _, editor_tooltip_bounds) = render_toolbar_frame(
            &tooltip_ctx,
            &mut dialog,
            &idle_status,
            tooltip_screen,
            Vec::new(),
        );
        let editor_run_rect = *editor_tooltip_bounds
            .get("Run")
            .expect("disabled Run control remains accessible in Editor");
        let (editor_tooltip_labels, _, _) = render_toolbar_frame(
            &tooltip_ctx,
            &mut dialog,
            &idle_status,
            tooltip_screen,
            vec![egui::Event::PointerMoved(editor_run_rect.center())],
        );
        assert!(
            editor_tooltip_labels.join("\n").contains("PRIVATE_PAYLOAD"),
            "Editor retains the original diagnostic tooltip"
        );
        assert_eq!(dialog.draft, original_document);
        assert_eq!(dialog.command_error, original_error);
    }
}
